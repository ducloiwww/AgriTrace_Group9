# M02 Standalone Requirements Index

## functional_requirements

### FR-002 — Manage farm information

- description: The system shall allow an authorized Farm Manager to create and update farm profile information.
- type: Functional
- priority: Must
- status: Approved
- source: SH-01
- rationale: Source: Lab 7 updated requirement baseline; Labs 1-4 core workflow. See UC-02.
- acceptance_criteria: Valid farm information is persisted and retrievable.
- verification_method: Test
- complexity: 1
- dependencies: None
- tags: UC-02;full-supply-chain
- module_id: M02
- implementation_status: Implemented locally: create and update farm
- linked_use_cases: UC-02
- designed_test_cases: TC-002
- _mod: M02

### FR-013 — Manage cultivation cycle

- description: The system shall allow an authorized Farm Manager to create and maintain a cultivation cycle for each crop plot, including crop variety, planting date, expected harvest window, and growing status.
- type: Functional
- priority: Must
- status: Approved
- source: SH-01
- rationale: Source: Lab 7 updated requirement baseline; post-Lab-4 expansion. See UC-14.
- acceptance_criteria: A cultivation cycle is stored with a unique cycle ID and linked farm/plot.
- verification_method: Test
- complexity: 1
- dependencies: None
- tags: UC-14;full-supply-chain
- module_id: M02
- implementation_status: Implemented (no close-cycle)
- linked_use_cases: UC-14
- designed_test_cases: TC-013
- _mod: M02

### FR-014 — Record cultivation activities

- description: The system shall allow an authorized Farm Manager to record irrigation, fertilization, crop-protection treatment, and other cultivation activities against an active cultivation cycle.
- type: Functional
- priority: Must
- status: Approved
- source: SH-01
- rationale: Source: Lab 7 updated requirement baseline; post-Lab-4 expansion. See UC-15.
- acceptance_criteria: Each activity is timestamped and linked to the correct cultivation cycle.
- verification_method: Test
- complexity: 1
- dependencies: None
- tags: UC-15;full-supply-chain
- module_id: M02
- implementation_status: Implemented
- linked_use_cases: UC-15
- designed_test_cases: TC-014
- _mod: M02

## use_cases

### UC-02 — Manage Farm Information

- primary_actor: Farm Manager
- goal: Maintain accurate farm identity and origin data
- preconditions: User is signed in as Farm Manager
- main_flow: Farmer opens farm profile; Enters farm name, location and contact details; System checks required fields and authorization; System stores the new or updated profile; System writes an audit event
- alternative_flows: 3a Missing field -> ValidationError. 3b Duplicate ID -> ConflictError. 3c Invalid ID characters -> ValidationError. Update of an existing farm is not implemented (gap G-02).
- postconditions: Approved farm profile is retrievable and linked to origin records
- trigger: Farm Manager registers a new farm.
- frequency: Not measured (coursework prototype)
- related_requirements: FR-002
- module_id: M02
- test_case_ids: TC-002
- web_implementation: add_farm
- _mod: M02

### UC-14 — Manage Cultivation Cycle

- primary_actor: Farm Manager
- goal: Register the full cultivation cycle for a crop plot
- preconditions: Farm and crop plot are identifiable; farm role authorized
- main_flow: Farmer selects farm/plot; Enters crop variety and planting date; System validates timeline and plot link; Creates cultivation-cycle identifier; Stores initial stage and audit event
- alternative_flows: Unknown plot -> reject; Invalid planting date -> reject; Duplicate active cycle -> flag
- postconditions: Cultivation cycle links farm, plot and crop to later batch history
- trigger: Farmer creates cultivation cycle
- frequency: Not measured (coursework prototype)
- related_requirements: FR-013
- module_id: M02
- test_case_ids: TC-013
- web_implementation: create_cycle
- _mod: M02

### UC-15 — Record Cultivation Activity

- primary_actor: Farm Manager
- goal: Record treatments and growing activities by cultivation cycle
- preconditions: An active cultivation cycle exists
- main_flow: Farmer selects cycle; Chooses activity type such as irrigation/fertilization/treatment; Enters date, product/amount and notes; System checks valid cycle and inputs; Stores actor/time and cycle linkage
- alternative_flows: Unknown cycle -> reject; Negative quantity -> reject; Invalid activity date -> reject
- postconditions: Cultivation timeline contains the new activity
- trigger: Farmer logs farm activity
- frequency: Not measured (coursework prototype)
- related_requirements: FR-014
- module_id: M02
- test_case_ids: TC-014
- web_implementation: record_cultivation
- _mod: M02

## test_cases

### TC-002 — Farm manager saves and retrieves farm profile

- related_requirements: FR-002
- type: Functional
- priority: Must
- preconditions: Empty database; user farm (Farm Manager).
- steps: 1 add_farm(F-001, Green Farm, Ha Noi, farm@example.test). 2 List farms. 3 Repeat add_farm with F-001. 4 add_farm with empty name.
- expected_result: Farm stored and listed; duplicate -> ConflictError; empty name -> ValidationError.
- status: PASS
- actual_result: Farm saved and listed (name=Green Farm); duplicate -> ConflictError; empty name -> ValidationError. Note: no update-farm function exists (create only).
- executed_by: Automated script run_detailed_tests.py (sandbox, local SQLite)
- executed_date: 2026-10-22
- module_id: M02
- test_data: F-001 / Green Farm / Ha Noi
- implementation_function: add_farm
- evidence_scope: Local SQLite scenario result
- _mod: M02

### TC-013 — Create cultivation cycle successfully

- related_requirements: FR-013
- type: Functional
- priority: Must
- preconditions: Farm F-001 exists.
- steps: 1 create_cycle C-1 (2026-01-01 to 2026-04-01). 2 End before start. 3 Unknown farm. 4 Duplicate id. 5 Invalid date 2026-13-01.
- expected_result: Cycle stored Active; each invalid input rejected with ValidationError/NotFoundError/ConflictError.
- status: PASS
- actual_result: Cycle C-1 stored with status Active; end<start -> ValidationError; unknown farm -> NotFoundError; duplicate id -> ConflictError; invalid date -> ValidationError.
- executed_by: Automated script run_detailed_tests.py (sandbox, local SQLite)
- executed_date: 2026-10-22
- module_id: M02
- test_data: C-1 Tomato Plot A
- implementation_function: create_cycle
- evidence_scope: Local SQLite scenario result
- _mod: M02

### TC-014 — Record cultivation activity successfully

- related_requirements: FR-014
- type: Functional
- priority: Must
- preconditions: Active cycle C-1.
- steps: 1 record_cultivation Fertilization 50 'NPK' on 2026-01-15. 2 Quantity -5. 3 Unknown cycle C-404.
- expected_result: Stored against C-1; negative -> ValidationError; unknown cycle -> NotFoundError.
- status: PASS
- actual_result: Fertilization 50 stored against C-1; negative quantity -> ValidationError; unknown cycle -> NotFoundError. Note: closed-cycle rejection (UC-15 alt 1a) cannot be tested: no function closes a cycle.
- executed_by: Automated script run_detailed_tests.py (sandbox, local SQLite)
- executed_date: 2026-10-22
- module_id: M02
- test_data: 50 kg; -5; C-404
- implementation_function: record_cultivation
- evidence_scope: Local SQLite scenario result
- _mod: M02


import sys, unittest, tempfile
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from service import create_service
from bootstrap import seed_demo
from modules.core import AgriTraceError,AuthorizationError

class ModuleTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory()
        self.s=create_service(Path(self.temp.name)/'test.sqlite3',Path(self.temp.name)/'qr')
        seed_demo(self.s,'M02')
    def tearDown(self):self.temp.cleanup()
    def test_create_farm(self):
        self.s.add_farm('farm','F-02','Demo Farm','Hà Nội','demo@mail.local');self.assertEqual(self.s._one('farms','farm_id','F-02')['name'],'Demo Farm')
    def test_duplicate_farm(self):
        with self.assertRaises(AgriTraceError):self.s.add_farm('farm','F-DEMO','Demo','Hà Nội','demo@mail.local')
    def test_create_cycle(self):
        self.s.create_cycle('farm','C-NEW','F-DEMO','P02','Tomato','2026-08-01','2026-10-20')
        self.assertEqual(self.s._one('cycles','cycle_id','C-NEW')['crop'],'Tomato')
    def test_invalid_date_order(self):
        with self.assertRaises(AgriTraceError):self.s.create_cycle('farm','C-BAD','F-DEMO','P02','Tomato','2026-10-20','2026-08-01')
    def test_record_activity(self):
        self.s.record_cultivation('farm','C-DEMO','Watering','2026-08-15',2,'Safe')
        with self.s._db() as conn:self.assertEqual(conn.execute('SELECT COUNT(*) FROM cultivation_events').fetchone()[0],1)
    def test_update_farm(self):
        self.s.update_farm('farm','F-DEMO','New Name','Hanoi','contact');self.assertEqual(self.s._one('farms','farm_id','F-DEMO')['name'],'New Name')
    def test_close_cycle(self):
        self.s.close_cycle('farm','C-DEMO');self.assertEqual(self.s._one('cycles','cycle_id','C-DEMO')['status'],'Closed')

if __name__=='__main__':unittest.main()

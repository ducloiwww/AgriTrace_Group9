import unittest,tempfile
from pathlib import Path
from service import create_service
from bootstrap import seed_demo
from modules.core import ValidationError,ConflictError,NotFoundError,AuthorizationError

class ReviewTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory()
        self.s=create_service(Path(self.temp.name)/'testing.sqlite3',Path(self.temp.name)/'qr')
        seed_demo(self.s,'M02')
    def tearDown(self):self.temp.cleanup()
    def new(self):return self.s.create_order('retailer','Retail-01','B-DEMO','A',20,'2026-11-01')
    def test_edit_farm_data(self):
        self.s.update_farm('farm','F-DEMO','New farm','Ha Noi','new@example.org')
        self.assertEqual(self.s._one('farms','farm_id','F-DEMO')['name'],'New farm')
    def test_reject_invalid_activity_date(self):
        with self.assertRaises(ValidationError):self.s.create_cycle('farm','C-ERR','F-DEMO','P-01','Tomato','2026-10-20','2026-10-01')


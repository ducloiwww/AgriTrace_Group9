"""AgriTrace modular SQLite business services.

Each mixin contains one cohesive responsibility; AgriTraceService composes them.
"""
from __future__ import annotations
from .core import (
    AgriTraceError, AuthorizationError, NotFoundError, ValidationError, ConflictError,
    ROLES, ROLE_ACTIONS, now_iso, _valid_date, _number, _valid_id, _required,
    hash_password, verify_password, sqlite3, secrets, json, datetime, date,
    timezone, math, re, hashlib, Path, Any
)

class FarmServiceMixin:
    def add_farm(self, actor: str, farm_id: str, name: str, region: str, contact: str) -> None:
        self._authorize(actor, "farm.write")
        farm_id = _valid_id(farm_id, "Mã trang trại")
        _required(Mã_trang_trại=farm_id, Tên_trang_trại=name, Khu_vực=region, Liên_hệ=contact)
        with self._db() as conn:
            if conn.execute("SELECT 1 FROM farms WHERE farm_id=?", (farm_id,)).fetchone():
                raise ConflictError("Mã trang trại đã tồn tại.")
            conn.execute("INSERT INTO farms VALUES(?,?,?,?,?,?)", (farm_id.strip(), name.strip(), region.strip(), contact.strip(), actor, now_iso()))
            self._audit(conn, actor, "farm.created", "farm", farm_id)

    def create_cycle(self, actor: str, cycle_id: str, farm_id: str, plot: str, crop: str, planting_date: str, expected_harvest: str) -> None:
        self._authorize(actor, "cycle.write")
        cycle_id = _valid_id(cycle_id, "Mã chu kỳ")
        farm_id = _valid_id(farm_id, "Mã trang trại")
        _required(Mã_chu_kỳ=cycle_id, Mã_trang_trại=farm_id, Lô_trồng=plot, Cây_trồng=crop)
        planted = _valid_date(planting_date, "Ngày trồng")
        harvest = _valid_date(expected_harvest, "Ngày dự kiến thu hoạch")
        if harvest < planted:
            raise ValidationError("Ngày dự kiến thu hoạch không được trước ngày trồng.")
        with self._db() as conn:
            if not conn.execute("SELECT 1 FROM farms WHERE farm_id=?", (farm_id,)).fetchone():
                raise NotFoundError("Không tìm thấy trang trại.")
            if conn.execute("SELECT 1 FROM cycles WHERE cycle_id=?", (cycle_id,)).fetchone():
                raise ConflictError("Mã chu kỳ đã tồn tại.")
            conn.execute("INSERT INTO cycles(cycle_id,farm_id,plot,crop,planting_date,expected_harvest,status,created_by,created_at) VALUES(?,?,?,?,?,?,'Active',?,?)",
                         (cycle_id, farm_id, plot.strip(), crop.strip(), planting_date, expected_harvest, actor, now_iso()))
            self._audit(conn, actor, "cycle.created", "cycle", cycle_id)

    def record_cultivation(self, actor: str, cycle_id: str, activity: str, event_date: str, quantity: float = 0, public_note: str = "") -> None:
        self._authorize(actor, "cultivation.write")
        _required(Mã_chu_kỳ=cycle_id, Hoạt_động=activity, Ngày=event_date)
        _valid_date(event_date, "Ngày hoạt động")
        quantity = _number(quantity, "Số lượng/vật tư")
        if quantity < 0:
            raise ValidationError("Số lượng/vật tư không được âm.")
        with self._db() as conn:
            cycle = conn.execute("SELECT * FROM cycles WHERE cycle_id=?", (cycle_id,)).fetchone()
            if not cycle:
                raise NotFoundError("Không tìm thấy chu kỳ trồng trọt.")
            if cycle["status"] != "Active":
                raise ConflictError("Chu kỳ không còn hoạt động.")
            if date.fromisoformat(event_date) < date.fromisoformat(cycle["planting_date"]):
                raise ValidationError("Ngày hoạt động không được trước ngày trồng.")
            cur = conn.execute("INSERT INTO cultivation_events(cycle_id,activity,event_date,quantity,public_note,created_by,created_at) VALUES(?,?,?,?,?,?,?)",
                               (cycle_id, activity.strip(), event_date, float(quantity), public_note.strip(), actor, now_iso()))
            self._audit(conn, actor, "cultivation.recorded", "cultivation_event", str(cur.lastrowid), cycle_id)


    def update_farm(self, actor: str, farm_id: str, name: str, region: str, contact: str) -> None:
        self._authorize(actor, "farm.write")
        _required(Tên_trang_trại=name, Khu_vực=region, Liên_hệ=contact)
        with self._db() as conn:
            if not conn.execute("SELECT 1 FROM farms WHERE farm_id=?", (farm_id,)).fetchone():
                raise NotFoundError("Không tìm thấy trang trại.")
            conn.execute("UPDATE farms SET name=?,region=?,contact=? WHERE farm_id=?", (name.strip(), region.strip(), contact.strip(), farm_id))
            self._audit(conn, actor, "farm.updated", "farm", farm_id)

    def close_cycle(self, actor: str, cycle_id: str) -> None:
        self._authorize(actor, "cycle.write")
        with self._db() as conn:
            cycle = conn.execute("SELECT status FROM cycles WHERE cycle_id=?", (cycle_id,)).fetchone()
            if not cycle:
                raise NotFoundError("Không tìm thấy chu kỳ trồng.")
            if cycle["status"] != "Active":
                raise ConflictError("Chu kỳ không còn hoạt động.")
            conn.execute("UPDATE cycles SET status='Closed' WHERE cycle_id=?", (cycle_id,))
            self._audit(conn, actor, "cycle.closed", "cycle", cycle_id)

"""Standalone smoke verification for M02; uses an isolated temporary SQLite database."""
import tempfile,json,traceback
from pathlib import Path
from service import create_service
from bootstrap import seed_demo

def verify():
    with tempfile.TemporaryDirectory() as td:
        s=create_service(Path(td)/'smoke.sqlite3',Path(td)/'qr')
        seed_demo(s,'M02')
        s.add_farm('farm','F-SMOKE','Demo farm','Ha Noi','demo@example.org')
        s.update_farm('farm','F-SMOKE','Updated farm','Ha Noi','demo@example.org')
        assert s._one('farms','farm_id','F-SMOKE')['name']=='Updated farm'
        from modules.core import ValidationError
        try:s.create_cycle('farm','C-INVALID','F-SMOKE','P','Tomato','2026-10-10','2026-09-10')
        except ValidationError:pass
        else:raise AssertionError('Bad dates must be rejected')
    return {'module':'M02','status':'PASS','scenario':'Quản lý trang trại và chu kỳ','positive_and_negative_checked':True}

if __name__=='__main__':
    try:result=verify()
    except Exception as e:
        result={'module':'M02','status':'FAIL','error':str(e)}
        traceback.print_exc()
    print(json.dumps(result,ensure_ascii=False,indent=2))
    if result['status']!='PASS':raise SystemExit(1)

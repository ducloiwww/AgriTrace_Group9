from modules.core import AgriTraceBase
from modules.accounts import AccountServiceMixin
from modules.farms import FarmServiceMixin

class AgriTraceService(FarmServiceMixin, AccountServiceMixin, AgriTraceBase):
    """Local composition: only the business methods required by M02."""
    pass

def create_service(db_path,qr_dir):
    return AgriTraceService(db_path,qr_dir)

# M02 — Functional Requirements

## FR-002 — Manage farm information
- description: The system shall allow an authorized Farm Manager to create and update farm profile information.
- type: Functional
- priority: Must
- status: Approved
- source: SH-01
- rationale: Source: Lab 7 updated requirement baseline; Labs 1-4 core workflow. See UC-02.
- acceptance_criteria: Valid farm information is persisted and retrievable.
- verification_method: Test
- complexity: 1
- dependencies: None
- tags: UC-02;full-supply-chain
- module_id: M02
- implementation_status: Implemented locally: create and update farm
- linked_use_cases: UC-02
- designed_test_cases: TC-002
- _mod: M02

## FR-013 — Manage cultivation cycle
- description: The system shall allow an authorized Farm Manager to create and maintain a cultivation cycle for each crop plot, including crop variety, planting date, expected harvest window, and growing status.
- type: Functional
- priority: Must
- status: Approved
- source: SH-01
- rationale: Source: Lab 7 updated requirement baseline; post-Lab-4 expansion. See UC-14.
- acceptance_criteria: A cultivation cycle is stored with a unique cycle ID and linked farm/plot.
- verification_method: Test
- complexity: 1
- dependencies: None
- tags: UC-14;full-supply-chain
- module_id: M02
- implementation_status: Implemented (no close-cycle)
- linked_use_cases: UC-14
- designed_test_cases: TC-013
- _mod: M02

## FR-014 — Record cultivation activities
- description: The system shall allow an authorized Farm Manager to record irrigation, fertilization, crop-protection treatment, and other cultivation activities against an active cultivation cycle.
- type: Functional
- priority: Must
- status: Approved
- source: SH-01
- rationale: Source: Lab 7 updated requirement baseline; post-Lab-4 expansion. See UC-15.
- acceptance_criteria: Each activity is timestamped and linked to the correct cultivation cycle.
- verification_method: Test
- complexity: 1
- dependencies: None
- tags: UC-15;full-supply-chain
- module_id: M02
- implementation_status: Implemented
- linked_use_cases: UC-15
- designed_test_cases: TC-014
- _mod: M02

# M02 — Test Cases

## TC-002 — Farm manager saves and retrieves farm profile
- related_requirements: FR-002
- type: Functional
- priority: Must
- preconditions: Empty database; user farm (Farm Manager).
- steps: 1 add_farm(F-001, Green Farm, Ha Noi, farm@example.test). 2 List farms. 3 Repeat add_farm with F-001. 4 add_farm with empty name.
- expected_result: Farm stored and listed; duplicate -> ConflictError; empty name -> ValidationError.
- status: PASS
- actual_result: Farm saved and listed (name=Green Farm); duplicate -> ConflictError; empty name -> ValidationError. Note: no update-farm function exists (create only).
- executed_by: Automated script run_detailed_tests.py (sandbox, local SQLite)
- executed_date: 2026-10-22
- module_id: M02
- test_data: F-001 / Green Farm / Ha Noi
- implementation_function: add_farm
- evidence_scope: Local SQLite scenario result
- _mod: M02

## TC-013 — Create cultivation cycle successfully
- related_requirements: FR-013
- type: Functional
- priority: Must
- preconditions: Farm F-001 exists.
- steps: 1 create_cycle C-1 (2026-01-01 to 2026-04-01). 2 End before start. 3 Unknown farm. 4 Duplicate id. 5 Invalid date 2026-13-01.
- expected_result: Cycle stored Active; each invalid input rejected with ValidationError/NotFoundError/ConflictError.
- status: PASS
- actual_result: Cycle C-1 stored with status Active; end<start -> ValidationError; unknown farm -> NotFoundError; duplicate id -> ConflictError; invalid date -> ValidationError.
- executed_by: Automated script run_detailed_tests.py (sandbox, local SQLite)
- executed_date: 2026-10-22
- module_id: M02
- test_data: C-1 Tomato Plot A
- implementation_function: create_cycle
- evidence_scope: Local SQLite scenario result
- _mod: M02

## TC-014 — Record cultivation activity successfully
- related_requirements: FR-014
- type: Functional
- priority: Must
- preconditions: Active cycle C-1.
- steps: 1 record_cultivation Fertilization 50 'NPK' on 2026-01-15. 2 Quantity -5. 3 Unknown cycle C-404.
- expected_result: Stored against C-1; negative -> ValidationError; unknown cycle -> NotFoundError.
- status: PASS
- actual_result: Fertilization 50 stored against C-1; negative quantity -> ValidationError; unknown cycle -> NotFoundError. Note: closed-cycle rejection (UC-15 alt 1a) cannot be tested: no function closes a cycle.
- executed_by: Automated script run_detailed_tests.py (sandbox, local SQLite)
- executed_date: 2026-10-22
- module_id: M02
- test_data: 50 kg; -5; C-404
- implementation_function: record_cultivation
- evidence_scope: Local SQLite scenario result
- _mod: M02

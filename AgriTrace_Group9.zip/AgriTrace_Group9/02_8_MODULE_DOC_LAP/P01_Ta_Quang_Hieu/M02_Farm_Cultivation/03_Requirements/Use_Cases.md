# M02 — Use Cases

## UC-02 — Manage Farm Information
- primary_actor: Farm Manager
- goal: Maintain accurate farm identity and origin data
- preconditions: User is signed in as Farm Manager
- main_flow: Farmer opens farm profile; Enters farm name, location and contact details; System checks required fields and authorization; System stores the new or updated profile; System writes an audit event
- alternative_flows: 3a Missing field -> ValidationError. 3b Duplicate ID -> ConflictError. 3c Invalid ID characters -> ValidationError. Update of an existing farm is not implemented (gap G-02).
- postconditions: Approved farm profile is retrievable and linked to origin records
- trigger: Farm Manager registers a new farm.
- frequency: Not measured (coursework prototype)
- related_requirements: FR-002
- module_id: M02
- test_case_ids: TC-002
- web_implementation: add_farm
- _mod: M02

## UC-14 — Manage Cultivation Cycle
- primary_actor: Farm Manager
- goal: Register the full cultivation cycle for a crop plot
- preconditions: Farm and crop plot are identifiable; farm role authorized
- main_flow: Farmer selects farm/plot; Enters crop variety and planting date; System validates timeline and plot link; Creates cultivation-cycle identifier; Stores initial stage and audit event
- alternative_flows: Unknown plot -> reject; Invalid planting date -> reject; Duplicate active cycle -> flag
- postconditions: Cultivation cycle links farm, plot and crop to later batch history
- trigger: Farmer creates cultivation cycle
- frequency: Not measured (coursework prototype)
- related_requirements: FR-013
- module_id: M02
- test_case_ids: TC-013
- web_implementation: create_cycle
- _mod: M02

## UC-15 — Record Cultivation Activity
- primary_actor: Farm Manager
- goal: Record treatments and growing activities by cultivation cycle
- preconditions: An active cultivation cycle exists
- main_flow: Farmer selects cycle; Chooses activity type such as irrigation/fertilization/treatment; Enters date, product/amount and notes; System checks valid cycle and inputs; Stores actor/time and cycle linkage
- alternative_flows: Unknown cycle -> reject; Negative quantity -> reject; Invalid activity date -> reject
- postconditions: Cultivation timeline contains the new activity
- trigger: Farmer logs farm activity
- frequency: Not measured (coursework prototype)
- related_requirements: FR-014
- module_id: M02
- test_case_ids: TC-014
- web_implementation: record_cultivation
- _mod: M02

# M02 — Quy tắc bổ sung

Sửa tên/vùng trang trại; ngày dự kiến không được trước ngày trồng.

Kiểm thử: `tests/test_review.py`, `verify_demo.py`. Đây là phần bổ sung, không thay thế đặc tả gốc.

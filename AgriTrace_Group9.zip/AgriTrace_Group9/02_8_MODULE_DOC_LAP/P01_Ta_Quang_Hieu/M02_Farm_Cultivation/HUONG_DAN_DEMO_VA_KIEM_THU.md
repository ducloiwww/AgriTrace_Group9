# M02 — Farm & Cultivation (29/10/2026)

- Vai trò demo: `farm` / `Farm@123`.
- Quy tắc: Sửa tên/vùng trang trại; ngày dự kiến không được trước ngày trồng.
- Luồng: thêm trang trại → tạo chu kỳ → sửa trang trại → thử ngày sai.
- Chạy web: `python app.py`; kiểm thử: `python run_tests.py`, `python verify_demo.py`.
- Dữ liệu demo dùng riêng module, không đồng bộ module khác.

P01_Ta_Quang_Hieu - Tạ Quang Hiếu
Hai module chạy hoàn toàn riêng, không dùng một app/database chung.
Cứ vào mỗi thư mục Mxx/01_Python_Source rồi nhấp đúp run_windows.bat.

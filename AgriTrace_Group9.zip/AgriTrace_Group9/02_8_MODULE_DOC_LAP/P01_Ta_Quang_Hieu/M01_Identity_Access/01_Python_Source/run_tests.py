import subprocess,sys
from pathlib import Path
root=Path(__file__).resolve().parent
sys.exit(subprocess.call([sys.executable,'-m','unittest','discover','-s','tests','-v'],cwd=root))

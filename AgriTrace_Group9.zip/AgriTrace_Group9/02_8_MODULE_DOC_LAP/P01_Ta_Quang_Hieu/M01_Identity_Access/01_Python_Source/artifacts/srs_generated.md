# M01 Standalone Requirements Index

## functional_requirements

### FR-001 — Role-based access control

- description: The system shall authenticate registered operational users and restrict protected data-modification functions according to assigned roles.
- type: Functional
- priority: Must
- status: Approved
- source: SH-07
- rationale: Source: Lab 7 updated requirement baseline; Labs 1-4 core workflow. See UC-01.
- acceptance_criteria: Unauthorized users cannot modify protected supply-chain records.
- verification_method: Test
- complexity: 1
- dependencies: None
- tags: UC-01;full-supply-chain
- module_id: M01
- implementation_status: Implemented
- linked_use_cases: UC-01
- designed_test_cases: TC-001
- _mod: M01

## use_cases

### UC-01 — Authenticate User

- primary_actor: Operational User
- goal: Sign in and establish an authorized session
- preconditions: An active user account with an assigned role exists
- main_flow: 1 System shows login form with CSRF token. 2 User enters username and password. 3 System verifies password against salted PBKDF2-HMAC-SHA256 hash. 4 System creates an in-memory session and shows the role-specific page. 5 Each later action checks ROLE_ACTIONS before running.
- alternative_flows: 3a Wrong password or unknown user -> login refused, no session. 5a Action not in role's permission set -> AuthorizationError, data unchanged. 5b Account inactive -> AuthorizationError.
- postconditions: Authenticated session exists with appropriate permissions
- trigger: User submits username and password on the login page.
- frequency: Not measured (coursework prototype)
- related_requirements: FR-001
- module_id: M01
- test_case_ids: TC-001
- web_implementation: authenticate / _authorize / ROLE_ACTIONS
- _mod: M01

## test_cases

### TC-001 — Unauthorized operator cannot modify protected records

- related_requirements: FR-001
- type: Security / access control
- priority: Must
- preconditions: Farm F-001 and batch B-001 exist. Users farm, retailer exist; user 'ghost' does not.
- steps: 1 Call add_farm as retailer. 2 Call recall_batch as farm. 3 Call receive_inventory as farm. 4 Call add_farm as unknown user ghost. 5 List farms.
- expected_result: Each call raises AuthorizationError; farms table unchanged (1 row).
- status: PASS
- actual_result: 4 unauthorized calls rejected (AuthorizationError, AuthorizationError, AuthorizationError, AuthorizationError); farms table still 1 row.
- executed_by: Automated script run_detailed_tests.py (sandbox, local SQLite)
- executed_date: 2026-10-22
- module_id: M01
- test_data: actors: retailer, farm, ghost; F-9/B-001
- implementation_function: authenticate / _authorize / ROLE_ACTIONS
- evidence_scope: Local SQLite scenario result
- _mod: M01



"""Read module SRS records and export a designed FR/UC/TC traceability matrix.
This is NOT evidence that each test case has been automated or executed in the isolated app.
"""
import json,csv
from pathlib import Path
ROOT=Path(__file__).resolve().parent
spec=json.loads((ROOT.parent/'03_Requirements'/'specification.json').read_text(encoding='utf-8'))
output=ROOT/'artifacts';output.mkdir(exist_ok=True)
frs=spec.get('functional_requirements',[])
ucs=spec.get('use_cases',[])
tcs=spec.get('test_cases',[])
with (output/'traceability_matrix.csv').open('w',encoding='utf-8-sig',newline='') as f:
 w=csv.writer(f);w.writerow(['module','FR','FR title','UC IDs (designed)','TC IDs (designed)','standalone run evidence'])
 for fr in frs:
  fid=fr.get('id','')
  uc=[x.get('id','') for x in ucs if fid in str(x.get('related_requirements','')) or x.get('id','') in str(fr.get('linked_use_cases',''))]
  tc=[x.get('id','') for x in tcs if fid in str(x.get('related_requirements',''))]
  w.writerow([spec.get('module_ids',[''])[0],fid,fr.get('title',''),'; '.join(uc),'; '.join(tc),'See 02_Test_Logs/unit_tests_result.txt (not 1:1 TC mapping)'])
with (output/'srs_generated.md').open('w',encoding='utf-8') as f:
 f.write('# '+spec.get('module_ids',[''])[0]+' Standalone Requirements Index\n\n')
 for key in ('functional_requirements','use_cases','test_cases'):
  f.write('## '+key+'\n\n')
  for rec in spec.get(key,[]):
   f.write('### '+rec.get('id','')+' — '+rec.get('title','')+'\n\n')
   for k,v in rec.items():
    if k not in ('id','title'):f.write('- '+k+': '+str(v)+'\n')
   f.write('\n')
print('Saved:',output/'traceability_matrix.csv',output/'srs_generated.md')
print('Designed counts:',len(frs),'FR;',len(ucs),'UC;',len(tcs),'TC. Executed unit tests are separate evidence.')

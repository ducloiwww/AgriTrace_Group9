"""Generate self-contained, clearly labelled DEMO fixtures; no other module required."""
from modules.core import now_iso

def seed_demo(service, module_id):
    if module_id == 'M01':
        return
    with service._db() as conn:
        conn.execute("INSERT OR IGNORE INTO farms(farm_id,name,region,contact,created_by,created_at) VALUES('F-DEMO','Trang trại DEMO','Hà Nội','demo@agritrace.local','farm',?)",(now_iso(),))
        conn.execute("INSERT OR IGNORE INTO cycles(cycle_id,farm_id,plot,crop,planting_date,expected_harvest,status,created_by,created_at) VALUES('C-DEMO','F-DEMO','P-01','Tomato','2026-08-01','2026-10-20','Active','farm',?)",(now_iso(),))
        if module_id in {'M02','M03'}:
            return
        state = 'Sorted' if module_id == 'M04' else 'Approved'
        passed_inspection = 'Pending' if module_id == 'M04' else 'Passed'
        proc_facility = None if module_id == 'M04' else 'AgriTrace Demo Packing'
        conn.execute("""INSERT OR IGNORE INTO batches(batch_id,cycle_id,harvest_date,harvest_qty,grade_a,grade_b,grade_c,rejected_qty,status,inspection_status,process_facility,processing_date,packaging_date,package_details,created_by,created_at)
                     VALUES('B-DEMO','C-DEMO','2026-10-20',100,60,25,10,5,?,?,?,?,?,?,'farm',?)""",
            (state, passed_inspection, proc_facility, '2026-10-21' if proc_facility else None, '2026-10-22' if proc_facility else None,'Thùng 5 kg' if proc_facility else None,now_iso()))
        if module_id in {'M04','M05'}: return
        conn.execute("INSERT OR IGNORE INTO inventory(batch_id,grade,on_hand,reserved,received_total,last_received_at,last_location) VALUES('B-DEMO','A',60,0,60,?,'Main warehouse')",(now_iso(),))
        if module_id == 'M06':return
        conn.execute("INSERT OR IGNORE INTO orders(order_id,retailer_id,batch_id,grade,quantity,status,created_by,created_at) VALUES('ORD-DEMO','FreshMart','B-DEMO','A',20,'Packed','retailer',?)",(now_iso(),))
        conn.execute("INSERT OR IGNORE INTO allocations(order_id,batch_id,grade,quantity,created_by,created_at) SELECT 'ORD-DEMO','B-DEMO','A',20,'warehouse',? WHERE NOT EXISTS (SELECT 1 FROM allocations WHERE order_id='ORD-DEMO')",(now_iso(),))
        if module_id == 'M07':
            conn.execute("UPDATE inventory SET reserved=20 WHERE batch_id='B-DEMO' AND grade='A' AND NOT EXISTS (SELECT 1 FROM shipments WHERE order_id='ORD-DEMO')")
        if module_id == 'M08':
            conn.execute("INSERT OR IGNORE INTO shipments(shipment_id,order_id,batch_id,quantity,destination,status,created_by,created_at,delivered_at) VALUES('SHP-DEMO','ORD-DEMO','B-DEMO',20,'FreshMart Ha Noi','Delivered','logistics',?,?)",(now_iso(),now_iso()))
            conn.execute("INSERT INTO shipment_events(shipment_id,event_type,location,note,event_at,created_by) SELECT 'SHP-DEMO','Delivered','FreshMart Ha Noi','Demo delivery',?,'logistics' WHERE NOT EXISTS (SELECT 1 FROM shipment_events WHERE shipment_id='SHP-DEMO')",(now_iso(),))
            conn.execute("UPDATE orders SET status='Received',received_qty=20,received_at=? WHERE order_id='ORD-DEMO' AND status='Packed'",(now_iso(),))

"""Run data-driven AgriTrace scenarios against REAL service methods with isolated SQLite.

Every case creates a separate temporary database; nothing in data/module.sqlite3 is changed.
The dataset lists preconditions, input steps and postcondition checks. The runner records
actual values and errors before deciding PASS/FAIL. No results are hardcoded.
"""
from __future__ import annotations
import argparse, json, os, sqlite3, sys, tempfile, traceback
from datetime import datetime, timezone
from pathlib import Path
from collections import Counter
from service import create_service
from bootstrap import seed_demo

HERE=Path(__file__).resolve().parent
MODULE=json.loads((HERE/'catalog.json').read_text(encoding='utf-8'))['id']
SOURCE=HERE.parent/'03_Requirements'/'test_data_cases.json'
LOG_DIR=HERE.parent/'02_Test_Logs'

def get_nested(obj,path):
    for key in path.split('.'):
        if isinstance(obj,dict): obj=obj[key]
        elif isinstance(obj,list):obj=obj[int(key)]
        else:obj=getattr(obj,key)
    return obj

def resolve(value,vars):
    if isinstance(value,str) and value.startswith('$'):return vars[value[1:]]
    return value

def compare(actual,expected):
    if isinstance(expected,bool):return actual is expected or actual == expected
    if isinstance(expected,(float,int)) and not isinstance(expected,bool):return isinstance(actual,(int,float)) and abs(float(actual)-float(expected))<1e-8
    return actual == expected

def run_one(case):
    log=[];saved={};last=None
    with tempfile.TemporaryDirectory(prefix='agritrace_data_test_') as tmp:
        svc=create_service(Path(tmp)/'scenario.sqlite3',Path(tmp)/'qr')
        seed_demo(svc, MODULE)
        def dbrow(table,where):
            if table not in {'users','farms','cycles','batches','inventory','orders','shipments','cultivation_events','audit_log','shipment_events','allocations'}:raise AssertionError('Table not allowed')
            if not where: raise AssertionError('WHERE required')
            if any(not k.replace('_','').isalnum() for k in where): raise AssertionError('Invalid column')
            cols=' AND '.join(f'{k}=?' for k in where)
            with svc._db() as conn:
                return conn.execute(f'SELECT * FROM {table} WHERE {cols} LIMIT 1',list(where.values())).fetchone()
        try:
            log.append({'kind':'precondition','description':case['precondition_description'],'status':'FIXTURE_CREATED','database':'TEMPORARY SQLite, unique for this test'})
            for index,step in enumerate(case['steps'],1):
                op=step['op']; expected=step.get('expect_error')
                if op=='call':
                    args=[resolve(a,saved) for a in step.get('args',[])]
                    method=step['method']
                    try:
                        last=getattr(svc,method)(*args)
                        if expected:raise AssertionError(f'{method} should raise {expected} but succeeded')
                        if 'save_as' in step: saved[step['save_as']]=last
                        if 'expect_return' in step and not compare(last,step['expect_return']):raise AssertionError(f'Return expected {step["expect_return"]!r}, actual {last!r}')
                        log.append({'step':index,'kind':'call','method':method,'input':args,'expected_error':None,'actual':'SUCCESS','returned':str(last)[:200]})
                    except Exception as exc:
                        if expected and type(exc).__name__==expected:
                            log.append({'step':index,'kind':'call','method':method,'input':args,'expected_error':expected,'actual_error':type(exc).__name__,'error_message':str(exc),'status':'EXPECTED_ERROR'})
                            last=None
                        else:raise
                elif op in ('assert_row','assert_absent','assert_count'):
                    where={k:resolve(v,saved) for k,v in step.get('where',{}).items()}
                    if op=='assert_count':
                        query=' AND '.join(f'{k}=?' for k in where)
                        with svc._db() as conn:
                            actual=conn.execute(f'SELECT count(*) FROM {step["table"]} WHERE {query}',list(where.values())).fetchone()[0]
                        expected_value=step['equals']
                    else:
                        row=dbrow(step['table'],where)
                        actual=(row[step['field']] if row is not None else None) if op=='assert_row' else row is None
                        expected_value=step['equals'] if op=='assert_row' else True
                    if not compare(actual,expected_value):raise AssertionError(f'{op} {step["table"]} {where}: expected={expected_value!r}, actual={actual!r}')
                    log.append({'step':index,'kind':'postcondition','table':step['table'],'where':where,'field':step.get('field'), 'expected':expected_value,'actual':actual,'status':'PASS'})
                elif op=='fixture_update':
                    fields=step['set'];where=step['where']
                    if not fields or not where:raise AssertionError('Missing fixture fields')
                    sets=', '.join(f'{k}=?' for k in fields);w=' AND '.join(f'{k}=?' for k in where)
                    with svc._db() as conn: c=conn.execute(f'UPDATE {step["table"]} SET {sets} WHERE {w}',list(fields.values())+list(where.values()))
                    if c.rowcount != 1:raise AssertionError('Fixture update rowcount not 1')
                    log.append({'step':index,'kind':'fixture','table':step['table'],'set':fields,'status':'APPLIED'})
                elif op=='assert_last_return':
                    actual=get_nested(last,step['path'])
                    if not compare(actual,step['equals']):raise AssertionError(f'return.{step["path"]}: expected {step["equals"]!r}, actual={actual!r}')
                    log.append({'step':index,'kind':'postcondition','path':step['path'],'expected':step['equals'],'actual':actual,'status':'PASS'})
                elif op=='assert_last_none':
                    if last is not None:raise AssertionError(f'Expected None, actual {last!r}')
                    log.append({'step':index,'kind':'postcondition','expected':None,'actual':None,'status':'PASS'})
                elif op=='assert_last_nonempty':
                    if not last:raise AssertionError('Expected nonempty response')
                    log.append({'step':index,'kind':'postcondition','expected':'non-empty','actual':f'{len(last)} items','status':'PASS'})
                else:raise AssertionError(f'Unknown test op {op}')
            passed=True;failure=''
        except Exception as e:
            passed=False;failure=f'{type(e).__name__}: {e}'
            log.append({'kind':'failure','message':failure,'traceback':traceback.format_exc(limit=3)})
    return {'case_id':case['case_id'],'module':MODULE,'fr':case.get('fr_reference'),'uc':case.get('uc_reference'),'description':case['description'],'type':case['type'],'precondition':case['precondition_description'],'expected_postcondition':case['expected_postcondition_description'],'status':'PASS' if passed else 'FAIL','failure':failure,'execution_steps':log}

def run_cases(cases,log_files=True):
    results=[run_one(case) for case in cases]
    outcome={'module':MODULE,'generated_at':datetime.now(timezone.utc).isoformat(),'dataset_file':str(SOURCE.relative_to(HERE.parent)),'run_on':'fresh isolated SQLite per scenario','total':len(results),'pass':sum(r['status']=='PASS' for r in results),'fail':sum(r['status']=='FAIL' for r in results),'results':results}
    if log_files:
        LOG_DIR.mkdir(parents=True,exist_ok=True)
        (LOG_DIR/'data_driven_results.json').write_text(json.dumps(outcome,ensure_ascii=False,indent=2),encoding='utf-8')
        lines=[f'{MODULE} DATA-DRIVEN TEST LOG',f'Executed: {outcome["generated_at"]}',f'PASS: {outcome["pass"]}/{outcome["total"]}',f'FAIL: {outcome["fail"]}','']
        for r in results:
            lines.extend([f'[{r["status"]}] {r["case_id"]}: {r["description"]}',f'FR: {r["fr"]} | UC: {r["uc"]}',f'PRECONDITION: {r["precondition"]}',f'EXPECTED POSTCONDITION: {r["expected_postcondition"]}'])
            for ev in r['execution_steps']:
                if ev.get('kind')=='postcondition':lines.append(f'  EXPECTED: {ev.get("expected")!r} | ACTUAL: {ev.get("actual")!r} | {ev.get("status")}')
                elif ev.get('kind')=='call':lines.append(f'  CALL {ev["method"]} {ev.get("status") or ev.get("actual")}; expected error {ev.get("expected_error")}; actual error {ev.get("actual_error")}')
            if r['failure']:lines.append('FAILURE: '+r['failure'])
            lines.append('')
        (LOG_DIR/'data_driven_execution.log').write_text('\n'.join(lines),encoding='utf-8')
    return outcome

def main():
    parser=argparse.ArgumentParser(description='Data-driven tests: real service calls using temporary SQLite.')
    parser.add_argument('--list',action='store_true',help='List all data-driven test ids')
    parser.add_argument('--case',default='',help='Run a specific test, e.g. DT-M05-01')
    args=parser.parse_args()
    data=json.loads(SOURCE.read_text(encoding='utf-8'))
    cases=data['cases']
    if args.list:
        for c in cases:print(c['case_id'],c['description'],f'[{c.get("excel_reference","")}]')
        return 0
    if args.case:cases=[c for c in cases if c['case_id']==args.case]
    if not cases:print('No matching test case',file=sys.stderr);return 2
    out=run_cases(cases)
    for r in out['results']:
        print(f'[{r["status"]}] {r["case_id"]} — {r["description"]}')
        if r['failure']:print('   ',r['failure'])
    print(f'FINAL: {MODULE} {out["pass"]}/{out["total"]} PASS | {out["fail"]} FAIL')
    print('Log:',LOG_DIR/'data_driven_execution.log')
    return 0 if out['fail']==0 else 1

if __name__=='__main__':sys.exit(main())

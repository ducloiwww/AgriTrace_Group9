from modules.core import AgriTraceBase
from modules.accounts import AccountServiceMixin

class AgriTraceService(AccountServiceMixin, AgriTraceBase):
    """Local composition: only the business methods required by M01."""
    pass

def create_service(db_path,qr_dir):
    return AgriTraceService(db_path,qr_dir)

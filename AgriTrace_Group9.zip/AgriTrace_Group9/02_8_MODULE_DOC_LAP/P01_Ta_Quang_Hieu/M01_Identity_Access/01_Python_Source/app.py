# Independent local web interface, built only with Python standard library.
import argparse, html, json, secrets, sys, urllib.parse
from http import cookies
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from service import create_service
from bootstrap import seed_demo
from modules.core import AgriTraceError, AuthorizationError

ROOT=Path(__file__).resolve().parent
CONF=json.loads((ROOT/'catalog.json').read_text(encoding='utf-8'))
DB=ROOT/'data'/'module.sqlite3'
SERVICE=create_service(DB,ROOT/'data'/'qr')
seed_demo(SERVICE,CONF['id'])
SESSIONS={}
OP_ACTIONS={'create_user': 'account.admin', 'update_user': 'account.admin', 'add_farm': 'farm.write', 'update_farm': 'farm.write', 'create_cycle': 'cycle.write', 'record_cultivation': 'cultivation.write', 'close_cycle': 'cycle.write', 'create_batch': 'batch.create', 'record_harvest': 'harvest.write', 'revise_harvest': 'harvest.write', 'grade_harvest': 'grading.write', 'record_processing': 'processing.write', 'revise_processing': 'processing.write', 'inspect_quality': 'quality.write', 'receive_inventory': 'inventory.receive', 'adjust_inventory': 'inventory.adjust', 'update_stock_location': 'inventory.adjust', 'create_order': 'order.write', 'update_order': 'order.write', 'confirm_order': 'order.confirm', 'allocate_order': 'order.allocate', 'pack_order': 'order.pack', 'cancel_order': 'order.cancel', 'create_shipment': 'shipment.write', 'update_shipment_destination': 'shipment.write', 'update_shipment_status': 'shipment.write', 'record_temperature': 'temperature.write', 'confirm_receipt': 'receipt.write', 'generate_qr': 'trace.generate', 'recall_batch': 'recall.write', 'release_safety_hold': 'safety.review'}
EDIT_CONFIG={'M01': ('users', 'username', 'update_user'), 'M02': ('farms', 'farm_id', 'update_farm'), 'M03': ('batches', 'batch_id', 'revise_harvest'), 'M04': ('batches', 'batch_id', 'revise_processing'), 'M05': ('inventory', 'batch_id', 'update_stock_location'), 'M06': ('orders', 'order_id', 'update_order'), 'M07': ('shipments', 'shipment_id', 'update_shipment_destination')}

def esc(v): return html.escape(str(v if v is not None else ''), quote=True)

def test_data_section():
    """Read-only review: original Excel TC and executable fixture test data.
    Displays historical Excel status as historical, never as the new test result.
    """
    from html import escape as hx
    req=ROOT.parent/'03_Requirements'
    legacy=json.loads((req/'excel_test_cases.json').read_text(encoding='utf-8'))['cases']
    dataset=json.loads((req/'test_data_cases.json').read_text(encoding='utf-8'))['cases']
    chunks=['<section class="card"><h2>Test Cases gốc từ Excel</h2>',
        '<p class="hint">Nguồn: Master Dataset → sheet test_cases. Trạng thái PASS trong Excel là kết quả lịch sử, không phải kết quả lần kiểm thử này. Dữ liệu trong Excel (ví dụ B-001) có thể khác fixture của app (B-DEMO).</p>']
    for row in legacy:
        chunks.append('<details class="card"><summary><b>'+esc(row.get('id'))+' — '+esc(row.get('title'))+'</b> ('+esc(row.get('related_requirements'))+')</summary>')
        for label,key in [('Precondition','preconditions'),('Input Excel','test_data'),('Steps','steps'),('Expected result','expected_result'),('Trạng thái lịch sử trong Excel','status')]:
            chunks.append('<p><b>'+esc(label)+':</b> '+esc(row.get(key))+'</p>')
        chunks.append('</details>')
    chunks.append('</section><section class="card"><h2>Bộ đầu vào chạy được trên app độc lập</h2>')
    chunks.append('<p class="hint">Các kịch bản DT-* sử dụng SQLite tạm, tự dựng dữ liệu ban đầu, gọi Python thật và so sánh Expected/Actual. Chạy ở terminal: <code>python run_data_tests.py</code> hoặc <code>python run_data_tests.py --case DT-'+esc(CONF['id'])+'-01</code>. Không thay đổi cơ sở dữ liệu website.</p>')
    for case in dataset:
        chunks.append('<details class="card"><summary><b>'+esc(case['case_id'])+' — '+esc(case['description'])+'</b> ('+esc(case.get('excel_reference',''))+')</summary>')
        chunks.append('<p><b>Loại:</b> '+esc(case['type'])+' | <b>FR:</b> '+esc(case['fr_reference'])+' | <b>UC:</b> '+esc(case['uc_reference'])+'</p>')
        chunks.append('<p><b>Precondition:</b> '+esc(case['precondition_description'])+'</p>')
        chunks.append('<ol>')
        for step in case['steps']:
            if step['op']=='call':
                desc=step['method']+'('+', '.join(str(a) for a in step.get('args',[]))+')'
                if 'expect_error' in step:desc+=' → kỳ vọng lỗi '+step['expect_error']
            else:desc=step['op']+' '+json.dumps({k:v for k,v in step.items() if k!='op'},ensure_ascii=False)
            chunks.append('<li><code>'+esc(desc)+'</code></li>')
        chunks.append('</ol><p><b>Expected postcondition:</b> '+esc(case['expected_postcondition_description'])+'</p>')
        chunks.append('</details>')
    chunks.append('</section>')
    return ''.join(chunks)

def render(title, body):
    return f'''<!doctype html><html lang="vi"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
    <title>{esc(title)} - AgriTrace</title><style>
    :root{{--bg:#f4f7fb;--ink:#1b293c;--blue:#164a80;--card:#fff;--muted:#58677c}}
    *{{box-sizing:border-box}}body{{font-family:system-ui,Segoe UI,Arial,sans-serif;background:var(--bg);color:var(--ink);margin:0}}
    header{{background:#102942;color:white;padding:20px 5%}}main{{max-width:1240px;margin:24px auto;padding:0 18px}}
    .card{{background:var(--card);border:1px solid #dce4ed;border-radius:12px;padding:20px;margin:15px 0;box-shadow:0 2px 4px #163b6511}}
    h1{{font-size:27px;margin:0}}small,.muted{{color:var(--muted)}}header small{{color:#c7d6e7}}h2{{margin-top:0;font-size:20px}}
    form{{display:grid;grid-template-columns:repeat(auto-fit,minmax(185px,1fr));gap:12px}}.field{{display:flex;flex-direction:column;gap:6px}}
    input,select{{font:inherit;width:100%;padding:10px;border:1px solid #bac8d6;border-radius:7px}}button{{background:var(--blue);color:white;border:0;border-radius:7px;padding:10px 16px;cursor:pointer}}
    .notice{{padding:12px;border-radius:7px;background:#e7f4e8;white-space:pre-wrap}}.error{{background:#ffe3e3}}
    details{{background:var(--card);border:1px solid #dce4ed;border-radius:12px;margin:12px 0;padding:14px}}
    summary{{font-weight:650;cursor:pointer;padding:5px}}details .card{{border:0;box-shadow:none;margin:0;padding:14px 2px}}
    .hint{{font-size:13px;color:#41546a}}.query{{display:flex;align-items:end;gap:12px;flex-wrap:wrap}}
    .query label{{min-width:260px;flex:1}}.mutedbutton{{background:#e4eefa;color:#11395e;border:1px solid #b8cae0;padding:7px 12px;border-radius:6px}}
    table{{border-collapse:collapse;width:100%;font-size:13px}}td,th{{border:1px solid #e2e7eb;padding:8px;text-align:left;vertical-align:top;word-break:break-word}}th{{background:#eef4fc}}.scroll{{overflow:auto}}
    a{{color:var(--blue)}}.bar{{display:flex;gap:14px;align-items:center;flex-wrap:wrap}}.bar form{{display:inline}}
    </style></head><body><header><h1>{esc(CONF['id'])} · {esc(CONF['title'])}</h1><small>AgriTrace | Demo module độc lập · Cơ sở dữ liệu riêng · Cổng {esc(CONF['port'])}</small></header><main>{body}</main></body></html>'''

def table_html(table, search='', editor=None):
    # Table names always originate from local catalog; never use browser input as a SQL identifier.
    with SERVICE._db() as conn:
        rows=[dict(r) for r in conn.execute('SELECT * FROM '+table+' ORDER BY rowid DESC LIMIT 300')]
    if search: rows=[r for r in rows if search.casefold() in ' '.join(str(v) for k,v in r.items() if 'password' not in k).casefold()]
    if not rows:return '<p class="muted">Không có bản ghi phù hợp.</p>'
    cols=[k for k in rows[0] if k not in ('password_hash', 'qr_token')]
    if table=='inventory':cols+=['available']
    out='<p class="hint">'+str(len(rows))+' bản ghi hiển thị · tối đa 300 bản ghi gần nhất</p>'
    out+='<div class="scroll"><table><tr>'+''.join('<th>'+esc(c)+'</th>' for c in cols)+'</tr>'
    if editor and table==editor[0]:out+='<th>Chỉnh sửa</th>'
    for row in rows:
        out+='<tr>'
        for col in cols:
            v=round(float(row.get('on_hand') or 0)-float(row.get('reserved') or 0),3) if col=='available' else row.get(col)
            out+='<td>'+esc(v)+'</td>'
        if editor and table==editor[0]:
            key=row[editor[1]]
            out+='<td><a class="mutedbutton" href="/?edit='+urllib.parse.quote(editor[2])+'&key='+urllib.parse.quote(str(key))+(('&grade='+urllib.parse.quote(str(row['grade']))) if table=='inventory' else '')+'">Sửa</a></td>'
        out+='</tr>'
    return out+'</table></div>'

def form_html(f,csrf,values=None,opened=False):
    values=values or {}
    fields=''
    for name,label,typ,default in f['fields']:
        current=str(values.get(name,default))
        if typ=='select':
            opts=CONF['selects'][name]
            element='<select name="'+esc(name)+'">'+''.join('<option value="'+esc(o)+'" '+('selected' if o==current else '')+'>'+esc(o)+'</option>' for o in opts)+'</select>'
        else:
            t={'number':'number','optional_number':'number','password':'password','date':'date'}.get(typ,'text')
            extra=' step="any"' if t=='number' else ''
            # Never redisplay a submitted password.
            value='' if t=='password' else current
            element='<input name="'+esc(name)+'" type="'+t+'" value="'+esc(value)+'"'+extra+(' required' if typ!='optional_number' else '')+'>'
        fields+='<label class="field">'+esc(label)+element+'</label>'
    return '<details '+('open' if opened else '')+'><summary>'+esc(f['title'])+'</summary><section class="card"><form method="post" action="/action"><input type="hidden" name="csrf" value="'+esc(csrf)+'"><input type="hidden" name="operation" value="'+esc(f['method'])+'">'+fields+'<div class="field" style="justify-content:end"><button>Kiểm tra và lưu</button></div></form></section></details>'

def prefilling(f, key, grade):
    if not key:return {}
    defaults={name:default for name,_,_,default in f['fields']}
    table={x[2]:x[0] for x in EDIT_CONFIG.values()}.get(f['method'])
    column={x[2]:x[1] for x in EDIT_CONFIG.values()}.get(f['method'])
    if not table:return defaults
    # Bind all row values with parameters; edit links cannot choose tables or columns.
    with SERVICE._db() as conn:
        if table=='inventory':r=conn.execute('SELECT * FROM inventory WHERE batch_id=? AND grade=?',(key,grade)).fetchone()
        else:r=conn.execute('SELECT * FROM '+table+' WHERE '+column+'=?',(key,)).fetchone()
    if not r:return defaults
    fields=dict(r)
    aliases={'name':'name','location':'last_location','quantity':'harvest_qty' if table=='batches' and f['method']=='revise_harvest' else 'quantity',
             'facility':'process_facility','requested_delivery_date':'requested_delivery_date'}
    for name in defaults:
        source=aliases.get(name,name)
        if source in fields and fields[source] is not None:defaults[name]=str(fields[source])
    return defaults

def public_trace(q):
    try:
        result=SERVICE.trace(q)
        b=result['batch']; public_keys=['batch_id','crop','farm_name','region','harvest_date','harvest_qty','inspection_status','recalled','review_hold']
        summary='<p>'+ ' · '.join(esc(k)+': <strong>'+esc(b.get(k))+'</strong>' for k in public_keys)+'</p>'
        allowed={'Tạo lô','Canh tác','Thu hoạch','Phân loại','Chế biến','Đóng gói','Kiểm định chất lượng','CẢNH BÁO THU HỒI','Đánh giá an toàn'}
        events='<ol>'+''.join('<li>'+esc(ev.get('time',''))+' — <b>'+esc(ev.get('event',''))+'</b>: '+esc(ev.get('detail',''))+'</li>' for ev in result['timeline'] if ev.get('event') in allowed)+'</ol>'
        qr=b.get('qr_token')
        if qr:summary+='<p><img src="/qr?token='+urllib.parse.quote(qr)+'" width="185" height="185" alt="QR truy xuất lô"></p>'
        return '<section class="card"><h2>Truy xuất công khai</h2>'+summary+events+'</section>'
    except Exception as e:
        return '<p class="notice error">'+esc(e)+'</p>'

class Handler(BaseHTTPRequestHandler):
    def session(self):
        c=cookies.SimpleCookie()
        try:c.load(self.headers.get('Cookie',''))
        except cookies.CookieError:return None
        sid=c.get('sid')
        return SESSIONS.get(sid.value) if sid else None
    def send_html(self,body,status=200,headers=None):
        out=body.encode('utf-8')
        self.send_response(status)
        self.send_header('Content-Type','text/html; charset=utf-8')
        self.send_header('Content-Length',str(len(out)))
        self.send_header('X-Content-Type-Options','nosniff')
        self.send_header('Cache-Control','no-store')
        self.send_header('Content-Security-Policy',"default-src 'self'; style-src 'unsafe-inline'")
        for k,v in (headers or {}).items():self.send_header(k,v)
        self.end_headers();self.wfile.write(out)
    def redirect(self,url,cookie=None):
        self.send_response(303);self.send_header('Location',url)
        if cookie:self.send_header('Set-Cookie',cookie)
        self.end_headers()
    def do_GET(self):
        parsed=urllib.parse.urlsplit(self.path)
        params=urllib.parse.parse_qs(parsed.query)
        if parsed.path=='/qr' and CONF['id']=='M08':
            try:
                import qrcode,io
                token=params.get('token',[''])[0]
                if SERVICE.trace(token)['batch']['qr_token']!=token:raise ValueError('Token invalid')
                png=qrcode.make('http://127.0.0.1:'+str(CONF['port'])+'/trace?q='+urllib.parse.quote(token))
                out=io.BytesIO();png.save(out,format='PNG');data=out.getvalue()
                self.send_response(200);self.send_header('Content-Type','image/png');self.send_header('Content-Length',str(len(data)));self.end_headers();self.wfile.write(data);return
            except Exception as e:
                self.send_html(render('QR','<p>Cần cài: python -m pip install qrcode[pil].</p>'),400);return
        if parsed.path=='/trace' and CONF['id']=='M08':
            self.send_html(render('Truy xuất',public_trace(params.get('q',['B-DEMO'])[0])+'<p><a href="/">Về trang chủ</a></p>'));return
        if parsed.path not in ('/','/test-data'):self.send_html(render('Không tìm thấy','<p>404</p>'),404);return
        sess=self.session()
        if not sess:
            body='<section class="card"><h2>Đăng nhập module</h2><p>Chọn tài khoản demo đã được cấp trong README. Tài khoản có quyền khác nhau.</p><form method="post" action="/login"><label class="field">Username<input name="username" required value="'+esc(CONF['default_user'])+'"></label><label class="field">Password<input type="password" name="password" required></label><div class="field" style="justify-content:end"><button>Đăng nhập</button></div></form></section>'
            if CONF['id']=='M08':body+='<p><a href="/trace?q=B-DEMO">Xem truy xuất công khai của lô demo</a></p>'
            if params.get('error'):body+='<p class="notice error">'+esc(params['error'][0])+'</p>'
            self.send_html(render('Đăng nhập',body));return
        if parsed.path=='/test-data':
            self.send_html(render('Dữ liệu Excel và Test Case', '<p><a href="/">Trở về ứng dụng</a></p>'+test_data_section()));return
        who=sess['username'];csrf=sess['csrf']
        flash=sess.pop('flash',None)
        note=(flash or {}).get('notice','') or params.get('notice',[''])[0]
        is_err=(flash or {}).get('error','') or params.get('error',[''])[0]
        saved=(flash or {}).get('values',{})
        active_op=(flash or {}).get('operation','') or params.get('edit',[''])[0]
        edit_key=params.get('key',[''])[0]
        edit_grade=params.get('grade',['A'])[0]
        search=params.get('q',[''])[0].strip()[:120]
        user=SERVICE.get_user(who)
        body='<div class="bar"><strong>Đang đăng nhập: '+esc(who)+'</strong><form method="post" action="/logout"><input type="hidden" name="csrf" value="'+esc(csrf)+'"><button>Đăng xuất</button></form><a href="/">Làm mới</a>'
        if CONF['id']=='M08':body+='<a href="/trace?q=B-DEMO">Xem truy xuất công khai</a>'
        body+='<a href="/test-data">Dữ liệu Excel / Test Case</a></div>'
        if note or is_err:body+='<p class="notice '+('error' if is_err else '')+'">'+esc(note or is_err)+'</p>'
        body+='<p class="muted">Dữ liệu ban đầu chỉ phục vụ demo, được lưu riêng tại <code>01_Python_Source/data/module.sqlite3</code>. Mỗi module không kết nối với module khác.</p>'
        body+='<section class="card"><h2>Thao tác nghiệp vụ</h2><p class="hint">Chọn chức năng, nhập dữ liệu hợp lệ rồi bấm Kiểm tra và lưu. Các biểu mẫu chỉ hiển thị khi vai trò có quyền; thao tác không hợp lệ không ghi dữ liệu.</p>'
        available=[]
        for f in CONF['forms']:
            action=OP_ACTIONS.get(f['method'])
            try:
                if action:SERVICE._authorize(who,action)
                available.append(f)
            except AuthorizationError:pass
        if not available:body+='<p>Vai trò này không có thao tác chỉnh sửa tại module đang xem.</p>'
        body+='</section>'
        for f in available:
            values=saved if active_op==f['method'] and saved else (prefilling(f,edit_key,edit_grade) if active_op==f['method'] and edit_key else None)
            body+=form_html(f,csrf,values,opened=bool(active_op==f['method']))
        body+='<section class="card"><h2>Tìm và kiểm tra dữ liệu</h2><form class="query" method="get" action="/"><label class="field">Tìm trong các bảng<input name="q" value="'+esc(search)+'" placeholder="Nhập mã lô, mã đơn, trạng thái..."></label><button>Tìm kiếm</button><a href="/">Xóa lọc</a></form></section>'
        editor=EDIT_CONFIG.get(CONF['id'])
        for t in CONF['tables']:
            try:
                if t=='audit_log':SERVICE._authorize(who,'audit.read')
                if t=='users' and CONF['id']=='M01':SERVICE._authorize(who,'account.admin')
                body+='<section class="card"><h2>Dữ liệu · '+esc(t)+'</h2>'+table_html(t,search,editor if editor and any(x['method']==editor[2] for x in available) else None)+'</section>'
            except AuthorizationError:
                body+='<section class="card"><h2>Dữ liệu · '+esc(t)+'</h2><p class="hint">Bạn không có quyền xem bảng này.</p></section>'
            except Exception as e:body+='<p class="notice error">'+esc(e)+'</p>'
        self.send_html(render(CONF['title'],body))
    def do_POST(self):
        path=urllib.parse.urlsplit(self.path).path
        try:
            length=int(self.headers.get('Content-Length','0'))
            if length<0 or length>100_000:raise ValueError('Payload quá lớn')
            raw=self.rfile.read(length).decode('utf-8')
            data={k:v[0] for k,v in urllib.parse.parse_qs(raw,keep_blank_values=True).items()}
            if path=='/login':
                user=SERVICE.authenticate(data.get('username',''),data.get('password',''))
                if not user:self.redirect('/?error='+urllib.parse.quote('Sai tài khoản hoặc mật khẩu'));return
                sid=secrets.token_urlsafe(24);SESSIONS[sid]={'username':user['username'],'csrf':secrets.token_urlsafe(24)}
                self.redirect('/',f'sid={sid}; HttpOnly; SameSite=Lax; Path=/');return
            sess=self.session()
            if not sess or data.get('csrf')!=sess['csrf']:
                self.send_html(render('Không có quyền','<p>403 — CSRF / session không hợp lệ</p>'),403);return
            if path=='/logout':
                c=cookies.SimpleCookie();c.load(self.headers.get('Cookie',''))
                sid=c.get('sid')
                if sid:SESSIONS.pop(sid.value,None)
                self.redirect('/','sid=; HttpOnly; SameSite=Lax; Path=/; Max-Age=0');return
            if path!='/action':self.send_html(render('Không tồn tại','<p>404</p>'),404);return
            op=data.get('operation')
            f=next((x for x in CONF['forms'] if x['method']==op),None)
            if not f:raise ValueError('Chức năng không nằm trong module này')
            kw={'actor':sess['username']}
            for name,label,typ,default in f['fields']:
                val=data.get(name,'')
                if typ=='optional_number' and not val.strip():kw[name]=None
                elif typ in ('number','optional_number'):kw[name]=float(val)
                else:kw[name]=val
            result=getattr(SERVICE,op)(**kw)
            notice=f'{op}: thành công'+(f' — {result}' if result is not None else '')
            self.redirect('/?notice='+urllib.parse.quote(notice));return
        except Exception as e:
            if isinstance(e,(AgriTraceError,ValueError)):
                message=str(e)
            else:
                message='Đã xảy ra lỗi nội bộ. Kiểm tra terminal để biết chi tiết.'
                print('INTERNAL ERROR:',repr(e),file=sys.stderr)
            if 'sess' in locals() and sess:
                safe={k:v for k,v in data.items() if 'password' not in k.lower() and k not in ('csrf',)}
                sess['flash']={'error':message,'values':safe,'operation':data.get('operation','')}
                self.redirect('/');return
            self.redirect('/?error='+urllib.parse.quote(message))
    def log_message(self,fmt,*args):
        sys.stdout.write('%s %s\n'%(self.address_string(),fmt%args))

def main():
    parser=argparse.ArgumentParser(description='AgriTrace standalone module')
    parser.add_argument('--port',type=int,default=CONF['port'])
    args=parser.parse_args()
    print(f"{CONF['id']} {CONF['title']} — http://127.0.0.1:{args.port}/", flush=True)
    with ThreadingHTTPServer(('127.0.0.1',args.port),Handler) as server:server.serve_forever()
if __name__=='__main__':main()

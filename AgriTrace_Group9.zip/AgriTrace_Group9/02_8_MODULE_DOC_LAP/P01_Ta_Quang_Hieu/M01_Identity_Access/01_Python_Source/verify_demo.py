"""Executable standalone smoke scenarios. Uses a temporary SQLite database."""
import tempfile,json,traceback
from pathlib import Path
from service import create_service
from bootstrap import seed_demo

def verify():
    with tempfile.TemporaryDirectory() as td:
        service=create_service(Path(td)/'smoke.sqlite3',Path(td)/'qr')
        seed_demo(service,'M01')
        s=service
        s.create_user('admin','test_user','Test User','Farm Manager','Testpass123')
        assert s.authenticate('test_user','Testpass123')
        s.update_user('admin','test_user','New Name','Farm Manager','1')
        assert s.get_user('test_user')['display_name']=='New Name'
        from modules.core import ConflictError
        try:s.create_user('admin','test_user','Dup','Farm Manager','Testpass123')
        except ConflictError:pass
        else:raise AssertionError('Duplicate must be rejected')
    return {'module':'M01','status':'PASS','scenario':'Tạo và quản lý tài khoản','positive_and_negative_checked':True}

if __name__=='__main__':
    try:
        result=verify()
    except Exception as e:
        result={'module':'M01','status':'FAIL','error':str(e)}
        traceback.print_exc()
    print(json.dumps(result,ensure_ascii=False,indent=2))
    if result['status']!='PASS':raise SystemExit(1)

@echo off
cd /d "%~dp0"
python app.py
if errorlevel 1 (
 echo Python failed. Check python --version and README.
 pause
)

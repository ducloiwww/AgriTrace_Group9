import sys, unittest, tempfile
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from service import create_service
from bootstrap import seed_demo
from modules.core import AgriTraceError,AuthorizationError

class ModuleTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory()
        self.s=create_service(Path(self.temp.name)/'test.sqlite3',Path(self.temp.name)/'qr')
        seed_demo(self.s,'M01')
    def tearDown(self):self.temp.cleanup()
    def test_create_and_login(self):
        s=self.s;s.create_user('admin','test01','Người mới','Farm Manager','Strong@123');self.assertEqual(s.authenticate('test01','Strong@123')['username'],'test01')
    def test_wrong_password(self):self.assertIsNone(self.s.authenticate('admin','wrong'))
    def test_duplicate_user(self):
        self.s.create_user('admin','test01','Name','Farm Manager','Strong@123')
        with self.assertRaises(AgriTraceError):self.s.create_user('admin','test01','Name','Farm Manager','Strong@123')
    def test_non_admin_rejected(self):
        with self.assertRaises(AuthorizationError):self.s.create_user('farm','bad','Name','Farm Manager','Strong@123')
    def test_change_password(self):
        self.s.change_password('farm','Farm@123','NewFarm@123')
        self.assertIsNotNone(self.s.authenticate('farm','NewFarm@123'))

if __name__=='__main__':unittest.main()

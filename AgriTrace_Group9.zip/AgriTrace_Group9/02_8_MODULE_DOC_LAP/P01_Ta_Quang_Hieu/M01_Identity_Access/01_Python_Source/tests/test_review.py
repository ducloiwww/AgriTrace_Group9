import unittest,tempfile
from pathlib import Path
from service import create_service
from bootstrap import seed_demo
from modules.core import ValidationError,ConflictError,NotFoundError,AuthorizationError

class ReviewTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory()
        self.s=create_service(Path(self.temp.name)/'testing.sqlite3',Path(self.temp.name)/'qr')
        seed_demo(self.s,'M01')
    def tearDown(self):self.temp.cleanup()
    def new(self):return self.s.create_order('retailer','Retail-01','B-DEMO','A',20,'2026-11-01')
    def test_update_and_disable_user(self):
        self.s.update_user('admin','farm','User New','Farm Manager','0')
        self.assertEqual(self.s.get_user('farm')['active'],0)
        self.assertIsNone(self.s.authenticate('farm','Farm@123'))
    def test_admin_cannot_disable_self(self):
        with self.assertRaises(ConflictError):self.s.update_user('admin','admin','Admin','System Administrator','0')


"""AgriTrace modular SQLite business services.

Each mixin contains one cohesive responsibility; AgriTraceService composes them.
"""
from __future__ import annotations
from .core import (
    AgriTraceError, AuthorizationError, NotFoundError, ValidationError, ConflictError,
    ROLES, ROLE_ACTIONS, now_iso, _valid_date, _number, _valid_id, _required,
    hash_password, verify_password, sqlite3, secrets, json, datetime, date,
    timezone, math, re, hashlib, Path, Any
)

class AccountServiceMixin:
    def get_user(self, username: str) -> dict[str, Any] | None:
        with self._db() as conn:
            row = conn.execute("SELECT username, display_name, role, active FROM users WHERE username=?", (username,)).fetchone()
            return dict(row) if row else None

    def authenticate(self, username: str, password: str) -> dict[str, Any] | None:
        with self._db() as conn:
            row = conn.execute("SELECT * FROM users WHERE username=? AND active=1", (username,)).fetchone()
            if row and verify_password(password, row["password_hash"]):
                return {"username": row["username"], "display_name": row["display_name"], "role": row["role"]}
        return None

    def change_password(self, actor: str, current_password: str, new_password: str) -> None:
        _required(Mật_khẩu_hiện_tại=current_password, Mật_khẩu_mới=new_password)
        with self._db() as conn:
            row = conn.execute("SELECT password_hash FROM users WHERE username=? AND active=1", (actor,)).fetchone()
            if not row or not verify_password(current_password, row["password_hash"]):
                raise AuthorizationError("Mật khẩu hiện tại không đúng.")
            pw_hash = hash_password(new_password)
            conn.execute("UPDATE users SET password_hash=? WHERE username=?", (pw_hash, actor))
            self._audit(conn, actor, "account.password_changed", "user", actor)

    def create_user(self, actor: str, username: str, display_name: str, role: str, password: str) -> None:
        self._authorize(actor, "account.admin")
        _required(Tên_tài_khoản=username, Tên_hiển_thị=display_name, Vai_trò=role, Mật_khẩu=password)
        if role not in ROLES:
            raise ValidationError("Vai trò không hợp lệ.")
        if len(username) < 3 or any(ch.isspace() for ch in username):
            raise ValidationError("Tên tài khoản phải có ít nhất 3 ký tự và không chứa khoảng trắng.")
        pw_hash = hash_password(password)
        with self._db() as conn:
            if conn.execute("SELECT 1 FROM users WHERE username=?", (username,)).fetchone():
                raise ConflictError("Tên tài khoản đã tồn tại.")
            conn.execute("INSERT INTO users VALUES(?,?,?,?,1,?)", (username, display_name.strip(), role, pw_hash, now_iso()))
            self._audit(conn, actor, "account.created", "user", username, role)

    def update_user(self, actor: str, username: str, display_name: str, role: str, active: str) -> None:
        """Admin can edit a demo account; protect active administrator access."""
        self._authorize(actor, "account.admin")
        _required(Tên_tài_khoản=username, Tên_hiển_thị=display_name)
        if role not in ROLES or active not in {"0", "1"}:
            raise ValidationError("Vai trò hoặc trạng thái tài khoản không hợp lệ.")
        with self._db() as conn:
            row=conn.execute("SELECT * FROM users WHERE username=?",(username,)).fetchone()
            if not row:raise NotFoundError("Không tìm thấy tài khoản.")
            if username==actor and (role != row['role'] or active=='0'):
                raise ConflictError("Quản trị viên không được tự thu hồi quyền hoặc khóa tài khoản đang sử dụng.")
            if row['role']=='System Administrator' and (role!='System Administrator' or active=='0'):
                count=conn.execute("SELECT COUNT(*) FROM users WHERE role='System Administrator' AND active=1").fetchone()[0]
                if count<=1:raise ConflictError("Phải duy trì ít nhất một quản trị viên đang hoạt động.")
            conn.execute("UPDATE users SET display_name=?,role=?,active=? WHERE username=?",(display_name.strip(),role,int(active),username))
            self._audit(conn,actor,'account.updated','user',username,f'role={role};active={active}')

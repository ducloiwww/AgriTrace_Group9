"""SQLite-backed AgriTrace core and shared domain functions.

This module implements the classroom project's local, end-to-end business workflow.
External carrier GPS, payment gateways, email/SMS delivery and production identity
providers are intentionally not simulated as real integrations.
"""
from __future__ import annotations

import hashlib
import json
import math
import re
import secrets
import sqlite3
from contextlib import contextmanager
from datetime import date, datetime, timezone
from pathlib import Path
from typing import Any


class AgriTraceError(Exception):
    """Base class for expected application errors."""


class AuthorizationError(AgriTraceError):
    pass


class NotFoundError(AgriTraceError):
    pass


class ValidationError(AgriTraceError):
    pass


class ConflictError(AgriTraceError):
    pass


ROLES = (
    "Farm Manager",
    "Processing & Packing Manager",
    "Food Safety Inspector",
    "Warehouse / Order Fulfilment Coordinator",
    "Distributor / Logistics Manager",
    "Retailer Manager",
    "System Administrator",
)

ROLE_ACTIONS: dict[str, set[str]] = {
    "Farm Manager": {"farm.write", "cycle.write", "cultivation.write", "batch.create", "harvest.write", "grading.write", "trace.generate"},
    "Processing & Packing Manager": {"processing.write", "quality.write", "grading.write"},
    "Food Safety Inspector": {"quality.write", "recall.write", "safety.review"},
    "Warehouse / Order Fulfilment Coordinator": {"inventory.receive", "inventory.adjust", "order.confirm", "order.allocate", "order.pack", "order.cancel", "audit.read"},
    "Distributor / Logistics Manager": {"shipment.write", "temperature.write"},
    "Retailer Manager": {"order.write", "order.cancel", "receipt.write"},
    "System Administrator": {"account.admin", "audit.read", "recall.write"},
}


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def _valid_date(value: str, label: str) -> date:
    try:
        return date.fromisoformat(str(value))
    except (TypeError, ValueError) as exc:
        raise ValidationError(f"{label} phải có định dạng YYYY-MM-DD.") from exc


def _number(value: Any, label: str) -> float:
    try:
        result = float(value)
    except (TypeError, ValueError) as exc:
        raise ValidationError(f"{label} phải là số hợp lệ.") from exc
    if not math.isfinite(result):
        raise ValidationError(f"{label} phải là số hữu hạn.")
    return result


def _valid_id(value: str, label: str) -> str:
    value = str(value or "").strip()
    if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_-]{0,63}", value):
        raise ValidationError(f"{label} chỉ được chứa chữ, số, dấu gạch ngang hoặc gạch dưới; tối đa 64 ký tự.")
    return value


def _required(**fields: Any) -> None:
    missing = [label for label, value in fields.items() if value is None or not str(value).strip()]
    if missing:
        raise ValidationError("Thiếu trường bắt buộc: " + ", ".join(missing))


def hash_password(password: str, salt: bytes | None = None) -> str:
    if len(password) < 8:
        raise ValidationError("Mật khẩu phải có ít nhất 8 ký tự.")
    salt = salt or secrets.token_bytes(16)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, 240_000)
    return f"pbkdf2_sha256${salt.hex()}${digest.hex()}"


def verify_password(password: str, stored: str) -> bool:
    try:
        algorithm, salt_hex, digest_hex = stored.split("$", 2)
        if algorithm != "pbkdf2_sha256":
            return False
        test = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), bytes.fromhex(salt_hex), 240_000)
        return secrets.compare_digest(test.hex(), digest_hex)
    except (ValueError, TypeError):
        return False


class AgriTraceBase:
    def __init__(self, db_path: str | Path = "data/agritrace.sqlite3", qr_dir: str | Path = "data/qr") -> None:
        self.db_path = Path(db_path).resolve()
        self.qr_dir = Path(qr_dir).resolve()
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self.qr_dir.mkdir(parents=True, exist_ok=True)
        self._initialize()

    @contextmanager
    def _db(self):
        conn = sqlite3.connect(self.db_path, timeout=15)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA foreign_keys = ON")
        try:
            yield conn
            conn.commit()
        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()

    def _initialize(self) -> None:
        schema = """
        PRAGMA journal_mode = WAL;
        CREATE TABLE IF NOT EXISTS users (
            username TEXT PRIMARY KEY, display_name TEXT NOT NULL, role TEXT NOT NULL,
            password_hash TEXT NOT NULL, active INTEGER NOT NULL DEFAULT 1, created_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS farms (
            farm_id TEXT PRIMARY KEY, name TEXT NOT NULL, region TEXT NOT NULL, contact TEXT NOT NULL,
            created_by TEXT NOT NULL, created_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS cycles (
            cycle_id TEXT PRIMARY KEY, farm_id TEXT NOT NULL REFERENCES farms(farm_id), plot TEXT NOT NULL,
            crop TEXT NOT NULL, planting_date TEXT NOT NULL, expected_harvest TEXT NOT NULL,
            status TEXT NOT NULL DEFAULT 'Active', created_by TEXT NOT NULL, created_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS cultivation_events (
            id INTEGER PRIMARY KEY AUTOINCREMENT, cycle_id TEXT NOT NULL REFERENCES cycles(cycle_id),
            activity TEXT NOT NULL, event_date TEXT NOT NULL, quantity REAL NOT NULL DEFAULT 0,
            public_note TEXT NOT NULL DEFAULT '', created_by TEXT NOT NULL, created_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS batches (
            batch_id TEXT PRIMARY KEY, cycle_id TEXT NOT NULL REFERENCES cycles(cycle_id),
            harvest_date TEXT, harvest_qty REAL, grade_a REAL NOT NULL DEFAULT 0, grade_b REAL NOT NULL DEFAULT 0,
            grade_c REAL NOT NULL DEFAULT 0, rejected_qty REAL NOT NULL DEFAULT 0, graded_at TEXT,
            grading_location TEXT NOT NULL DEFAULT '',
            process_facility TEXT, processing_date TEXT, packaging_date TEXT, package_details TEXT,
            inspection_status TEXT NOT NULL DEFAULT 'Pending', inspection_notes TEXT NOT NULL DEFAULT '',
            inspection_location TEXT NOT NULL DEFAULT '', inspection_actor TEXT, inspection_at TEXT, status TEXT NOT NULL DEFAULT 'Created',
            qr_token TEXT UNIQUE, recalled INTEGER NOT NULL DEFAULT 0, recall_reason TEXT, recall_at TEXT,
            review_hold INTEGER NOT NULL DEFAULT 0, created_by TEXT NOT NULL, created_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS inventory (
            batch_id TEXT NOT NULL REFERENCES batches(batch_id), grade TEXT NOT NULL,
            on_hand REAL NOT NULL DEFAULT 0, reserved REAL NOT NULL DEFAULT 0, received_total REAL NOT NULL DEFAULT 0,
            last_received_at TEXT NOT NULL DEFAULT '', last_location TEXT NOT NULL DEFAULT '', PRIMARY KEY(batch_id, grade)
        );
        CREATE TABLE IF NOT EXISTS orders (
            order_id TEXT PRIMARY KEY, retailer_id TEXT NOT NULL, batch_id TEXT NOT NULL REFERENCES batches(batch_id),
            grade TEXT NOT NULL, quantity REAL NOT NULL, status TEXT NOT NULL DEFAULT 'Pending', requested_delivery_date TEXT NOT NULL DEFAULT '',
            created_by TEXT NOT NULL, created_at TEXT NOT NULL, received_qty REAL, received_at TEXT
        );
        CREATE TABLE IF NOT EXISTS allocations (
            id INTEGER PRIMARY KEY AUTOINCREMENT, order_id TEXT NOT NULL REFERENCES orders(order_id),
            batch_id TEXT NOT NULL REFERENCES batches(batch_id), grade TEXT NOT NULL, quantity REAL NOT NULL,
            created_by TEXT NOT NULL, created_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS shipments (
            shipment_id TEXT PRIMARY KEY, order_id TEXT NOT NULL UNIQUE REFERENCES orders(order_id),
            batch_id TEXT NOT NULL REFERENCES batches(batch_id), quantity REAL NOT NULL,
            destination TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'In Transit', created_by TEXT NOT NULL,
            created_at TEXT NOT NULL, delivered_at TEXT
        );
        CREATE TABLE IF NOT EXISTS shipment_events (
            id INTEGER PRIMARY KEY AUTOINCREMENT, shipment_id TEXT NOT NULL REFERENCES shipments(shipment_id),
            event_type TEXT NOT NULL, location TEXT NOT NULL DEFAULT '', note TEXT NOT NULL DEFAULT '',
            temperature_c REAL, min_allowed_c REAL, max_allowed_c REAL, out_of_range INTEGER NOT NULL DEFAULT 0,
            event_at TEXT NOT NULL, created_by TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS safety_reviews (
            id INTEGER PRIMARY KEY AUTOINCREMENT, batch_id TEXT NOT NULL REFERENCES batches(batch_id),
            event_type TEXT NOT NULL, note TEXT NOT NULL, actor TEXT NOT NULL, event_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS alerts (
            id INTEGER PRIMARY KEY AUTOINCREMENT, batch_id TEXT NOT NULL REFERENCES batches(batch_id),
            target_role TEXT NOT NULL, message TEXT NOT NULL, created_at TEXT NOT NULL,
            acknowledged INTEGER NOT NULL DEFAULT 0
        );
        CREATE TABLE IF NOT EXISTS audit_log (
            id INTEGER PRIMARY KEY AUTOINCREMENT, actor TEXT NOT NULL, action TEXT NOT NULL,
            entity_type TEXT NOT NULL, entity_id TEXT NOT NULL, details TEXT NOT NULL DEFAULT '',
            event_at TEXT NOT NULL
        );
        CREATE INDEX IF NOT EXISTS idx_cycles_farm ON cycles(farm_id);
        CREATE INDEX IF NOT EXISTS idx_batches_cycle ON batches(cycle_id);
        CREATE INDEX IF NOT EXISTS idx_orders_batch ON orders(batch_id);
        CREATE INDEX IF NOT EXISTS idx_shipments_batch ON shipments(batch_id);
        CREATE INDEX IF NOT EXISTS idx_audit_entity ON audit_log(entity_type, entity_id);
        CREATE TRIGGER IF NOT EXISTS audit_no_update BEFORE UPDATE ON audit_log
        BEGIN SELECT RAISE(ABORT, 'audit entries are append-only'); END;
        CREATE TRIGGER IF NOT EXISTS audit_no_delete BEFORE DELETE ON audit_log
        BEGIN SELECT RAISE(ABORT, 'audit entries are append-only'); END;
        """
        with self._db() as conn:
            conn.executescript(schema)
            # Small safe migrations for installations created by an earlier local version.
            batch_columns = {r[1] for r in conn.execute("PRAGMA table_info(batches)")}
            if "graded_at" not in batch_columns:
                conn.execute("ALTER TABLE batches ADD COLUMN graded_at TEXT")
            if "grading_location" not in batch_columns:
                conn.execute("ALTER TABLE batches ADD COLUMN grading_location TEXT NOT NULL DEFAULT ''")
            if "inspection_location" not in batch_columns:
                conn.execute("ALTER TABLE batches ADD COLUMN inspection_location TEXT NOT NULL DEFAULT ''")
            inventory_columns = {r[1] for r in conn.execute("PRAGMA table_info(inventory)")}
            if "last_received_at" not in inventory_columns:
                conn.execute("ALTER TABLE inventory ADD COLUMN last_received_at TEXT NOT NULL DEFAULT ''")
            if "last_location" not in inventory_columns:
                conn.execute("ALTER TABLE inventory ADD COLUMN last_location TEXT NOT NULL DEFAULT ''")
            order_columns = {r[1] for r in conn.execute("PRAGMA table_info(orders)")}
            if "requested_delivery_date" not in order_columns:
                conn.execute("ALTER TABLE orders ADD COLUMN requested_delivery_date TEXT NOT NULL DEFAULT ''")
            defaults = [
                ("farm", "Farm Manager", "Farm@123"),
                ("processor", "Processing & Packing Manager", "Process@123"),
                ("inspector", "Food Safety Inspector", "Inspect@123"),
                ("warehouse", "Warehouse / Order Fulfilment Coordinator", "Warehouse@123"),
                ("logistics", "Distributor / Logistics Manager", "Logistics@123"),
                ("retailer", "Retailer Manager", "Retail@123"),
                ("admin", "System Administrator", "Admin@123"),
            ]
            for username, role, password in defaults:
                conn.execute(
                    "INSERT OR IGNORE INTO users(username,display_name,role,password_hash,active,created_at) VALUES(?,?,?,?,1,?)",
                    (username, username.title(), role, hash_password(password), now_iso()),
                )

    def _authorize(self, actor: str, action: str) -> None:
        user = self.get_user(actor)
        if user is None or not user["active"] or action not in ROLE_ACTIONS.get(user["role"], set()):
            raise AuthorizationError(f"Tài khoản '{actor}' không có quyền thực hiện chức năng này.")

    def _audit(self, conn: sqlite3.Connection, actor: str, action: str, entity_type: str, entity_id: str, details: str = "") -> None:
        conn.execute("INSERT INTO audit_log(actor,action,entity_type,entity_id,details,event_at) VALUES(?,?,?,?,?,?)",
                     (actor, action, entity_type, entity_id, details, now_iso()))

    def _one(self, table: str, key: str, value: str) -> dict[str, Any]:
        with self._db() as conn:
            row = conn.execute(f"SELECT * FROM {table} WHERE {key}=?", (value,)).fetchone()
            if not row:
                raise NotFoundError(f"Không tìm thấy {value}.")
            return dict(row)


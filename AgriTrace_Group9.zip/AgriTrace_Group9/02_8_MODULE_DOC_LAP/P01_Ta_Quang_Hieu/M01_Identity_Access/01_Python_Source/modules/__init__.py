"""Bundled local service dependencies; nothing imported from another module folder."""

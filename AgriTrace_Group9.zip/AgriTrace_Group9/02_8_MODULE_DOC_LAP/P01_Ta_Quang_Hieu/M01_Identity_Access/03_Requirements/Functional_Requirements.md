# M01 — Functional Requirements

## FR-001 — Role-based access control
- description: The system shall authenticate registered operational users and restrict protected data-modification functions according to assigned roles.
- type: Functional
- priority: Must
- status: Approved
- source: SH-07
- rationale: Source: Lab 7 updated requirement baseline; Labs 1-4 core workflow. See UC-01.
- acceptance_criteria: Unauthorized users cannot modify protected supply-chain records.
- verification_method: Test
- complexity: 1
- dependencies: None
- tags: UC-01;full-supply-chain
- module_id: M01
- implementation_status: Implemented
- linked_use_cases: UC-01
- designed_test_cases: TC-001
- _mod: M01

# M01 — Test Cases

## TC-001 — Unauthorized operator cannot modify protected records
- related_requirements: FR-001
- type: Security / access control
- priority: Must
- preconditions: Farm F-001 and batch B-001 exist. Users farm, retailer exist; user 'ghost' does not.
- steps: 1 Call add_farm as retailer. 2 Call recall_batch as farm. 3 Call receive_inventory as farm. 4 Call add_farm as unknown user ghost. 5 List farms.
- expected_result: Each call raises AuthorizationError; farms table unchanged (1 row).
- status: PASS
- actual_result: 4 unauthorized calls rejected (AuthorizationError, AuthorizationError, AuthorizationError, AuthorizationError); farms table still 1 row.
- executed_by: Automated script run_detailed_tests.py (sandbox, local SQLite)
- executed_date: 2026-10-22
- module_id: M01
- test_data: actors: retailer, farm, ghost; F-9/B-001
- implementation_function: authenticate / _authorize / ROLE_ACTIONS
- evidence_scope: Local SQLite scenario result
- _mod: M01

# M01 — Quy tắc kiểm tra bổ sung

- **Hành vi:** Cập nhật trạng thái user với quyền admin; đăng nhập sai bị từ chối.
- **Luồng demo:** admin tạo tài khoản → đổi vai trò → thử vô hiệu hóa admin hiện tại
- **Mã nguồn:** `01_Python_Source/modules`, `01_Python_Source/app.py`
- **Kiểm thử đã thực thi:** `tests/test_review.py`, `verify_demo.py`; không tự đồng nhất số lượng unit test với số TC thiết kế.
- **Mốc:** 29/10/2026; nội dung mới phục vụ giao diện cập nhật, chưa thay thế các FR/UC/TC gốc trong `specification.json`.

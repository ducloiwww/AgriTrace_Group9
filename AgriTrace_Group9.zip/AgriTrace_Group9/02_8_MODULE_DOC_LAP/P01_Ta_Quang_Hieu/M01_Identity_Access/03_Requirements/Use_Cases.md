# M01 — Use Cases

## UC-01 — Authenticate User
- primary_actor: Operational User
- goal: Sign in and establish an authorized session
- preconditions: An active user account with an assigned role exists
- main_flow: 1 System shows login form with CSRF token. 2 User enters username and password. 3 System verifies password against salted PBKDF2-HMAC-SHA256 hash. 4 System creates an in-memory session and shows the role-specific page. 5 Each later action checks ROLE_ACTIONS before running.
- alternative_flows: 3a Wrong password or unknown user -> login refused, no session. 5a Action not in role's permission set -> AuthorizationError, data unchanged. 5b Account inactive -> AuthorizationError.
- postconditions: Authenticated session exists with appropriate permissions
- trigger: User submits username and password on the login page.
- frequency: Not measured (coursework prototype)
- related_requirements: FR-001
- module_id: M01
- test_case_ids: TC-001
- web_implementation: authenticate / _authorize / ROLE_ACTIONS
- _mod: M01

# M06 — Quy tắc kiểm tra bổ sung

- **Hành vi:** Chỉ tác giả sửa đơn Pending; thay đổi sau Confirmed bị từ chối.
- **Luồng demo:** retailer tạo đơn → sửa số lượng → warehouse xác nhận/phân bổ → retailer thử sửa lại
- **Mã nguồn:** `01_Python_Source/modules`, `01_Python_Source/app.py`
- **Kiểm thử đã thực thi:** `tests/test_review.py`, `verify_demo.py`; không tự đồng nhất số lượng unit test với số TC thiết kế.
- **Mốc:** 29/10/2026; nội dung mới phục vụ giao diện cập nhật, chưa thay thế các FR/UC/TC gốc trong `specification.json`.

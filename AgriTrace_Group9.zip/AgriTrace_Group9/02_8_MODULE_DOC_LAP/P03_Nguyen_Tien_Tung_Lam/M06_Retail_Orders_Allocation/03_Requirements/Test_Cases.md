# M06 — Test Cases

## TC-017 — Create valid retailer order
- related_requirements: FR-017
- type: Functional
- priority: Must
- preconditions: B-001 approved with stock.
- steps: 1 create_order(Retailer-1, B-001, A, 100). 2 Quantity 0. 3 Grade Z. 4 Unknown batch. 5 As farm role.
- expected_result: ORD-00001 Pending; invalid inputs rejected; farm -> AuthorizationError.
- status: PASS
- actual_result: Order ORD-00001 created with status Pending; qty 0 -> ValidationError; bad grade -> ValidationError; unknown batch -> NotFoundError; farm role -> AuthorizationError. Note: requested delivery date is not captured by the app (FR-017 lists it).
- executed_by: Automated script run_detailed_tests.py (sandbox, local SQLite)
- executed_date: 2026-10-22
- module_id: M06
- test_data: 100 kg A
- implementation_function: create_order
- evidence_scope: Local SQLite scenario result
- _mod: M06

## TC-018 — Allocate eligible inventory to order
- related_requirements: FR-018
- type: Functional
- priority: Must
- preconditions: A stock 600; order1=200, order2=500.
- steps: 1 Confirm+allocate order1. 2 Allocate order2 (available 400). 3 Re-allocate full order1. 4 Allocate order2 partial 400.
- expected_result: order1 reserved 200; order2 full -> ConflictError; re-allocate -> ValidationError; partial 400 -> reserved 600.
- status: PASS
- actual_result: Order 200 allocated -> reserved 200; order 500 vs available 400 -> ConflictError; re-allocating a full order -> ValidationError; partial allocation 400 allowed -> reserved 600 = on_hand (available 0).
- executed_by: Automated script run_detailed_tests.py (sandbox, local SQLite)
- executed_date: 2026-10-22
- module_id: M06
- test_data: 200; 500; 400
- implementation_function: allocate_order
- evidence_scope: Local SQLite scenario result
- _mod: M06

## TC-019 — Fulfill order through valid status transitions
- related_requirements: FR-019
- type: Functional
- priority: Must
- preconditions: B-001 stock A600; order for 100 kg.
- steps: 1 Pack a Pending order. 2 Allocate a Pending order. 3 Confirm, allocate, pack, ship, deliver, confirm receipt. 4 Look for a cancel function.
- expected_result: Skipped steps -> ConflictError; full chain accepted. Cancelled not implemented -> PARTIAL.
- status: PARTIAL
- actual_result: Transitions Pending -> Confirmed -> Allocated -> Packed -> Shipped -> Delivered -> Received accepted; skipping steps rejected (ConflictError). Cancelled status and release-on-cancel (required by FR-019) are NOT implemented in agritrace_service.py (cancel methods found: none).
- executed_by: Automated script run_detailed_tests.py (sandbox, local SQLite)
- executed_date: 2026-10-22
- module_id: M06
- test_data: 100 kg
- implementation_function: confirm_order / pack_order / shipment status
- evidence_scope: Local SQLite scenario result
- _mod: M06
- implementation_status: Implemented locally; cancellation regression added

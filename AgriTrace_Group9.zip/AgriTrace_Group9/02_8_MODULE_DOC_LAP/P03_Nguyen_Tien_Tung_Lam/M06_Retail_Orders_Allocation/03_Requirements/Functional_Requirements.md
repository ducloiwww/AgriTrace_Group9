# M06 — Functional Requirements

## FR-017 — Create retailer order
- description: The system shall allow an authorized Retail Order Coordinator or Retailer Manager to create an order containing requested product, grade, quantity, requested delivery date, and destination retailer.
- type: Functional
- priority: Must
- status: Approved
- source: SH-10
- rationale: Source: Lab 7 updated requirement baseline; post-Lab-4 expansion. See UC-18.
- acceptance_criteria: A valid order receives a unique Order ID and status Pending.
- verification_method: Test
- complexity: 1
- dependencies: None
- tags: UC-18;full-supply-chain
- module_id: M06
- implementation_status: Implemented locally: new order with requested delivery date; destination held at shipment
- linked_use_cases: UC-18
- designed_test_cases: TC-017
- _mod: M06

## FR-018 — Allocate inventory to order
- description: The system shall allocate eligible batch inventory to confirmed orders without exceeding available stock or double-allocating the same reserved quantity.
- type: Functional
- priority: Must
- status: Approved
- source: SH-09
- rationale: Source: Lab 7 updated requirement baseline; post-Lab-4 expansion. See UC-19.
- acceptance_criteria: Allocation records reference valid order/batch pairs and reserved stock is consistent.
- verification_method: Test
- complexity: 1
- dependencies: None
- tags: UC-19;full-supply-chain
- module_id: M06
- implementation_status: Implemented
- linked_use_cases: UC-19
- designed_test_cases: TC-018
- _mod: M06

## FR-019 — Manage order fulfillment
- description: The system shall support order status transitions Pending, Confirmed, Packed, Shipped, Delivered, and Cancelled with release of reservations on cancellation before shipment.
- type: Functional
- priority: Must
- status: Approved
- source: SH-10
- rationale: Source: Lab 7 updated requirement baseline; post-Lab-4 expansion. See UC-20.
- acceptance_criteria: Only valid transitions are accepted and cancellation releases reservations when applicable.
- verification_method: Test
- complexity: 1
- dependencies: None
- tags: UC-20;full-supply-chain
- module_id: M06
- implementation_status: Implemented locally: pre-shipment cancellation with reservation release
- linked_use_cases: UC-20
- designed_test_cases: TC-019
- _mod: M06

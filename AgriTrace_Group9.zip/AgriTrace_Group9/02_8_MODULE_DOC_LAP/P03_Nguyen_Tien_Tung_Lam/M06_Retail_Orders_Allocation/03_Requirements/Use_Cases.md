# M06 — Use Cases

## UC-18 — Create Retail Order
- primary_actor: Retail Order Coordinator
- goal: Create retailer purchase order with products, grade and quantity
- preconditions: Retailer or order coordinator authorized; catalog has orderable products
- main_flow: Actor selects retailer and products; Enters requested grade, quantity and destination; System validates inputs; Creates unique Order ID in Pending status; Stores order lines and actor/time
- alternative_flows: Missing retailer -> reject; Nonpositive quantity -> reject; Unknown product -> reject
- postconditions: Retail order is recorded as Pending and traceable
- trigger: Retailer starts new order
- frequency: Not measured (coursework prototype)
- related_requirements: FR-017
- module_id: M06
- test_case_ids: TC-017
- web_implementation: create_order
- _mod: M06

## UC-19 — Allocate Batch to Order
- primary_actor: Warehouse Manager
- goal: Reserve valid inventory without overselling
- preconditions: Order is confirmed or otherwise eligible; warehouse balance exists
- main_flow: Warehouse manager selects order; System identifies eligible graded batches; Computes available stock excluding existing reservations; Reserves quantities atomically by batch/order; Stores allocations and updates balances
- alternative_flows: Insufficient stock -> reject without partial mutation unless permitted; Duplicate reservation -> reject; Recalled batch -> ineligible
- postconditions: Valid order-to-batch allocations and quantities are conserved
- trigger: Order ready for stock allocation
- frequency: Not measured (coursework prototype)
- related_requirements: FR-018
- module_id: M06
- test_case_ids: TC-018
- web_implementation: allocate_order
- _mod: M06

## UC-20 — Fulfill Order
- primary_actor: Retail Order Coordinator
- goal: Move orders through fulfillment with safe cancellation
- preconditions: Order and required reservations exist
- main_flow: Coordinator confirms order; Records packed quantity; System validates transitions; Order links to shipment when dispatched; Delivery updates status Delivered; Cancellation releases eligible outstanding reservations
- alternative_flows: Invalid status transition -> reject; Shipment before packing -> reject; Cancelled order cannot ship; Reservation-release failure -> transaction rollback
- postconditions: Order status and reserved stock remain consistent
- trigger: Coordinator processes order
- frequency: Not measured (coursework prototype)
- related_requirements: FR-019
- module_id: M06
- test_case_ids: TC-019
- web_implementation: confirm_order / pack_order / shipment status
- _mod: M06

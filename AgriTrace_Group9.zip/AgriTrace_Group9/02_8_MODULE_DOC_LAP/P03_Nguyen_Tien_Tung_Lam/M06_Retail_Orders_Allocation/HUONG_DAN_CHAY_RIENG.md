# CHẠY RIÊNG M06: Retail Orders & Allocation

1. Mở thư mục 01_Python_Source của chính module này.
2. Nhấp đúp run_windows.bat (Windows) hoặc mở terminal chạy `python app.py`.
3. Truy cập http://127.0.0.1:8106 trong Chrome.
4. Đăng nhập tài khoản retailer, tra mật khẩu trong README.md.
5. Chọn biểu mẫu và thao tác; dữ liệu được lưu trong data/module.sqlite3.
6. Muốn chạy test riêng: `python run_tests.py`.

Đối với biểu mẫu có ghi (warehouse) / (inspector) / (retailer), đăng xuất và đổi sang tài khoản tương ứng.
Không cần giải nén/chạy bất kỳ module nào khác. Mọi dữ liệu đầu vào từ module trước đều là fixture DEMO cục bộ.
Không có đồng bộ giữa các module độc lập.

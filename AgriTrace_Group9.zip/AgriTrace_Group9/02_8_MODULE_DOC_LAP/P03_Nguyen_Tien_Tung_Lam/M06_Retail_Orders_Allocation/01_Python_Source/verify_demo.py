"""Executable standalone smoke scenarios. Uses a temporary SQLite database."""
import tempfile,json,traceback
from pathlib import Path
from service import create_service
from bootstrap import seed_demo

def verify():
    with tempfile.TemporaryDirectory() as td:
        service=create_service(Path(td)/'smoke.sqlite3',Path(td)/'qr')
        seed_demo(service,'M06')
        s=service
        oid=s.create_order('retailer','Retail-01','B-DEMO','A',20,'2026-11-01')
        s.update_order('retailer',oid,'Retail-01',15,'2026-11-01')
        s.confirm_order('warehouse',oid);s.allocate_order('warehouse',oid)
        from modules.core import ConflictError
        try:s.update_order('retailer',oid,'Retail-01',10,'2026-11-01')
        except ConflictError:pass
        else:raise AssertionError('Cannot edit confirmed order')
        s.cancel_order('retailer',oid,'Smoke cancel')
        assert s._one('inventory','batch_id','B-DEMO')['reserved']==0
    return {'module':'M06','status':'PASS','scenario':'Đơn hàng và phân bổ','positive_and_negative_checked':True}

if __name__=='__main__':
    try:
        result=verify()
    except Exception as e:
        result={'module':'M06','status':'FAIL','error':str(e)}
        traceback.print_exc()
    print(json.dumps(result,ensure_ascii=False,indent=2))
    if result['status']!='PASS':raise SystemExit(1)

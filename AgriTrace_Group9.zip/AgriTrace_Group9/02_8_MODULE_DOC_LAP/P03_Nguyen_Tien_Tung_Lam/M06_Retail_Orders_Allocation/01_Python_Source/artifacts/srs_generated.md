# M06 Standalone Requirements Index

## functional_requirements

### FR-017 — Create retailer order

- description: The system shall allow an authorized Retail Order Coordinator or Retailer Manager to create an order containing requested product, grade, quantity, requested delivery date, and destination retailer.
- type: Functional
- priority: Must
- status: Approved
- source: SH-10
- rationale: Source: Lab 7 updated requirement baseline; post-Lab-4 expansion. See UC-18.
- acceptance_criteria: A valid order receives a unique Order ID and status Pending.
- verification_method: Test
- complexity: 1
- dependencies: None
- tags: UC-18;full-supply-chain
- module_id: M06
- implementation_status: Implemented locally: new order with requested delivery date; destination held at shipment
- linked_use_cases: UC-18
- designed_test_cases: TC-017
- _mod: M06

### FR-018 — Allocate inventory to order

- description: The system shall allocate eligible batch inventory to confirmed orders without exceeding available stock or double-allocating the same reserved quantity.
- type: Functional
- priority: Must
- status: Approved
- source: SH-09
- rationale: Source: Lab 7 updated requirement baseline; post-Lab-4 expansion. See UC-19.
- acceptance_criteria: Allocation records reference valid order/batch pairs and reserved stock is consistent.
- verification_method: Test
- complexity: 1
- dependencies: None
- tags: UC-19;full-supply-chain
- module_id: M06
- implementation_status: Implemented
- linked_use_cases: UC-19
- designed_test_cases: TC-018
- _mod: M06

### FR-019 — Manage order fulfillment

- description: The system shall support order status transitions Pending, Confirmed, Packed, Shipped, Delivered, and Cancelled with release of reservations on cancellation before shipment.
- type: Functional
- priority: Must
- status: Approved
- source: SH-10
- rationale: Source: Lab 7 updated requirement baseline; post-Lab-4 expansion. See UC-20.
- acceptance_criteria: Only valid transitions are accepted and cancellation releases reservations when applicable.
- verification_method: Test
- complexity: 1
- dependencies: None
- tags: UC-20;full-supply-chain
- module_id: M06
- implementation_status: Implemented locally: pre-shipment cancellation with reservation release
- linked_use_cases: UC-20
- designed_test_cases: TC-019
- _mod: M06

## use_cases

### UC-18 — Create Retail Order

- primary_actor: Retail Order Coordinator
- goal: Create retailer purchase order with products, grade and quantity
- preconditions: Retailer or order coordinator authorized; catalog has orderable products
- main_flow: Actor selects retailer and products; Enters requested grade, quantity and destination; System validates inputs; Creates unique Order ID in Pending status; Stores order lines and actor/time
- alternative_flows: Missing retailer -> reject; Nonpositive quantity -> reject; Unknown product -> reject
- postconditions: Retail order is recorded as Pending and traceable
- trigger: Retailer starts new order
- frequency: Not measured (coursework prototype)
- related_requirements: FR-017
- module_id: M06
- test_case_ids: TC-017
- web_implementation: create_order
- _mod: M06

### UC-19 — Allocate Batch to Order

- primary_actor: Warehouse Manager
- goal: Reserve valid inventory without overselling
- preconditions: Order is confirmed or otherwise eligible; warehouse balance exists
- main_flow: Warehouse manager selects order; System identifies eligible graded batches; Computes available stock excluding existing reservations; Reserves quantities atomically by batch/order; Stores allocations and updates balances
- alternative_flows: Insufficient stock -> reject without partial mutation unless permitted; Duplicate reservation -> reject; Recalled batch -> ineligible
- postconditions: Valid order-to-batch allocations and quantities are conserved
- trigger: Order ready for stock allocation
- frequency: Not measured (coursework prototype)
- related_requirements: FR-018
- module_id: M06
- test_case_ids: TC-018
- web_implementation: allocate_order
- _mod: M06

### UC-20 — Fulfill Order

- primary_actor: Retail Order Coordinator
- goal: Move orders through fulfillment with safe cancellation
- preconditions: Order and required reservations exist
- main_flow: Coordinator confirms order; Records packed quantity; System validates transitions; Order links to shipment when dispatched; Delivery updates status Delivered; Cancellation releases eligible outstanding reservations
- alternative_flows: Invalid status transition -> reject; Shipment before packing -> reject; Cancelled order cannot ship; Reservation-release failure -> transaction rollback
- postconditions: Order status and reserved stock remain consistent
- trigger: Coordinator processes order
- frequency: Not measured (coursework prototype)
- related_requirements: FR-019
- module_id: M06
- test_case_ids: TC-019
- web_implementation: confirm_order / pack_order / shipment status
- _mod: M06

## test_cases

### TC-017 — Create valid retailer order

- related_requirements: FR-017
- type: Functional
- priority: Must
- preconditions: B-001 approved with stock.
- steps: 1 create_order(Retailer-1, B-001, A, 100). 2 Quantity 0. 3 Grade Z. 4 Unknown batch. 5 As farm role.
- expected_result: ORD-00001 Pending; invalid inputs rejected; farm -> AuthorizationError.
- status: PASS
- actual_result: Order ORD-00001 created with status Pending; qty 0 -> ValidationError; bad grade -> ValidationError; unknown batch -> NotFoundError; farm role -> AuthorizationError. Note: requested delivery date is not captured by the app (FR-017 lists it).
- executed_by: Automated script run_detailed_tests.py (sandbox, local SQLite)
- executed_date: 2026-10-22
- module_id: M06
- test_data: 100 kg A
- implementation_function: create_order
- evidence_scope: Local SQLite scenario result
- _mod: M06

### TC-018 — Allocate eligible inventory to order

- related_requirements: FR-018
- type: Functional
- priority: Must
- preconditions: A stock 600; order1=200, order2=500.
- steps: 1 Confirm+allocate order1. 2 Allocate order2 (available 400). 3 Re-allocate full order1. 4 Allocate order2 partial 400.
- expected_result: order1 reserved 200; order2 full -> ConflictError; re-allocate -> ValidationError; partial 400 -> reserved 600.
- status: PASS
- actual_result: Order 200 allocated -> reserved 200; order 500 vs available 400 -> ConflictError; re-allocating a full order -> ValidationError; partial allocation 400 allowed -> reserved 600 = on_hand (available 0).
- executed_by: Automated script run_detailed_tests.py (sandbox, local SQLite)
- executed_date: 2026-10-22
- module_id: M06
- test_data: 200; 500; 400
- implementation_function: allocate_order
- evidence_scope: Local SQLite scenario result
- _mod: M06

### TC-019 — Fulfill order through valid status transitions

- related_requirements: FR-019
- type: Functional
- priority: Must
- preconditions: B-001 stock A600; order for 100 kg.
- steps: 1 Pack a Pending order. 2 Allocate a Pending order. 3 Confirm, allocate, pack, ship, deliver, confirm receipt. 4 Look for a cancel function.
- expected_result: Skipped steps -> ConflictError; full chain accepted. Cancelled not implemented -> PARTIAL.
- status: PARTIAL
- actual_result: Transitions Pending -> Confirmed -> Allocated -> Packed -> Shipped -> Delivered -> Received accepted; skipping steps rejected (ConflictError). Cancelled status and release-on-cancel (required by FR-019) are NOT implemented in agritrace_service.py (cancel methods found: none).
- executed_by: Automated script run_detailed_tests.py (sandbox, local SQLite)
- executed_date: 2026-10-22
- module_id: M06
- test_data: 100 kg
- implementation_function: confirm_order / pack_order / shipment status
- evidence_scope: Local SQLite scenario result
- _mod: M06
- implementation_status: Implemented locally; cancellation regression added


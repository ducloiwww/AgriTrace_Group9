from modules.core import AgriTraceBase
from modules.accounts import AccountServiceMixin
from modules.orders import OrderServiceMixin

class AgriTraceService(OrderServiceMixin, AccountServiceMixin, AgriTraceBase):
    """Local composition: only the business methods required by M06."""
    pass

def create_service(db_path,qr_dir):
    return AgriTraceService(db_path,qr_dir)

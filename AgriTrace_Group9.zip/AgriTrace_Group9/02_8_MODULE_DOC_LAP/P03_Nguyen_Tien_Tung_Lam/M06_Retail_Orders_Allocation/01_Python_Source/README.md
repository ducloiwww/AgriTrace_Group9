# M06 — Retail Orders & Allocation (standalone)

- Member: Nguyễn Tiến Tùng Lâm
- All source files, service dependencies and local SQLite data are stored inside THIS module.
- No integrated application, other module folder, external server or external database is required.
- App: `python app.py` or double-click `run_windows.bat` (Windows).
- Local URL: http://127.0.0.1:8106
- Unit tests: `python run_tests.py` or `python -m unittest discover -s tests -v`.
- Demo CLI: `python demo_cli.py`.
- To reset demo data: stop the app, delete `data/module.sqlite3` and run again.
- The built-in sample accounts are `farm/Farm@123`, `admin/Admin@123`, `processor/Process@123`, `inspector/Inspect@123`, `warehouse/Warehouse@123`, `retailer/Retail@123`, `logistics/Logistics@123`.
- Choose the authorized account for each form. All demo fixtures created locally are independent and NOT synchronized with other modules.
- The original business methods were retained from the integrated project and wrapped in this local application; no production GPS/IoT/SMS integration is claimed.


## DỮ LIỆU ĐẦU VÀO THEO MASTER DATASET EXCEL
- `03_Requirements/excel_test_cases.json`: Test Cases gốc từ sheet `test_cases`; thông tin PASS trong bản này là lịch sử và không được tự cập nhật bởi runner.
- `03_Requirements/test_data_cases.json`: Kịch bản chạy được với fixture SQLite độc lập; input có thể khác ID/dữ liệu của Test Case Excel gốc.
- Khởi động `python app.py`, đăng nhập và mở **Dữ liệu Excel / Test Case** hoặc `/test-data`.
- Chạy `python run_data_tests.py --list` để xem ID.
- Chạy `python run_data_tests.py` để chạy tất cả; `python run_data_tests.py --case DT-M06-01` để chạy một ca.
- Kết quả mới: `02_Test_Logs/data_driven_execution.log` và `data_driven_results.json`, có Expected/Actual; KHÔNG sửa dữ liệu website.

import sys, unittest, tempfile
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from service import create_service
from bootstrap import seed_demo
from modules.core import AgriTraceError,AuthorizationError

class ModuleTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory()
        self.s=create_service(Path(self.temp.name)/'test.sqlite3',Path(self.temp.name)/'qr')
        seed_demo(self.s,'M06')
    def tearDown(self):self.temp.cleanup()
    def new(self):return self.s.create_order('retailer','Retail-01','B-DEMO','A',20,'2026-11-01')
    def test_create(self):
        oid=self.new();self.assertEqual(self.s._one('orders','order_id',oid)['status'],'Pending')
    def test_confirm_allocate_pack(self):
        oid=self.new();self.s.confirm_order('warehouse',oid);self.s.allocate_order('warehouse',oid);self.s.pack_order('warehouse',oid)
        self.assertEqual(self.s._one('orders','order_id',oid)['status'],'Packed')
    def test_reject_excess(self):
        oid=self.s.create_order('retailer','Retail-01','B-DEMO','A',100,'2026-11-01');self.s.confirm_order('warehouse',oid)
        with self.assertRaises(AgriTraceError):self.s.allocate_order('warehouse',oid)
    def test_cancel_restores_reserved(self):
        oid=self.new();self.s.confirm_order('warehouse',oid);self.s.allocate_order('warehouse',oid)
        self.s.cancel_order('retailer',oid,'Demo cancellation');self.assertEqual(self.s._one('inventory','batch_id','B-DEMO')['reserved'],0)
    def test_double_cancel_rejected(self):
        oid=self.new();self.s.cancel_order('retailer',oid,'First')
        with self.assertRaises(AgriTraceError):self.s.cancel_order('retailer',oid,'Again')
    def test_wrong_role_confirm(self):
        oid=self.new()
        with self.assertRaises(AuthorizationError):self.s.confirm_order('retailer',oid)

if __name__=='__main__':unittest.main()

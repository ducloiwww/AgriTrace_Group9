import unittest,tempfile
from pathlib import Path
from service import create_service
from bootstrap import seed_demo
from modules.core import ValidationError,ConflictError,NotFoundError,AuthorizationError

class ReviewTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory()
        self.s=create_service(Path(self.temp.name)/'testing.sqlite3',Path(self.temp.name)/'qr')
        seed_demo(self.s,'M06')
    def tearDown(self):self.temp.cleanup()
    def new(self):return self.s.create_order('retailer','Retail-01','B-DEMO','A',20,'2026-11-01')
    def test_edit_pending_order(self):
        oid=self.new()
        self.s.update_order('retailer',oid,'Retail-2',12,'2026-11-02')
        self.assertEqual(self.s._one('orders','order_id',oid)['quantity'],12)
        self.s.confirm_order('warehouse',oid)
        with self.assertRaises(ConflictError):self.s.update_order('retailer',oid,'Retail-3',11,'2026-11-02')
    def test_invalid_edit_keeps_order(self):
        oid=self.new()
        with self.assertRaises(ValidationError):self.s.update_order('retailer',oid,'Retail-2',-1,'2026-11-02')
        self.assertEqual(self.s._one('orders','order_id',oid)['quantity'],20)


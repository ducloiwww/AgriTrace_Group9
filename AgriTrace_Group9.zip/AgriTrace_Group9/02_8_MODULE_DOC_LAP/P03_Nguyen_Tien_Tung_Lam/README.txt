P03_Nguyen_Tien_Tung_Lam - Nguyễn Tiến Tùng Lâm
Hai module chạy hoàn toàn riêng, không dùng một app/database chung.
Cứ vào mỗi thư mục Mxx/01_Python_Source rồi nhấp đúp run_windows.bat.

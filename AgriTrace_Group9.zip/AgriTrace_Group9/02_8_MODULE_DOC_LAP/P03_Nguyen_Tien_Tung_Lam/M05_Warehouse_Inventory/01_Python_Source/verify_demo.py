"""Executable standalone smoke scenarios. Uses a temporary SQLite database."""
import tempfile,json,traceback
from pathlib import Path
from service import create_service
from bootstrap import seed_demo

def verify():
    with tempfile.TemporaryDirectory() as td:
        service=create_service(Path(td)/'smoke.sqlite3',Path(td)/'qr')
        seed_demo(service,'M05')
        s=service
        s.receive_inventory('warehouse','B-DEMO','A',20,'Warehouse A')
        s.update_stock_location('warehouse','B-DEMO','A','Warehouse B','Move')
        with s._db() as conn:
            row=conn.execute("SELECT * FROM inventory WHERE batch_id='B-DEMO' AND grade='A'").fetchone()
            assert row['on_hand']==20 and row['last_location']=='Warehouse B'
        from modules.core import ConflictError
        try:s.receive_inventory('warehouse','B-DEMO','A',100,'Warehouse B')
        except ConflictError:pass
        else:raise AssertionError('Exceed graded output must be rejected')
    return {'module':'M05','status':'PASS','scenario':'Kho và tồn kho','positive_and_negative_checked':True}

if __name__=='__main__':
    try:
        result=verify()
    except Exception as e:
        result={'module':'M05','status':'FAIL','error':str(e)}
        traceback.print_exc()
    print(json.dumps(result,ensure_ascii=False,indent=2))
    if result['status']!='PASS':raise SystemExit(1)

from modules.core import AgriTraceBase
from modules.accounts import AccountServiceMixin
from modules.inventory import InventoryServiceMixin

class AgriTraceService(InventoryServiceMixin, AccountServiceMixin, AgriTraceBase):
    """Local composition: only the business methods required by M05."""
    pass

def create_service(db_path,qr_dir):
    return AgriTraceService(db_path,qr_dir)

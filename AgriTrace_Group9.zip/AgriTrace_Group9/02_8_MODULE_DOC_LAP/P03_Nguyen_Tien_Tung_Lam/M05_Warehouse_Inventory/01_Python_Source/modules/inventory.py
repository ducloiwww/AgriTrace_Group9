"""AgriTrace modular SQLite inventory stock services.

Each mixin contains one cohesive responsibility; AgriTraceService composes them.
"""
from __future__ import annotations
from .core import (
    AgriTraceError, AuthorizationError, NotFoundError, ValidationError, ConflictError,
    ROLES, ROLE_ACTIONS, now_iso, _valid_date, _number, _valid_id, _required,
    hash_password, verify_password, sqlite3, secrets, json, datetime, date,
    timezone, math, re, hashlib, Path, Any
)

class InventoryServiceMixin:
    def receive_inventory(self, actor: str, batch_id: str, grade: str, quantity: float, location: str = "Main warehouse") -> None:
        self._authorize(actor, "inventory.receive")
        _required(Địa_điểm_kho=location)
        if grade not in {"A", "B", "C"}:
            raise ValidationError("Hạng phải là A, B hoặc C.")
        quantity = _number(quantity, "Số lượng nhập kho")
        if quantity <= 0:
            raise ValidationError("Số lượng nhập kho phải lớn hơn 0.")
        with self._db() as conn:
            batch = conn.execute("SELECT * FROM batches WHERE batch_id=?", (batch_id,)).fetchone()
            if not batch:
                raise NotFoundError("Không tìm thấy lô nông sản.")
            if batch["inspection_status"] != "Passed":
                raise ConflictError("Chỉ lô đã kiểm định Passed mới được nhập kho.")
            if batch["recalled"] or batch["review_hold"]:
                raise ConflictError("Lô bị thu hồi/giữ để xem xét không được nhập kho.")
            graded = float(batch[{"A": "grade_a", "B": "grade_b", "C": "grade_c"}[grade]])
            inv = conn.execute("SELECT * FROM inventory WHERE batch_id=? AND grade=?", (batch_id, grade)).fetchone()
            received = float(inv["received_total"]) if inv else 0.0
            if received + quantity > graded + 1e-9:
                raise ConflictError("Số lượng nhập vượt lượng đã phân loại cho hạng này.")
            conn.execute("INSERT INTO inventory(batch_id,grade,on_hand,reserved,received_total,last_received_at,last_location) VALUES(?,?,?,0,?,?,?) ON CONFLICT(batch_id,grade) DO UPDATE SET on_hand=on_hand+excluded.on_hand,received_total=received_total+excluded.received_total,last_received_at=excluded.last_received_at,last_location=excluded.last_location",
                         (batch_id, grade, float(quantity), float(quantity), now_iso(), location.strip()))
            self._audit(conn, actor, "inventory.received", "batch", batch_id, f"grade={grade};quantity={quantity};location={location.strip()}")

    def inventory_summary(self) -> list[dict[str, Any]]:
        with self._db() as conn:
            return [dict(r) for r in conn.execute("SELECT i.*, b.inspection_status, b.recalled, b.review_hold FROM inventory i JOIN batches b USING(batch_id) ORDER BY batch_id,grade")]


    def adjust_inventory(self, actor: str, batch_id: str, grade: str, quantity_delta: float, reason: str) -> None:
        """Record physical stock loss; positive stock creation must use inspected receipts.

        Never decreases stock below already-reserved quantity. Negative adjustments are
        kept in audit_log and do not alter historical received_total.
        """
        self._authorize(actor, "inventory.adjust")
        _required(Lý_do=reason)
        if grade not in {"A", "B", "C"}:
            raise ValidationError("Hạng phải là A, B hoặc C.")
        delta = _number(quantity_delta, "Lượng điều chỉnh")
        if delta >= 0:
            raise ValidationError("Chỉ hỗ trợ điều chỉnh giảm; hàng nhập bổ sung phải qua bước nhận hàng.")
        with self._db() as conn:
            inv = conn.execute("SELECT * FROM inventory WHERE batch_id=? AND grade=?", (batch_id, grade)).fetchone()
            if not inv:
                raise NotFoundError("Không tìm thấy tồn kho cần điều chỉnh.")
            if float(inv["on_hand"]) + delta < float(inv["reserved"]) - 1e-9:
                raise ConflictError("Không thể điều chỉnh giảm vượt tồn kho khả dụng.")
            conn.execute("UPDATE inventory SET on_hand=on_hand+? WHERE batch_id=? AND grade=?", (delta, batch_id, grade))
            self._audit(conn, actor, "inventory.adjusted", "batch", batch_id, f"grade={grade};delta={delta};reason={reason.strip()}")

    def update_stock_location(self, actor: str, batch_id: str, grade: str, location: str, reason: str) -> None:
        """Record stock-bin correction without changing physical stock totals."""
        self._authorize(actor,'inventory.adjust')
        _required(Vị_trí_kho=location,Lý_do_sửa=reason)
        if grade not in {'A','B','C'}:raise ValidationError('Hạng không hợp lệ.')
        with self._db() as conn:
            row=conn.execute('SELECT last_location FROM inventory WHERE batch_id=? AND grade=?',(batch_id,grade)).fetchone()
            if not row:raise NotFoundError('Không tìm thấy tồn kho.')
            conn.execute('UPDATE inventory SET last_location=? WHERE batch_id=? AND grade=?',(location.strip(),batch_id,grade))
            self._audit(conn,actor,'inventory.location_updated','batch',batch_id,
                        f'grade={grade};old={row["last_location"]};new={location.strip()};reason={reason.strip()}')

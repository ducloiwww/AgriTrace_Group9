# M05 Standalone Requirements Index

## functional_requirements

### FR-016 — Manage warehouse inventory

- description: The system shall allow an authorized Warehouse Manager to receive, reserve, release, and issue batch quantities while maintaining available and reserved stock.
- type: Functional
- priority: Must
- status: Approved
- source: SH-09
- rationale: Source: Lab 7 updated requirement baseline; post-Lab-4 expansion. See UC-17.
- acceptance_criteria: Inventory balances are updated atomically and never become negative.
- verification_method: Test
- complexity: 1
- dependencies: None
- tags: UC-17;full-supply-chain
- module_id: M05
- implementation_status: Implemented locally: receive, reserve by order, issue by shipment, loss adjustment and cancel-release
- linked_use_cases: UC-17
- designed_test_cases: TC-016
- _mod: M05

## use_cases

### UC-17 — Manage Warehouse Inventory

- primary_actor: Warehouse Manager
- goal: Track received, available, reserved and issued warehouse stock
- preconditions: Inspected/grading-eligible batch exists; warehouse user authorized
- main_flow: Warehouse manager receives eligible batch quantity; System increases on-hand quantity; Manager reserves or issues quantities; System atomically checks on-hand/available/reserved constraints; Stores stock ledger event
- alternative_flows: Insufficient available stock -> reject; Negative quantity -> reject; Uninspected batch -> reject
- postconditions: Inventory balances remain nonnegative and traceable
- trigger: Warehouse manager performs inventory movement
- frequency: Not measured (coursework prototype)
- related_requirements: FR-016
- module_id: M05
- test_case_ids: TC-016
- web_implementation: receive_inventory + allocate_order + create_shipment
- _mod: M05

## test_cases

### TC-016 — Warehouse receives and reserves inventory

- related_requirements: FR-016
- type: Functional
- priority: Must
- preconditions: B-001 Passed, graded A600/B250/C100.
- steps: 1 Receive A600. 2 Receive 1 more A. 3 Receive 0. 4 Receive grade D. 5 Allocate 200 to an order.
- expected_result: on_hand 600/reserved 0; over-receipt -> ConflictError; zero/invalid grade -> ValidationError; allocation gives reserved 200.
- status: PASS
- actual_result: Receive 600 A -> on_hand 600/reserved 0; over-receipt beyond graded -> ConflictError; zero -> ValidationError; unknown grade -> ValidationError; allocation 200 -> on_hand 600/reserved 200/available 400. Gap: no standalone 'release' or 'adjust' function; issue happens only at dispatch.
- executed_by: Automated script run_detailed_tests.py (sandbox, local SQLite)
- executed_date: 2026-10-22
- module_id: M05
- test_data: A 600; extra 1; grade D
- implementation_function: receive_inventory + allocate_order + create_shipment
- evidence_scope: Local SQLite scenario result
- _mod: M05


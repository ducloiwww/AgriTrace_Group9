import unittest,tempfile
from pathlib import Path
from service import create_service
from bootstrap import seed_demo
from modules.core import ValidationError,ConflictError,NotFoundError,AuthorizationError

class ReviewTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory()
        self.s=create_service(Path(self.temp.name)/'testing.sqlite3',Path(self.temp.name)/'qr')
        seed_demo(self.s,'M05')
    def tearDown(self):self.temp.cleanup()
    def new(self):return self.s.create_order('retailer','Retail-01','B-DEMO','A',20,'2026-11-01')
    def test_location_correction_preserves_stock(self):
        self.s.receive_inventory('warehouse','B-DEMO','A',20,'K1')
        self.s.update_stock_location('warehouse','B-DEMO','A','K2','Relocate')
        with self.s._db() as con:
            row=con.execute("SELECT on_hand,reserved,last_location FROM inventory WHERE batch_id='B-DEMO' AND grade='A'").fetchone()
            self.assertEqual((row['on_hand'],row['reserved'],row['last_location']),(20,0,'K2'))
    def test_location_requires_reason(self):
        self.s.receive_inventory('warehouse','B-DEMO','A',20,'K1')
        with self.assertRaises(ValidationError):self.s.update_stock_location('warehouse','B-DEMO','A','K2','')
        with self.s._db() as con:
            self.assertEqual(con.execute("SELECT last_location FROM inventory WHERE batch_id='B-DEMO' AND grade='A'").fetchone()[0],'K1')


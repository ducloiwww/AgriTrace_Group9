import sys, unittest, tempfile
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from service import create_service
from bootstrap import seed_demo
from modules.core import AgriTraceError,AuthorizationError

class ModuleTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory()
        self.s=create_service(Path(self.temp.name)/'test.sqlite3',Path(self.temp.name)/'qr')
        seed_demo(self.s,'M05')
    def tearDown(self):self.temp.cleanup()
    def test_receive_inventory(self):
        self.s.receive_inventory('warehouse','B-DEMO','A',20,'Main Warehouse')
        self.assertEqual(self.s.inventory_summary()[0]['on_hand'],20)
    def test_exceed_grade_rejected(self):
        with self.assertRaises(AgriTraceError):self.s.receive_inventory('warehouse','B-DEMO','A',61)
    def test_invalid_grade(self):
        with self.assertRaises(AgriTraceError):self.s.receive_inventory('warehouse','B-DEMO','D',2)
    def test_negative_quantity(self):
        with self.assertRaises(AgriTraceError):self.s.receive_inventory('warehouse','B-DEMO','A',-1)
    def test_adjust_inventory(self):
        self.s.receive_inventory('warehouse','B-DEMO','A',20)
        self.s.adjust_inventory('warehouse','B-DEMO','A',-2,'Spoilage')
        self.assertEqual(self.s.inventory_summary()[0]['on_hand'],18)
    def test_no_permission(self):
        with self.assertRaises(AuthorizationError):self.s.receive_inventory('retailer','B-DEMO','A',2)

if __name__=='__main__':unittest.main()

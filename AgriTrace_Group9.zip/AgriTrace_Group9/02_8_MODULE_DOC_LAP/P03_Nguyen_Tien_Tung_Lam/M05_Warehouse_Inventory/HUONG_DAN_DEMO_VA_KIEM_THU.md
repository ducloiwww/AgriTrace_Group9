# M05 — Warehouse & Inventory (bản cập nhật 29/10/2026)

## Mục tiêu trình diễn
Kho và tồn kho. Cập nhật vị trí kho nhưng không đổi số lượng; không nhập vượt lượng được phân loại.

## Các thao tác
nhập kho → sửa vị trí kho → điều chỉnh giảm → thử nhập quá số lượng.

1. Mở `01_Python_Source` bằng VS Code, chạy `python app.py`.
2. Truy cập `http://127.0.0.1:8105` và đăng nhập `warehouse` bằng mật khẩu demo `Warehouse@123`.
3. Chọn biểu mẫu tương ứng, xem bảng dữ liệu; bấm `Sửa` bên cạnh bản ghi nếu có.
4. Nhập dữ liệu sai để kiểm tra lỗi (như số âm, ngày không hợp lệ, sai trạng thái, quyền không đủ).
5. Kiểm tra dữ liệu không bị thay đổi khi hệ thống từ chối thao tác.
6. Dùng thanh tìm kiếm để tìm theo mã lô/đơn/trạng thái, rồi kiểm tra kết quả.

## Test và minh chứng
- `python run_tests.py` — unit test chạy trên database tạm.
- `python verify_demo.py` — smoke test nghiệp vụ (không thay đổi database giao diện).
- File thực thi: `tests/test_module.py`, `tests/test_review.py`.
- Kết quả ghi trong `02_Test_Logs` ở cấp thư mục module.

## Ràng buộc dữ liệu
Cập nhật vị trí kho nhưng không đổi số lượng; không nhập vượt lượng được phân loại.

## Phạm vi
Đây là bản demo độc lập dùng dữ liệu mẫu của riêng module, không tự đồng bộ với các ứng dụng khác. Không mô phỏng kết nối cảm biến/GPS thật. Lịch sử nghiệp vụ và audit quan trọng không được sửa trực tiếp.

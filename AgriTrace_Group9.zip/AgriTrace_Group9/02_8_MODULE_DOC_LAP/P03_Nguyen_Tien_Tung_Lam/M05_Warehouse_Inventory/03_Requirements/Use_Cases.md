# M05 — Use Cases

## UC-17 — Manage Warehouse Inventory
- primary_actor: Warehouse Manager
- goal: Track received, available, reserved and issued warehouse stock
- preconditions: Inspected/grading-eligible batch exists; warehouse user authorized
- main_flow: Warehouse manager receives eligible batch quantity; System increases on-hand quantity; Manager reserves or issues quantities; System atomically checks on-hand/available/reserved constraints; Stores stock ledger event
- alternative_flows: Insufficient available stock -> reject; Negative quantity -> reject; Uninspected batch -> reject
- postconditions: Inventory balances remain nonnegative and traceable
- trigger: Warehouse manager performs inventory movement
- frequency: Not measured (coursework prototype)
- related_requirements: FR-016
- module_id: M05
- test_case_ids: TC-016
- web_implementation: receive_inventory + allocate_order + create_shipment
- _mod: M05

# M05 — Functional Requirements

## FR-016 — Manage warehouse inventory
- description: The system shall allow an authorized Warehouse Manager to receive, reserve, release, and issue batch quantities while maintaining available and reserved stock.
- type: Functional
- priority: Must
- status: Approved
- source: SH-09
- rationale: Source: Lab 7 updated requirement baseline; post-Lab-4 expansion. See UC-17.
- acceptance_criteria: Inventory balances are updated atomically and never become negative.
- verification_method: Test
- complexity: 1
- dependencies: None
- tags: UC-17;full-supply-chain
- module_id: M05
- implementation_status: Implemented locally: receive, reserve by order, issue by shipment, loss adjustment and cancel-release
- linked_use_cases: UC-17
- designed_test_cases: TC-016
- _mod: M05

# M05 — Test Cases

## TC-016 — Warehouse receives and reserves inventory
- related_requirements: FR-016
- type: Functional
- priority: Must
- preconditions: B-001 Passed, graded A600/B250/C100.
- steps: 1 Receive A600. 2 Receive 1 more A. 3 Receive 0. 4 Receive grade D. 5 Allocate 200 to an order.
- expected_result: on_hand 600/reserved 0; over-receipt -> ConflictError; zero/invalid grade -> ValidationError; allocation gives reserved 200.
- status: PASS
- actual_result: Receive 600 A -> on_hand 600/reserved 0; over-receipt beyond graded -> ConflictError; zero -> ValidationError; unknown grade -> ValidationError; allocation 200 -> on_hand 600/reserved 200/available 400. Gap: no standalone 'release' or 'adjust' function; issue happens only at dispatch.
- executed_by: Automated script run_detailed_tests.py (sandbox, local SQLite)
- executed_date: 2026-10-22
- module_id: M05
- test_data: A 600; extra 1; grade D
- implementation_function: receive_inventory + allocate_order + create_shipment
- evidence_scope: Local SQLite scenario result
- _mod: M05

# M05 — Quy tắc kiểm tra bổ sung

- **Hành vi:** Cập nhật vị trí kho nhưng không đổi số lượng; không nhập vượt lượng được phân loại.
- **Luồng demo:** nhập kho → sửa vị trí kho → điều chỉnh giảm → thử nhập quá số lượng
- **Mã nguồn:** `01_Python_Source/modules`, `01_Python_Source/app.py`
- **Kiểm thử đã thực thi:** `tests/test_review.py`, `verify_demo.py`; không tự đồng nhất số lượng unit test với số TC thiết kế.
- **Mốc:** 29/10/2026; nội dung mới phục vụ giao diện cập nhật, chưa thay thế các FR/UC/TC gốc trong `specification.json`.

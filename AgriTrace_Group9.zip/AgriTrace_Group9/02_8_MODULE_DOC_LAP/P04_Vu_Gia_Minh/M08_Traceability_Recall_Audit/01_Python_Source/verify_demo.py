"""Executable standalone smoke scenarios. Uses a temporary SQLite database."""
import tempfile,json,traceback
from pathlib import Path
from service import create_service
from bootstrap import seed_demo

def verify():
    with tempfile.TemporaryDirectory() as td:
        service=create_service(Path(td)/'smoke.sqlite3',Path(td)/'qr')
        seed_demo(service,'M08')
        s=service
        token=s.generate_qr('farm','B-DEMO')
        assert s.trace(token)['batch']['batch_id']=='B-DEMO'
        s.recall_batch('inspector','B-DEMO','Smoke recall')
        assert s.trace(token)['batch']['recalled']==1
        from modules.core import AuthorizationError
        try:s.read_audit('farm')
        except AuthorizationError:pass
        else:raise AssertionError('Unauthorized audit view')
    return {'module':'M08','status':'PASS','scenario':'Truy xuất và thu hồi','positive_and_negative_checked':True}

if __name__=='__main__':
    try:
        result=verify()
    except Exception as e:
        result={'module':'M08','status':'FAIL','error':str(e)}
        traceback.print_exc()
    print(json.dumps(result,ensure_ascii=False,indent=2))
    if result['status']!='PASS':raise SystemExit(1)

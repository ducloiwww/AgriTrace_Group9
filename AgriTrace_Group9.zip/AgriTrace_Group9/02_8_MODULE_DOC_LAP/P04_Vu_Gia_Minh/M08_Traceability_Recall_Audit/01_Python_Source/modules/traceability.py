"""AgriTrace modular SQLite business services.

Each mixin contains one cohesive responsibility; AgriTraceService composes them.
"""
from __future__ import annotations
from .core import (
    AgriTraceError, AuthorizationError, NotFoundError, ValidationError, ConflictError,
    ROLES, ROLE_ACTIONS, now_iso, _valid_date, _number, _valid_id, _required,
    hash_password, verify_password, sqlite3, secrets, json, datetime, date,
    timezone, math, re, hashlib, Path, Any
)

class TraceabilityServiceMixin:
    def recall_batch(self, actor: str, batch_id: str, reason: str) -> None:
        self._authorize(actor, "recall.write")
        _required(Lý_do_thu_hồi=reason)
        with self._db() as conn:
            batch = conn.execute("SELECT * FROM batches WHERE batch_id=?", (batch_id,)).fetchone()
            if not batch:
                raise NotFoundError("Không tìm thấy lô nông sản.")
            if batch["recalled"]:
                raise ConflictError("Lô đã bị thu hồi.")
            conn.execute("UPDATE batches SET recalled=1,recall_reason=?,recall_at=?,review_hold=1,status='Recalled' WHERE batch_id=?",
                         (reason.strip(), now_iso(), batch_id))
            self._create_alerts(conn, batch_id, f"THU HỒI SẢN PHẨM: {reason.strip()}. Ngừng bán/sử dụng và làm theo quy trình an toàn của đơn vị.")
            self._audit(conn, actor, "recall.issued", "batch", batch_id, reason.strip())

    def release_safety_hold(self, actor: str, batch_id: str, review_note: str) -> None:
        self._authorize(actor, "safety.review")
        _required(Ghi_chú_đánh_giá=review_note)
        with self._db() as conn:
            batch = conn.execute("SELECT * FROM batches WHERE batch_id=?", (batch_id,)).fetchone()
            if not batch:
                raise NotFoundError("Không tìm thấy lô nông sản.")
            if batch["recalled"]:
                raise ConflictError("Không thể giải phóng lô đã có lệnh thu hồi; lệnh thu hồi phải được xử lý riêng theo quy trình an toàn.")
            if not batch["review_hold"]:
                raise ConflictError("Lô hiện không bị giữ để xem xét.")
            next_status = "Approved" if batch["inspection_status"] == "Passed" else "Quality Hold"
            conn.execute("UPDATE batches SET review_hold=0,status=? WHERE batch_id=?", (next_status, batch_id))
            conn.execute("INSERT INTO safety_reviews(batch_id,event_type,note,actor,event_at) VALUES(?,?,?,?,?)",
                         (batch_id, "Safety hold released", review_note.strip(), actor, now_iso()))
            self._create_alerts(conn, batch_id, f"ĐÃ GIẢI PHÓNG GIỮ AN TOÀN sau đánh giá được ủy quyền: {review_note.strip()}")
            self._audit(conn, actor, "safety.hold_released", "batch", batch_id, review_note.strip())

    def _create_alerts(self, conn: sqlite3.Connection, batch_id: str, message: str) -> None:
        targets = sorted(ROLE_ACTIONS.keys())
        for role in targets:
            conn.execute("INSERT INTO alerts(batch_id,target_role,message,created_at) VALUES(?,?,?,?)", (batch_id, role, message, now_iso()))

    def generate_qr(self, actor: str, batch_id: str) -> str:
        self._authorize(actor, "trace.generate")
        with self._db() as conn:
            row = conn.execute("SELECT qr_token FROM batches WHERE batch_id=?", (batch_id,)).fetchone()
            if not row:
                raise NotFoundError("Không tìm thấy lô nông sản.")
            if row["qr_token"]:
                return str(row["qr_token"])
            token = secrets.token_urlsafe(16)
            conn.execute("UPDATE batches SET qr_token=? WHERE batch_id=?", (token, batch_id))
            self._audit(conn, actor, "qr.generated", "batch", batch_id, token)
            return token

    def trace(self, identifier: str) -> dict[str, Any]:
        with self._db() as conn:
            batch = conn.execute("SELECT b.*,c.crop,c.farm_id,c.plot,c.planting_date,c.expected_harvest,f.name AS farm_name,f.region FROM batches b JOIN cycles c USING(cycle_id) JOIN farms f USING(farm_id) WHERE b.batch_id=? OR b.qr_token=?", (identifier, identifier)).fetchone()
            if not batch:
                raise NotFoundError("Không tìm thấy lô/QR. Hãy kiểm tra mã đã nhập.")
            b = dict(batch)
            timeline: list[dict[str, Any]] = [{"time": b["created_at"], "event": "Tạo lô", "detail": f"{b['crop']} · {b['farm_name']} · {b['region']} · chu kỳ {b['cycle_id']}"}]
            for ev in conn.execute("SELECT * FROM cultivation_events WHERE cycle_id=? ORDER BY event_date,id", (b["cycle_id"],)):
                timeline.append({"time": ev["event_date"], "event": "Canh tác", "detail": f"{ev['activity']} · {ev['public_note']}".strip(" ·")})
            if b["harvest_qty"] is not None:
                timeline.append({"time": b["harvest_date"], "event": "Thu hoạch", "detail": f"{b['harvest_qty']} kg"})
            for graded in conn.execute("SELECT * FROM audit_log WHERE entity_type='batch' AND entity_id=? AND action='harvest.graded' ORDER BY event_at,id", (b["batch_id"],)):
                try:
                    grade_detail = json.loads(graded["details"] or "{}")
                except json.JSONDecodeError:
                    grade_detail = {}
                timeline.append({"time": graded["event_at"], "event": "Phân loại", "detail": f"A: {grade_detail.get('A', b['grade_a'])} kg; B: {grade_detail.get('B', b['grade_b'])} kg; C: {grade_detail.get('C', b['grade_c'])} kg; loại bỏ: {grade_detail.get('rejected', b['rejected_qty'])} kg; nơi phân loại: {grade_detail.get('location', b['grading_location'])}"})
            if b["process_facility"]:
                timeline.append({"time": b["processing_date"], "event": "Chế biến", "detail": f"{b['process_facility']} · {b['package_details']}"})
                timeline.append({"time": b["packaging_date"], "event": "Đóng gói", "detail": b["package_details"]})
            for check in conn.execute("SELECT * FROM audit_log WHERE entity_type='batch' AND entity_id=? AND action LIKE 'quality.%' ORDER BY event_at,id", (b["batch_id"],)):
                timeline.append({"time": check["event_at"], "event": "Kiểm định chất lượng", "detail": f"{check['action'].split('.')[-1]} · {check['details']}"})
            for receipt in conn.execute("SELECT * FROM audit_log WHERE entity_type='batch' AND entity_id=? AND action='inventory.received' ORDER BY event_at,id", (b["batch_id"],)):
                timeline.append({"time": receipt["event_at"], "event": "Nhập kho", "detail": receipt["details"]})
            for inv in conn.execute("SELECT * FROM inventory WHERE batch_id=? ORDER BY grade", (b["batch_id"],)):
                timeline.append({"time": inv["last_received_at"] or b["created_at"], "event": "Tồn kho hiện tại", "detail": f"Hạng {inv['grade']}: đã nhập tổng {inv['received_total']} kg; hiện còn {inv['on_hand']} kg; vị trí gần nhất: {inv['last_location']}"})
            for s in conn.execute("SELECT * FROM shipments WHERE batch_id=? ORDER BY created_at", (b["batch_id"],)):
                timeline.append({"time": s["created_at"], "event": "Vận chuyển", "detail": f"{s['shipment_id']} · {s['status']} · {s['destination']} · {s['quantity']} kg"})
                for ev in conn.execute("SELECT * FROM shipment_events WHERE shipment_id=? ORDER BY event_at,id", (s["shipment_id"],)):
                    event_detail = f"{ev['location']} · {ev['note']}".strip(" ·")
                    if ev["temperature_c"] is not None:
                        event_detail += f" · {ev['temperature_c']}°C ({'NGOÀI NGƯỠNG' if ev['out_of_range'] else 'trong ngưỡng'})"
                    timeline.append({"time": ev["event_at"], "event": ev["event_type"], "detail": event_detail})
            for o in conn.execute("SELECT * FROM orders WHERE batch_id=? ORDER BY created_at", (b["batch_id"],)):
                for audit in conn.execute("SELECT * FROM audit_log WHERE entity_type='order' AND entity_id=? ORDER BY event_at,id", (o["order_id"],)):
                    timeline.append({"time": audit["event_at"], "event": "Lịch sử đơn hàng", "detail": f"{o['order_id']} · {audit['action']}" + (f" · {audit['details']}" if audit["details"] else "")})
                if o["received_qty"] is not None:
                    timeline.append({"time": o["received_at"], "event": "Xác nhận nhận hàng", "detail": f"Đơn {o['order_id']} · nhà bán lẻ {o['retailer_id']} · {o['received_qty']} kg"})
            for review in conn.execute("SELECT * FROM safety_reviews WHERE batch_id=? ORDER BY event_at,id", (b["batch_id"],)):
                timeline.append({"time": review["event_at"], "event": "Đánh giá an toàn", "detail": f"{review['event_type']} · {review['note']}"})
            if b["recalled"]:
                timeline.append({"time": b["recall_at"], "event": "CẢNH BÁO THU HỒI", "detail": b["recall_reason"]})
            timeline.sort(key=lambda item: item.get("time") or "")
            return {"batch": b, "timeline": timeline, "recalled": bool(b["recalled"]), "review_hold": bool(b["review_hold"])}

    # M08 consolidated audit, dashboards and role-specific alerts (former M09).
    def dashboard_data(self) -> dict[str, Any]:
        with self._db() as conn:
            counts = {}
            for table, label in [("farms", "farms"), ("cycles", "cycles"), ("batches", "batches"), ("orders", "orders"), ("shipments", "shipments")]:
                counts[label] = int(conn.execute(f"SELECT COUNT(*) FROM {table}").fetchone()[0])
            counts["alerts"] = int(conn.execute("SELECT COUNT(*) FROM alerts WHERE acknowledged=0").fetchone()[0])
            return counts

    def list_rows(self, view: str) -> list[dict[str, Any]]:
        queries = {
            "farms": "SELECT * FROM farms ORDER BY created_at DESC",
            "cycles": "SELECT c.*,f.name AS farm_name FROM cycles c JOIN farms f USING(farm_id) ORDER BY c.created_at DESC",
            "batches": "SELECT b.*,c.crop,c.farm_id FROM batches b JOIN cycles c USING(cycle_id) ORDER BY b.created_at DESC",
            "inventory": "SELECT i.*,b.status,b.inspection_status,b.recalled FROM inventory i JOIN batches b USING(batch_id) ORDER BY i.batch_id,i.grade",
            "orders": "SELECT o.*,s.shipment_id,s.status AS shipment_status FROM orders o LEFT JOIN shipments s USING(order_id) ORDER BY o.created_at DESC",
            "shipments": "SELECT s.*,o.retailer_id FROM shipments s JOIN orders o USING(order_id) ORDER BY s.created_at DESC",
            "alerts": "SELECT * FROM alerts ORDER BY created_at DESC LIMIT 100",
            "users": "SELECT username,display_name,role,active,created_at FROM users ORDER BY username",
        }
        if view not in queries:
            raise ValidationError("Bảng dữ liệu không hợp lệ.")
        with self._db() as conn:
            return [dict(row) for row in conn.execute(queries[view])]

    def read_audit(self, actor: str, limit: int = 150) -> list[dict[str, Any]]:
        self._authorize(actor, "audit.read")
        with self._db() as conn:
            return [dict(r) for r in conn.execute("SELECT * FROM audit_log ORDER BY id DESC LIMIT ?", (max(1, min(int(limit), 1000)),))]

    def alerts_for_role(self, role: str) -> list[dict[str, Any]]:
        with self._db() as conn:
            return [dict(r) for r in conn.execute("SELECT * FROM alerts WHERE target_role=? AND acknowledged=0 ORDER BY id DESC LIMIT 30", (role,))]

    def acknowledge_alert(self, actor: str, alert_id: int) -> None:
        user = self.get_user(actor)
        if not user:
            raise AuthorizationError("Không xác định được người dùng.")
        with self._db() as conn:
            row = conn.execute("SELECT * FROM alerts WHERE id=? AND target_role=?", (alert_id, user["role"])).fetchone()
            if not row:
                raise NotFoundError("Không tìm thấy cảnh báo dành cho vai trò của bạn.")
            conn.execute("UPDATE alerts SET acknowledged=1 WHERE id=?", (alert_id,))
            self._audit(conn, actor, "alert.acknowledged", "alert", str(alert_id), row["batch_id"])


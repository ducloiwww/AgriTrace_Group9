@echo off
cd /d "%~dp0"
python -c "import qrcode; import PIL" >nul 2>&1
if errorlevel 1 (
 echo Installing QR image dependency...
 python -m pip install -r requirements.txt
 if errorlevel 1 (echo Could not install QR package. & pause & exit /b 1)
)
python app.py
if errorlevel 1 (echo Python failed. Check python --version. & pause)

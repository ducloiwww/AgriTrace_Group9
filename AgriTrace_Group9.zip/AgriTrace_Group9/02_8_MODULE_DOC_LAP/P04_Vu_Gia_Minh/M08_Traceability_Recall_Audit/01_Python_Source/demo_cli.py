"""Simple console demonstrations without web or external modules."""
from pathlib import Path
import json
from service import create_service
from bootstrap import seed_demo
from modules.core import AgriTraceError

ROOT=Path(__file__).resolve().parent
MID='M08'
s=create_service(ROOT/'data'/'module.sqlite3',ROOT/'data'/'qr')
seed_demo(s,MID)
print('=== AgriTrace', MID,'— Public Traceability, Recall & Audit ===')
print('Standalone SQLite:',s.db_path)
print('Fixture data, independent from all other modules:')
with s._db() as conn:
    for table in ['batches', 'alerts', 'audit_log', 'shipments']:
        rows=[dict(row) for row in conn.execute('SELECT * FROM '+table+' LIMIT 10')]
        for row in rows:
            row.pop('password_hash',None)
        print(table+':',json.dumps(rows,ensure_ascii=False,default=str,indent=2))
print('Run python app.py for UI and python -m unittest discover -s tests -v for automated checks.')

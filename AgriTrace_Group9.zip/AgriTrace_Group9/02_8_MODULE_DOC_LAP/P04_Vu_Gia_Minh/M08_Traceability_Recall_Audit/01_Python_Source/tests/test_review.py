import unittest,tempfile
from pathlib import Path
from service import create_service
from bootstrap import seed_demo
from modules.core import ValidationError,ConflictError,NotFoundError,AuthorizationError

class ReviewTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory()
        self.s=create_service(Path(self.temp.name)/'testing.sqlite3',Path(self.temp.name)/'qr')
        seed_demo(self.s,'M08')
    def tearDown(self):self.temp.cleanup()
    def new(self):return self.s.create_order('retailer','Retail-01','B-DEMO','A',20,'2026-11-01')
    def test_audit_only_authorized_role(self):
        with self.assertRaises(AuthorizationError):self.s.read_audit('farm')
        self.assertIsInstance(self.s.read_audit('admin'),list)
    def test_alert_acknowledgement_protected(self):
        self.s.recall_batch('inspector','B-DEMO','Test recall')
        with self.s._db() as conn: aid=conn.execute('SELECT id FROM alerts LIMIT 1').fetchone()[0]
        with self.assertRaises(NotFoundError):self.s.acknowledge_alert('farm',aid) if self.s._one('alerts','id',aid)['target_role']!='Farm Manager' else self.s.acknowledge_alert('warehouse',aid)


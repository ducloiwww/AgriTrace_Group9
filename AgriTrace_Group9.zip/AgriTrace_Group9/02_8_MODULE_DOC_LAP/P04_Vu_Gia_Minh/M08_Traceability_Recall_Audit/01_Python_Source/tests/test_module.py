import sys, unittest, tempfile
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from service import create_service
from bootstrap import seed_demo
from modules.core import AgriTraceError,AuthorizationError

class ModuleTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory()
        self.s=create_service(Path(self.temp.name)/'test.sqlite3',Path(self.temp.name)/'qr')
        seed_demo(self.s,'M08')
    def tearDown(self):self.temp.cleanup()
    def test_trace(self):
        r=self.s.trace('B-DEMO');self.assertEqual(r['batch']['batch_id'],'B-DEMO')
    def test_qr_token(self):
        token=self.s.generate_qr('farm','B-DEMO');self.assertEqual(self.s.trace(token)['batch']['batch_id'],'B-DEMO')
    def test_recall(self):
        self.s.recall_batch('inspector','B-DEMO','Quality concern')
        self.assertTrue(self.s.trace('B-DEMO')['recalled'])
    def test_release_hold(self):
        with self.s._db() as conn:conn.execute("UPDATE batches SET review_hold=1 WHERE batch_id='B-DEMO'")
        self.s.release_safety_hold('inspector','B-DEMO','Verified')
        self.assertFalse(self.s.trace('B-DEMO')['review_hold'])
    def test_recall_permission(self):
        with self.assertRaises(AuthorizationError):self.s.recall_batch('retailer','B-DEMO','Unsafe')
    def test_audit_is_append_only(self):
        self.s.generate_qr('farm','B-DEMO');records=self.s.read_audit('admin')
        self.assertTrue(records)
        with self.assertRaises(Exception):
            with self.s._db() as conn:conn.execute('DELETE FROM audit_log')
    def test_alerts(self):
        self.s.recall_batch('inspector','B-DEMO','Risk')
        self.assertTrue(self.s.alerts_for_role('Retailer Manager'))

if __name__=='__main__':unittest.main()

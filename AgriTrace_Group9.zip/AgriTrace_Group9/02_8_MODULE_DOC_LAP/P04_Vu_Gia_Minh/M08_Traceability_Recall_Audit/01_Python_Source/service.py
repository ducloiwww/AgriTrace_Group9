from modules.core import AgriTraceBase
from modules.accounts import AccountServiceMixin
from modules.traceability import TraceabilityServiceMixin

class AgriTraceService(TraceabilityServiceMixin, AccountServiceMixin, AgriTraceBase):
    """Local composition: only the business methods required by M08."""
    pass

def create_service(db_path,qr_dir):
    return AgriTraceService(db_path,qr_dir)

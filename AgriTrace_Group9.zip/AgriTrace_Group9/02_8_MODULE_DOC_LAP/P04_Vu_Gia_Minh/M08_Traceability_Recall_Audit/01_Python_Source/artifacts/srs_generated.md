# M08 Standalone Requirements Index

## functional_requirements

### FR-009 — Generate QR traceability code

- description: The system shall generate a unique QR traceability code linked to each approved product batch.
- type: Functional
- priority: Must
- status: Approved
- source: SH-04
- rationale: Source: Lab 7 updated requirement baseline; Labs 1-4 core workflow. See UC-09.
- acceptance_criteria: The QR code resolves to the correct Batch ID.
- verification_method: Test
- complexity: 1
- dependencies: None
- tags: UC-09;full-supply-chain
- module_id: M08
- implementation_status: Implemented
- linked_use_cases: UC-09
- designed_test_cases: TC-009
- _mod: M08

### FR-010 — Trace product history

- description: When a consumer scans a valid QR code or enters a Batch ID, the system shall display the approved farm-to-retail traceability history.
- type: Functional
- priority: Must
- status: Approved
- source: SH-05
- rationale: Source: Lab 7 updated requirement baseline; Labs 1-4 core workflow. See UC-10.
- acceptance_criteria: Approved events are displayed and private notes excluded.
- verification_method: Test
- complexity: 1
- dependencies: None
- tags: UC-10;full-supply-chain
- module_id: M08
- implementation_status: Implemented
- linked_use_cases: UC-10
- designed_test_cases: TC-010
- _mod: M08

### FR-011 — Issue product batch recall

- description: When an authorized inspector activates a recall, the system shall mark the batch as recalled and expose a safety warning to trace requests.
- type: Functional
- priority: Must
- status: Approved
- source: SH-06
- rationale: Source: Lab 7 updated requirement baseline; Labs 1-4 core workflow. See UC-11.
- acceptance_criteria: Recalled status and warning are available to trace requests.
- verification_method: Test
- complexity: 1
- dependencies: None
- tags: UC-11;full-supply-chain
- module_id: M08
- implementation_status: Implemented (alerts in-app only)
- linked_use_cases: UC-11;UC-13
- designed_test_cases: TC-011
- _mod: M08

### FR-012 — Maintain supply-chain audit log

- description: The system shall record actor, timestamp, action, and Batch ID for protected create or update operations.
- type: Functional
- priority: Should
- status: Approved
- source: SH-07
- rationale: Source: Lab 7 updated requirement baseline; Labs 1-4 core workflow. See UC-12.
- acceptance_criteria: Every protected update produces an immutable audit entry.
- verification_method: Test
- complexity: 1
- dependencies: None
- tags: UC-12;full-supply-chain
- module_id: M08
- implementation_status: Implemented (DB immutability not enforced)
- linked_use_cases: UC-12
- designed_test_cases: TC-012
- _mod: M08

## use_cases

### UC-09 — Generate QR Traceability Code

- primary_actor: System
- goal: Assign a traceability QR reference to an approved batch
- preconditions: A valid approved batch exists
- main_flow: System receives QR generation request for Batch ID; System verifies batch eligibility; Generates or retrieves a stable unique trace token; Associates token with Batch ID; Returns QR payload for display/print
- alternative_flows: 2a Token already exists -> same token returned (idempotent). 1a Unknown batch -> NotFoundError. 1b Non-Farm role -> AuthorizationError.
- postconditions: A unique QR reference resolves to exactly one eligible batch
- trigger: Approved batch is published for traceability
- frequency: Not measured (coursework prototype)
- related_requirements: FR-009
- module_id: M08
- test_case_ids: TC-009
- web_implementation: generate_qr
- _mod: M08

### UC-10 — Trace Product History

- primary_actor: Consumer
- goal: Provide consumers with approved farm-to-retail provenance
- preconditions: A valid Batch ID or QR token is available; public trace endpoint accessible
- main_flow: 1 Consumer opens /trace/<token or Batch ID>. 2 System finds the batch. 3 System builds a time-ordered timeline: origin, cultivation, harvest, grading, processing, packaging, inspection, inventory, shipments, receipt. 4 System displays the timeline and any recall or hold warning.
- alternative_flows: Unknown token -> show Not found; Missing event -> show unavailable stage; Recalled -> conspicuous warning; Unauthorized private fields never disclosed
- postconditions: Consumer can view authorized provenance for the selected batch
- trigger: Consumer scans QR or types a Batch ID.
- frequency: Not measured (coursework prototype)
- related_requirements: FR-010
- module_id: M08
- test_case_ids: TC-010
- web_implementation: trace
- _mod: M08

### UC-11 — Issue Product Recall

- primary_actor: Food Safety / Regulatory Inspector
- goal: Activate recall and protect downstream supply chain
- preconditions: Authorized safety inspector selects an existing batch
- main_flow: 1 Select batch. 2 Enter recall reason. 3 System marks batch Recalled and Safety hold. 4 System creates alerts for operational roles. 5 System writes audit recall.issued. 6 Later orders, stock receipt, allocation and delivery on the batch are blocked.
- alternative_flows: 2a Blank reason -> ValidationError. 3a Already recalled -> ConflictError. 1a Non-authorized role -> AuthorizationError.
- postconditions: Recalled status is recorded and exposed to downstream trace queries
- trigger: Inspector opens Recall batch
- frequency: Not measured (coursework prototype)
- related_requirements: FR-011
- module_id: M08
- test_case_ids: TC-011
- web_implementation: recall_batch / release_safety_hold
- _mod: M08

### UC-12 — Review Audit Log

- primary_actor: System Administrator
- goal: Review tamper-resistant activity history
- preconditions: An authorized administrator and audit records exist
- main_flow: Administrator filters audit log by actor, Batch ID or time; System validates read privilege; Returns matching actor/time/action records; Administrator examines events; System records audit access when applicable
- alternative_flows: Unauthorized requester -> deny; No matching records -> show empty result
- postconditions: Authorized user views source-linked history without modification
- trigger: Administrator needs to review actions.
- frequency: Not measured (coursework prototype)
- related_requirements: FR-012
- module_id: M08
- test_case_ids: TC-012
- web_implementation: _audit / read_audit
- _mod: M08

### UC-13 — Display Recall Warning

- primary_actor: System
- goal: Display a safety notice for recalled batches
- preconditions: Product trace request matches a recalled batch
- main_flow: System loads batch recall status; Resolves active warning content and affected batch; Inserts prominent safety alert in trace result; Presents recall details and trace timestamp; Keeps normal history visible with warning
- alternative_flows: Recall metadata unavailable -> show safe fallback warning; Not recalled -> no recall banner
- postconditions: Public trace explicitly identifies recalled products
- trigger: Anyone requests trace of a recalled batch.
- frequency: Not measured (coursework prototype)
- related_requirements: FR-011
- module_id: M08
- test_case_ids: TC-011
- web_implementation: recall_batch / release_safety_hold
- _mod: M08

## test_cases

### TC-009 — QR resolves uniquely to original Batch ID

- related_requirements: FR-009
- type: Functional
- priority: Must
- preconditions: Batches B-001 and B-002 exist.
- steps: 1 generate_qr for each batch. 2 Generate again for B-001. 3 trace(token) for both. 4 trace('nope'). 5 generate_qr as retailer.
- expected_result: Distinct tokens; same token on repeat; each token resolves to its own Batch ID; unknown -> NotFoundError; retailer -> AuthorizationError.
- status: PASS
- actual_result: Two batches received distinct tokens (22 chars); token resolves to its own Batch ID; repeat generation returns same token; unknown token -> NotFoundError; non-farm user -> AuthorizationError.
- executed_by: Automated script run_detailed_tests.py (sandbox, local SQLite)
- executed_date: 2026-10-22
- module_id: M08
- test_data: tokens; 'nope'
- implementation_function: generate_qr
- evidence_scope: Local SQLite scenario result
- _mod: M08

### TC-010 — Consumer trace retrieves approved timeline

- related_requirements: FR-010
- type: Functional
- priority: Must
- preconditions: Batch B-001 completed full flow through retailer receipt.
- steps: 1 trace('B-001') without login. 2 Collect timeline event names.
- expected_result: Timeline contains origin, cultivation, harvest, grading, processing, packaging, inspection, inventory, shipment, receipt events.
- status: PASS
- actual_result: Consumer-facing trace displays approved origin, cultivation, harvest, grading, processing/packaging, inspection result, shipment status, receipt confirmation and safety warnings. Batch ID lookup works without login. Current stock, warehouse locations, order/retailer IDs and internal operational notes are filtered from the consumer view.
- executed_by: Automated script run_detailed_tests.py (sandbox, local SQLite)
- executed_date: 2026-10-22
- module_id: M08
- test_data: Batch ID B-001
- implementation_function: trace
- evidence_scope: Local SQLite scenario result
- _mod: M08

### TC-011 — Recalled batch displays safety warning

- related_requirements: FR-011
- type: Security / access control
- priority: Must
- preconditions: Batch B-001 approved and in inventory.
- steps: 1 recall_batch with blank reason. 2 recall_batch 'Pesticide residue above limit'. 3 trace B-001. 4 create_order on B-001. 5 recall again.
- expected_result: Blank -> ValidationError; recall stored; trace shows warning event; new order -> ConflictError; second recall -> ConflictError; alerts for roles.
- status: PASS
- actual_result: Empty reason -> ValidationError; recall stored; trace shows recall warning event; new order -> ConflictError; second recall -> ConflictError; 7 role alerts created.
- executed_by: Automated script run_detailed_tests.py (sandbox, local SQLite)
- executed_date: 2026-10-22
- module_id: M08
- test_data: reason text
- implementation_function: recall_batch / release_safety_hold
- evidence_scope: Local SQLite scenario result
- _mod: M08

### TC-012 — Supply-chain update writes immutable audit entry

- related_requirements: FR-012
- type: Security / access control
- priority: Must
- preconditions: Operations on B-001 completed.
- steps: 1 read_audit as admin. 2 read_audit as farm. 3 Inspect service for audit modify/delete methods.
- expected_result: Rows hold actor, time, action, entity; farm -> AuthorizationError; no public modify/delete method. DB-level immutability not enforced.
- status: PASS
- actual_result: 11 audit rows with actor/time/action/entity; admin can read; farm read -> AuthorizationError; no public audit modify/delete method found ([]). Database-level immutability not enforced (rows can be edited by direct SQL).
- executed_by: Automated script run_detailed_tests.py (sandbox, local SQLite)
- executed_date: 2026-10-22
- module_id: M08
- test_data: limit 500
- implementation_function: _audit / read_audit
- evidence_scope: Local SQLite scenario result
- _mod: M08


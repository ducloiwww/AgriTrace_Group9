# M08 — Use Cases

## UC-09 — Generate QR Traceability Code
- primary_actor: System
- goal: Assign a traceability QR reference to an approved batch
- preconditions: A valid approved batch exists
- main_flow: System receives QR generation request for Batch ID; System verifies batch eligibility; Generates or retrieves a stable unique trace token; Associates token with Batch ID; Returns QR payload for display/print
- alternative_flows: 2a Token already exists -> same token returned (idempotent). 1a Unknown batch -> NotFoundError. 1b Non-Farm role -> AuthorizationError.
- postconditions: A unique QR reference resolves to exactly one eligible batch
- trigger: Approved batch is published for traceability
- frequency: Not measured (coursework prototype)
- related_requirements: FR-009
- module_id: M08
- test_case_ids: TC-009
- web_implementation: generate_qr
- _mod: M08

## UC-10 — Trace Product History
- primary_actor: Consumer
- goal: Provide consumers with approved farm-to-retail provenance
- preconditions: A valid Batch ID or QR token is available; public trace endpoint accessible
- main_flow: 1 Consumer opens /trace/<token or Batch ID>. 2 System finds the batch. 3 System builds a time-ordered timeline: origin, cultivation, harvest, grading, processing, packaging, inspection, inventory, shipments, receipt. 4 System displays the timeline and any recall or hold warning.
- alternative_flows: Unknown token -> show Not found; Missing event -> show unavailable stage; Recalled -> conspicuous warning; Unauthorized private fields never disclosed
- postconditions: Consumer can view authorized provenance for the selected batch
- trigger: Consumer scans QR or types a Batch ID.
- frequency: Not measured (coursework prototype)
- related_requirements: FR-010
- module_id: M08
- test_case_ids: TC-010
- web_implementation: trace
- _mod: M08

## UC-11 — Issue Product Recall
- primary_actor: Food Safety / Regulatory Inspector
- goal: Activate recall and protect downstream supply chain
- preconditions: Authorized safety inspector selects an existing batch
- main_flow: 1 Select batch. 2 Enter recall reason. 3 System marks batch Recalled and Safety hold. 4 System creates alerts for operational roles. 5 System writes audit recall.issued. 6 Later orders, stock receipt, allocation and delivery on the batch are blocked.
- alternative_flows: 2a Blank reason -> ValidationError. 3a Already recalled -> ConflictError. 1a Non-authorized role -> AuthorizationError.
- postconditions: Recalled status is recorded and exposed to downstream trace queries
- trigger: Inspector opens Recall batch
- frequency: Not measured (coursework prototype)
- related_requirements: FR-011
- module_id: M08
- test_case_ids: TC-011
- web_implementation: recall_batch / release_safety_hold
- _mod: M08

## UC-12 — Review Audit Log
- primary_actor: System Administrator
- goal: Review tamper-resistant activity history
- preconditions: An authorized administrator and audit records exist
- main_flow: Administrator filters audit log by actor, Batch ID or time; System validates read privilege; Returns matching actor/time/action records; Administrator examines events; System records audit access when applicable
- alternative_flows: Unauthorized requester -> deny; No matching records -> show empty result
- postconditions: Authorized user views source-linked history without modification
- trigger: Administrator needs to review actions.
- frequency: Not measured (coursework prototype)
- related_requirements: FR-012
- module_id: M08
- test_case_ids: TC-012
- web_implementation: _audit / read_audit
- _mod: M08

## UC-13 — Display Recall Warning
- primary_actor: System
- goal: Display a safety notice for recalled batches
- preconditions: Product trace request matches a recalled batch
- main_flow: System loads batch recall status; Resolves active warning content and affected batch; Inserts prominent safety alert in trace result; Presents recall details and trace timestamp; Keeps normal history visible with warning
- alternative_flows: Recall metadata unavailable -> show safe fallback warning; Not recalled -> no recall banner
- postconditions: Public trace explicitly identifies recalled products
- trigger: Anyone requests trace of a recalled batch.
- frequency: Not measured (coursework prototype)
- related_requirements: FR-011
- module_id: M08
- test_case_ids: TC-011
- web_implementation: recall_batch / release_safety_hold
- _mod: M08

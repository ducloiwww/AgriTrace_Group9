# M08 — Quy tắc kiểm tra bổ sung

- **Hành vi:** Chỉ actor có quyền được thu hồi và đọc nhật ký; các lịch sử quan trọng là bất biến.
- **Luồng demo:** farm tạo QR → inspector thu hồi → admin xem audit → thử thay đổi audit trực tiếp
- **Mã nguồn:** `01_Python_Source/modules`, `01_Python_Source/app.py`
- **Kiểm thử đã thực thi:** `tests/test_review.py`, `verify_demo.py`; không tự đồng nhất số lượng unit test với số TC thiết kế.
- **Mốc:** 29/10/2026; nội dung mới phục vụ giao diện cập nhật, chưa thay thế các FR/UC/TC gốc trong `specification.json`.

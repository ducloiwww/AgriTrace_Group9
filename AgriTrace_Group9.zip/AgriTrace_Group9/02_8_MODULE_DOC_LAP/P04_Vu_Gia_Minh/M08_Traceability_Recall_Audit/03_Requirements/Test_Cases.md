# M08 — Test Cases

## TC-009 — QR resolves uniquely to original Batch ID
- related_requirements: FR-009
- type: Functional
- priority: Must
- preconditions: Batches B-001 and B-002 exist.
- steps: 1 generate_qr for each batch. 2 Generate again for B-001. 3 trace(token) for both. 4 trace('nope'). 5 generate_qr as retailer.
- expected_result: Distinct tokens; same token on repeat; each token resolves to its own Batch ID; unknown -> NotFoundError; retailer -> AuthorizationError.
- status: PASS
- actual_result: Two batches received distinct tokens (22 chars); token resolves to its own Batch ID; repeat generation returns same token; unknown token -> NotFoundError; non-farm user -> AuthorizationError.
- executed_by: Automated script run_detailed_tests.py (sandbox, local SQLite)
- executed_date: 2026-10-22
- module_id: M08
- test_data: tokens; 'nope'
- implementation_function: generate_qr
- evidence_scope: Local SQLite scenario result
- _mod: M08

## TC-010 — Consumer trace retrieves approved timeline
- related_requirements: FR-010
- type: Functional
- priority: Must
- preconditions: Batch B-001 completed full flow through retailer receipt.
- steps: 1 trace('B-001') without login. 2 Collect timeline event names.
- expected_result: Timeline contains origin, cultivation, harvest, grading, processing, packaging, inspection, inventory, shipment, receipt events.
- status: PASS
- actual_result: Consumer-facing trace displays approved origin, cultivation, harvest, grading, processing/packaging, inspection result, shipment status, receipt confirmation and safety warnings. Batch ID lookup works without login. Current stock, warehouse locations, order/retailer IDs and internal operational notes are filtered from the consumer view.
- executed_by: Automated script run_detailed_tests.py (sandbox, local SQLite)
- executed_date: 2026-10-22
- module_id: M08
- test_data: Batch ID B-001
- implementation_function: trace
- evidence_scope: Local SQLite scenario result
- _mod: M08

## TC-011 — Recalled batch displays safety warning
- related_requirements: FR-011
- type: Security / access control
- priority: Must
- preconditions: Batch B-001 approved and in inventory.
- steps: 1 recall_batch with blank reason. 2 recall_batch 'Pesticide residue above limit'. 3 trace B-001. 4 create_order on B-001. 5 recall again.
- expected_result: Blank -> ValidationError; recall stored; trace shows warning event; new order -> ConflictError; second recall -> ConflictError; alerts for roles.
- status: PASS
- actual_result: Empty reason -> ValidationError; recall stored; trace shows recall warning event; new order -> ConflictError; second recall -> ConflictError; 7 role alerts created.
- executed_by: Automated script run_detailed_tests.py (sandbox, local SQLite)
- executed_date: 2026-10-22
- module_id: M08
- test_data: reason text
- implementation_function: recall_batch / release_safety_hold
- evidence_scope: Local SQLite scenario result
- _mod: M08

## TC-012 — Supply-chain update writes immutable audit entry
- related_requirements: FR-012
- type: Security / access control
- priority: Must
- preconditions: Operations on B-001 completed.
- steps: 1 read_audit as admin. 2 read_audit as farm. 3 Inspect service for audit modify/delete methods.
- expected_result: Rows hold actor, time, action, entity; farm -> AuthorizationError; no public modify/delete method. DB-level immutability not enforced.
- status: PASS
- actual_result: 11 audit rows with actor/time/action/entity; admin can read; farm read -> AuthorizationError; no public audit modify/delete method found ([]). Database-level immutability not enforced (rows can be edited by direct SQL).
- executed_by: Automated script run_detailed_tests.py (sandbox, local SQLite)
- executed_date: 2026-10-22
- module_id: M08
- test_data: limit 500
- implementation_function: _audit / read_audit
- evidence_scope: Local SQLite scenario result
- _mod: M08

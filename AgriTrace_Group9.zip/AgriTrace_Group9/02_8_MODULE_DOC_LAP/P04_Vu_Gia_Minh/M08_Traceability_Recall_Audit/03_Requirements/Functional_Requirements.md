# M08 — Functional Requirements

## FR-009 — Generate QR traceability code
- description: The system shall generate a unique QR traceability code linked to each approved product batch.
- type: Functional
- priority: Must
- status: Approved
- source: SH-04
- rationale: Source: Lab 7 updated requirement baseline; Labs 1-4 core workflow. See UC-09.
- acceptance_criteria: The QR code resolves to the correct Batch ID.
- verification_method: Test
- complexity: 1
- dependencies: None
- tags: UC-09;full-supply-chain
- module_id: M08
- implementation_status: Implemented
- linked_use_cases: UC-09
- designed_test_cases: TC-009
- _mod: M08

## FR-010 — Trace product history
- description: When a consumer scans a valid QR code or enters a Batch ID, the system shall display the approved farm-to-retail traceability history.
- type: Functional
- priority: Must
- status: Approved
- source: SH-05
- rationale: Source: Lab 7 updated requirement baseline; Labs 1-4 core workflow. See UC-10.
- acceptance_criteria: Approved events are displayed and private notes excluded.
- verification_method: Test
- complexity: 1
- dependencies: None
- tags: UC-10;full-supply-chain
- module_id: M08
- implementation_status: Implemented
- linked_use_cases: UC-10
- designed_test_cases: TC-010
- _mod: M08

## FR-011 — Issue product batch recall
- description: When an authorized inspector activates a recall, the system shall mark the batch as recalled and expose a safety warning to trace requests.
- type: Functional
- priority: Must
- status: Approved
- source: SH-06
- rationale: Source: Lab 7 updated requirement baseline; Labs 1-4 core workflow. See UC-11.
- acceptance_criteria: Recalled status and warning are available to trace requests.
- verification_method: Test
- complexity: 1
- dependencies: None
- tags: UC-11;full-supply-chain
- module_id: M08
- implementation_status: Implemented (alerts in-app only)
- linked_use_cases: UC-11;UC-13
- designed_test_cases: TC-011
- _mod: M08

## FR-012 — Maintain supply-chain audit log
- description: The system shall record actor, timestamp, action, and Batch ID for protected create or update operations.
- type: Functional
- priority: Should
- status: Approved
- source: SH-07
- rationale: Source: Lab 7 updated requirement baseline; Labs 1-4 core workflow. See UC-12.
- acceptance_criteria: Every protected update produces an immutable audit entry.
- verification_method: Test
- complexity: 1
- dependencies: None
- tags: UC-12;full-supply-chain
- module_id: M08
- implementation_status: Implemented (DB immutability not enforced)
- linked_use_cases: UC-12
- designed_test_cases: TC-012
- _mod: M08

"""Executable standalone smoke scenarios. Uses a temporary SQLite database."""
import tempfile,json,traceback
from pathlib import Path
from service import create_service
from bootstrap import seed_demo

def verify():
    with tempfile.TemporaryDirectory() as td:
        service=create_service(Path(td)/'smoke.sqlite3',Path(td)/'qr')
        seed_demo(service,'M07')
        s=service
        sid=s.create_shipment('logistics','ORD-DEMO','Demo store')
        s.update_shipment_destination('logistics',sid,'Store B','Customer correction')
        assert s._one('shipments','shipment_id',sid)['destination']=='Store B'
        s.record_temperature('logistics',sid,12,2,8,'Checkpoint')
        from modules.core import ConflictError
        try:s.update_shipment_status('logistics',sid,'Delivered','Store B')
        except ConflictError:pass
        else:raise AssertionError('Cannot deliver held batch')
    return {'module':'M07','status':'PASS','scenario':'Vận chuyển và giao nhận','positive_and_negative_checked':True}

if __name__=='__main__':
    try:
        result=verify()
    except Exception as e:
        result={'module':'M07','status':'FAIL','error':str(e)}
        traceback.print_exc()
    print(json.dumps(result,ensure_ascii=False,indent=2))
    if result['status']!='PASS':raise SystemExit(1)

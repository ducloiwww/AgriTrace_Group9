import sys, unittest, tempfile
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from service import create_service
from bootstrap import seed_demo
from modules.core import AgriTraceError,AuthorizationError

class ModuleTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory()
        self.s=create_service(Path(self.temp.name)/'test.sqlite3',Path(self.temp.name)/'qr')
        seed_demo(self.s,'M07')
    def tearDown(self):self.temp.cleanup()
    def shipped(self):return self.s.create_shipment('logistics','ORD-DEMO','FreshMart Ha Noi')
    def test_create_shipment(self):
        sid=self.shipped();self.assertEqual(self.s._one('shipments','shipment_id',sid)['status'],'In Transit')
    def test_delivery(self):
        sid=self.shipped();self.s.update_shipment_status('logistics',sid,'Delivered','FreshMart')
        self.assertEqual(self.s._one('orders','order_id','ORD-DEMO')['status'],'Delivered')
    def test_confirm_receipt(self):
        sid=self.shipped();self.s.update_shipment_status('logistics',sid,'Delivered','FreshMart')
        self.s.confirm_receipt('retailer','ORD-DEMO',20,'OK');self.assertEqual(self.s._one('orders','order_id','ORD-DEMO')['status'],'Received')
    def test_temperature_alarm(self):
        sid=self.shipped();self.assertTrue(self.s.record_temperature('logistics',sid,12,2,8,'On road'))
        self.assertTrue(self.s._one('batches','batch_id','B-DEMO')['review_hold'])
    def test_hold_blocks_delivery(self):
        sid=self.shipped();self.s.record_temperature('logistics',sid,12,2,8,'On road')
        with self.assertRaises(AgriTraceError):self.s.update_shipment_status('logistics',sid,'Delivered','FreshMart')
    def test_invalid_receipt(self):
        sid=self.shipped();self.s.update_shipment_status('logistics',sid,'Delivered','FreshMart')
        with self.assertRaises(AgriTraceError):self.s.confirm_receipt('retailer','ORD-DEMO',100,'Too many')

if __name__=='__main__':unittest.main()

import unittest,tempfile
from pathlib import Path
from service import create_service
from bootstrap import seed_demo
from modules.core import ValidationError,ConflictError,NotFoundError,AuthorizationError

class ReviewTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory()
        self.s=create_service(Path(self.temp.name)/'testing.sqlite3',Path(self.temp.name)/'qr')
        seed_demo(self.s,'M07')
    def tearDown(self):self.temp.cleanup()
    def new(self):return self.s.create_order('retailer','Retail-01','B-DEMO','A',20,'2026-11-01')
    def test_change_destination_before_checkpoint(self):
        ship=self.s.create_shipment('logistics','ORD-DEMO','Store A')
        self.s.update_shipment_destination('logistics',ship,'Store B','Customer request')
        self.assertEqual(self.s._one('shipments','shipment_id',ship)['destination'],'Store B')
        self.s.record_temperature('logistics',ship,5,2,8,'Checkpoint')
        with self.assertRaises(ConflictError):self.s.update_shipment_destination('logistics',ship,'Store C','Too late')
    def test_destination_validation(self):
        ship=self.s.create_shipment('logistics','ORD-DEMO','Store A')
        with self.assertRaises(ValidationError):self.s.update_shipment_destination('logistics',ship,'','Reason')
        self.assertEqual(self.s._one('shipments','shipment_id',ship)['destination'],'Store A')


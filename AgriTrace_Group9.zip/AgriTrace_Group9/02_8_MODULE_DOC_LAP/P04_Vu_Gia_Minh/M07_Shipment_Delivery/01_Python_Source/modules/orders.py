"""AgriTrace modular SQLite business services.

Each mixin contains one cohesive responsibility; AgriTraceService composes them.
"""
from __future__ import annotations
from .core import (
    AgriTraceError, AuthorizationError, NotFoundError, ValidationError, ConflictError,
    ROLES, ROLE_ACTIONS, now_iso, _valid_date, _number, _valid_id, _required,
    hash_password, verify_password, sqlite3, secrets, json, datetime, date,
    timezone, math, re, hashlib, Path, Any
)

class OrderServiceMixin:
    def create_order(self, actor: str, retailer_id: str, batch_id: str, grade: str, quantity: float, requested_delivery_date: str = "") -> str:
        self._authorize(actor, "order.write")
        _required(Mã_nhà_bán_lẻ=retailer_id, Mã_lô=batch_id)
        quantity = _number(quantity, "Số lượng đặt hàng")
        if grade not in {"A", "B", "C"} or quantity <= 0:
            raise ValidationError("Hạng sản phẩm không hợp lệ hoặc số lượng không lớn hơn 0.")
        if requested_delivery_date:
            _valid_date(requested_delivery_date, "Ngày giao dự kiến")
        with self._db() as conn:
            batch = conn.execute("SELECT * FROM batches WHERE batch_id=?", (batch_id,)).fetchone()
            if not batch:
                raise NotFoundError("Không tìm thấy lô nông sản.")
            if batch["recalled"] or batch["review_hold"] or batch["inspection_status"] != "Passed":
                raise ConflictError("Không thể đặt hàng từ lô chưa duyệt, bị giữ hoặc đã thu hồi.")
            order_id = self._next_id(conn, "orders", "order_id", "ORD")
            conn.execute("INSERT INTO orders(order_id,retailer_id,batch_id,grade,quantity,status,requested_delivery_date,created_by,created_at) VALUES(?,?,?,?,?,'Pending',?,?,?)",
                         (order_id, retailer_id.strip(), batch_id, grade, float(quantity), requested_delivery_date, actor, now_iso()))
            self._audit(conn, actor, "order.created", "order", order_id, batch_id)
            return order_id

    @staticmethod
    def _next_id(conn: sqlite3.Connection, table: str, key: str, prefix: str) -> str:
        rows = conn.execute(f"SELECT {key} FROM {table} WHERE {key} LIKE ?", (prefix + "-%",)).fetchall()
        max_num = 0
        for row in rows:
            try:
                max_num = max(max_num, int(str(row[0]).split("-")[-1]))
            except ValueError:
                pass
        return f"{prefix}-{max_num + 1:05d}"

    def confirm_order(self, actor: str, order_id: str) -> None:
        self._authorize(actor, "order.confirm")
        with self._db() as conn:
            order = conn.execute("SELECT * FROM orders WHERE order_id=?", (order_id,)).fetchone()
            if not order:
                raise NotFoundError("Không tìm thấy đơn hàng.")
            if order["status"] != "Pending":
                raise ConflictError("Chỉ đơn Pending mới được xác nhận.")
            conn.execute("UPDATE orders SET status='Confirmed' WHERE order_id=?", (order_id,))
            self._audit(conn, actor, "order.confirmed", "order", order_id)

    def allocate_order(self, actor: str, order_id: str, quantity: float | None = None) -> None:
        self._authorize(actor, "order.allocate")
        with self._db() as conn:
            order = conn.execute("SELECT * FROM orders WHERE order_id=?", (order_id,)).fetchone()
            if not order:
                raise NotFoundError("Không tìm thấy đơn hàng.")
            if order["status"] not in {"Confirmed", "Allocated"}:
                raise ConflictError("Đơn hàng phải ở trạng thái Confirmed/Allocated.")
            batch = conn.execute("SELECT * FROM batches WHERE batch_id=?", (order["batch_id"],)).fetchone()
            if batch["recalled"] or batch["review_hold"] or batch["inspection_status"] != "Passed":
                raise ConflictError("Lô bị thu hồi/giữ hoặc chưa đạt kiểm định.")
            qty_left = float(order["quantity"]) - float(conn.execute("SELECT COALESCE(SUM(quantity),0) FROM allocations WHERE order_id=?", (order_id,)).fetchone()[0])
            qty = qty_left if quantity is None else _number(quantity, "Số lượng phân bổ")
            if qty <= 0 or qty > qty_left + 1e-9:
                raise ValidationError("Số lượng phân bổ phải dương và không vượt phần còn thiếu của đơn.")
            inv = conn.execute("SELECT * FROM inventory WHERE batch_id=? AND grade=?", (order["batch_id"], order["grade"])).fetchone()
            if not inv or float(inv["on_hand"])-float(inv["reserved"]) < qty - 1e-9:
                raise ConflictError("Tồn kho khả dụng không đủ.")
            conn.execute("UPDATE inventory SET reserved=reserved+? WHERE batch_id=? AND grade=?", (qty, order["batch_id"], order["grade"]))
            conn.execute("INSERT INTO allocations(order_id,batch_id,grade,quantity,created_by,created_at) VALUES(?,?,?,?,?,?)",
                         (order_id, order["batch_id"], order["grade"], qty, actor, now_iso()))
            total = float(conn.execute("SELECT COALESCE(SUM(quantity),0) FROM allocations WHERE order_id=?", (order_id,)).fetchone()[0])
            conn.execute("UPDATE orders SET status=? WHERE order_id=?", ("Allocated" if total >= float(order["quantity"])-1e-9 else "Confirmed", order_id))
            self._audit(conn, actor, "order.stock_allocated", "order", order_id, f"quantity={qty}")

    def pack_order(self, actor: str, order_id: str) -> None:
        self._authorize(actor, "order.pack")
        with self._db() as conn:
            order = conn.execute("SELECT * FROM orders WHERE order_id=?", (order_id,)).fetchone()
            if not order:
                raise NotFoundError("Không tìm thấy đơn hàng.")
            if order["status"] != "Allocated":
                raise ConflictError("Đơn hàng phải được phân bổ đủ trước khi đóng gói.")
            batch = conn.execute("SELECT * FROM batches WHERE batch_id=?", (order["batch_id"],)).fetchone()
            if batch["recalled"] or batch["review_hold"] or batch["inspection_status"] != "Passed":
                raise ConflictError("Lô bị thu hồi/giữ hoặc chưa đạt kiểm định, không thể đóng gói.")
            conn.execute("UPDATE orders SET status='Packed' WHERE order_id=?", (order_id,))
            self._audit(conn, actor, "order.packed", "order", order_id)


    def cancel_order(self, actor: str, order_id: str, reason: str) -> None:
        """Cancel a non-shipped order atomically and release any reserved quantities.

        Retailer may cancel own order; warehouse personnel may cancel any pre-shipment order.
        Cancellation is terminal; shipped/delivered/received orders are not cancellable here.
        """
        self._authorize(actor, "order.cancel")
        _required(Lý_do_hủy=reason)
        with self._db() as conn:
            order = conn.execute("SELECT * FROM orders WHERE order_id=?", (order_id,)).fetchone()
            if not order:
                raise NotFoundError("Không tìm thấy đơn hàng.")
            if order["status"] not in {"Pending", "Confirmed", "Allocated", "Packed"}:
                raise ConflictError("Chỉ có thể hủy đơn trước khi xuất vận chuyển.")
            if actor != "warehouse" and order["created_by"] != actor:
                raise AuthorizationError("Không thể hủy đơn của tài khoản khác.")
            allocated = float(conn.execute("SELECT COALESCE(SUM(quantity),0) FROM allocations WHERE order_id=?", (order_id,)).fetchone()[0])
            if allocated:
                inv = conn.execute("SELECT reserved FROM inventory WHERE batch_id=? AND grade=?", (order["batch_id"], order["grade"])).fetchone()
                if not inv or float(inv["reserved"]) + 1e-9 < allocated:
                    raise ConflictError("Lỗi nhất quán tồn kho: không đủ lượng đã giữ để giải phóng.")
                conn.execute("UPDATE inventory SET reserved=reserved-? WHERE batch_id=? AND grade=?", (allocated, order["batch_id"], order["grade"]))
                conn.execute("DELETE FROM allocations WHERE order_id=?", (order_id,))
            conn.execute("UPDATE orders SET status='Cancelled' WHERE order_id=?", (order_id,))
            self._audit(conn, actor, "order.cancelled", "order", order_id, f"reason={reason.strip()};released={allocated}")

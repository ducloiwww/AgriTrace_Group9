"""AgriTrace modular SQLite business services.

Each mixin contains one cohesive responsibility; AgriTraceService composes them.
"""
from __future__ import annotations
from .core import (
    AgriTraceError, AuthorizationError, NotFoundError, ValidationError, ConflictError,
    ROLES, ROLE_ACTIONS, now_iso, _valid_date, _number, _valid_id, _required,
    hash_password, verify_password, sqlite3, secrets, json, datetime, date,
    timezone, math, re, hashlib, Path, Any
)

class ShippingServiceMixin:
    def create_shipment(self, actor: str, order_id: str, destination: str) -> str:
        self._authorize(actor, "shipment.write")
        _required(Mã_đơn_hàng=order_id, Điểm_đến=destination)
        with self._db() as conn:
            order = conn.execute("SELECT * FROM orders WHERE order_id=?", (order_id,)).fetchone()
            if not order:
                raise NotFoundError("Không tìm thấy đơn hàng.")
            if order["status"] != "Packed":
                raise ConflictError("Chỉ đơn Packed mới được xuất vận chuyển.")
            batch = conn.execute("SELECT * FROM batches WHERE batch_id=?", (order["batch_id"],)).fetchone()
            if batch["recalled"] or batch["review_hold"] or batch["inspection_status"] != "Passed":
                raise ConflictError("Lô bị thu hồi/giữ hoặc chưa đạt kiểm định.")
            allocs = conn.execute("SELECT * FROM allocations WHERE order_id=?", (order_id,)).fetchall()
            if round(sum(float(a["quantity"]) for a in allocs), 6) != round(float(order["quantity"]), 6):
                raise ConflictError("Tổng phân bổ không khớp số lượng đơn.")
            for a in allocs:
                inv = conn.execute("SELECT * FROM inventory WHERE batch_id=? AND grade=?", (a["batch_id"], a["grade"])).fetchone()
                if not inv or float(inv["reserved"]) < float(a["quantity"]) or float(inv["on_hand"]) < float(a["quantity"]):
                    raise ConflictError("Tồn kho đã thay đổi; không thể xuất hàng.")
                conn.execute("UPDATE inventory SET reserved=reserved-?, on_hand=on_hand-? WHERE batch_id=? AND grade=?",
                             (a["quantity"], a["quantity"], a["batch_id"], a["grade"]))
            shipment_id = self._next_id(conn, "shipments", "shipment_id", "SHP")
            conn.execute("INSERT INTO shipments(shipment_id,order_id,batch_id,quantity,destination,status,created_by,created_at) VALUES(?,?,?,?,?,'In Transit',?,?)",
                         (shipment_id, order_id, order["batch_id"], order["quantity"], destination.strip(), actor, now_iso()))
            conn.execute("UPDATE orders SET status='Shipped' WHERE order_id=?", (order_id,))
            conn.execute("INSERT INTO shipment_events(shipment_id,event_type,location,note,event_at,created_by) VALUES(?,?,?,?,?,?)",
                         (shipment_id, "Dispatched", "Origin warehouse", destination.strip(), now_iso(), actor))
            self._audit(conn, actor, "shipment.dispatched", "shipment", shipment_id, order_id)
            return shipment_id

    def update_shipment_status(self, actor: str, shipment_id: str, status: str, location: str, note: str = "") -> None:
        self._authorize(actor, "shipment.write")
        if status not in {"In Transit", "Delivered", "Quarantined"}:
            raise ValidationError("Trạng thái vận chuyển không hợp lệ.")
        if not location.strip():
            raise ValidationError("Cần ghi địa điểm cập nhật.")
        with self._db() as conn:
            s = conn.execute("SELECT * FROM shipments WHERE shipment_id=?", (shipment_id,)).fetchone()
            if not s:
                raise NotFoundError("Không tìm thấy chuyến hàng.")
            if s["status"] in {"Delivered", "Quarantined"}:
                raise ConflictError("Chuyến hàng đã kết thúc (đã giao/cách ly), không thể đổi trạng thái.")
            batch = conn.execute("SELECT * FROM batches WHERE batch_id=?", (s["batch_id"],)).fetchone()
            if status == "Delivered" and (batch["recalled"] or batch["review_hold"] or batch["inspection_status"] != "Passed"):
                raise ConflictError("Không thể xác nhận giao khi lô bị thu hồi/giữ hoặc chưa đạt kiểm định; hãy cách ly chuyến hàng hoặc xử lý an toàn trước.")
            conn.execute("UPDATE shipments SET status=?,delivered_at=? WHERE shipment_id=?",
                         (status, now_iso() if status == "Delivered" else None, shipment_id))
            conn.execute("INSERT INTO shipment_events(shipment_id,event_type,location,note,event_at,created_by) VALUES(?,?,?,?,?,?)",
                         (shipment_id, status, location.strip(), note.strip(), now_iso(), actor))
            if status == "Delivered":
                conn.execute("UPDATE orders SET status='Delivered' WHERE order_id=?", (s["order_id"],))
            elif status == "Quarantined":
                conn.execute("UPDATE orders SET status='Quarantined' WHERE order_id=?", (s["order_id"],))
            self._audit(conn, actor, "shipment.status_updated", "shipment", shipment_id, status)

    def record_temperature(self, actor: str, shipment_id: str, temperature: float, min_allowed: float, max_allowed: float, location: str, timestamp: str = "") -> bool:
        self._authorize(actor, "temperature.write")
        temperature = _number(temperature, "Nhiệt độ")
        min_allowed = _number(min_allowed, "Ngưỡng nhiệt độ tối thiểu")
        max_allowed = _number(max_allowed, "Ngưỡng nhiệt độ tối đa")
        if min_allowed > max_allowed:
            raise ValidationError("Nhiệt độ tối thiểu không được lớn hơn tối đa.")
        if not str(location).strip():
            raise ValidationError("Cần ghi địa điểm kiểm tra nhiệt độ.")
        with self._db() as conn:
            s = conn.execute("SELECT * FROM shipments WHERE shipment_id=?", (shipment_id,)).fetchone()
            if not s:
                raise NotFoundError("Không tìm thấy chuyến hàng.")
            if s["status"] != "In Transit":
                raise ConflictError("Chỉ có thể cập nhật nhiệt độ khi hàng đang vận chuyển.")
            out = not (min_allowed <= temperature <= max_allowed)
            conn.execute("INSERT INTO shipment_events(shipment_id,event_type,location,note,temperature_c,min_allowed_c,max_allowed_c,out_of_range,event_at,created_by) VALUES(?,?,?,?,?,?,?,?,?,?)",
                         (shipment_id, "Temperature checkpoint", location.strip(), "", float(temperature), float(min_allowed), float(max_allowed), int(out), timestamp.strip() or now_iso(), actor))
            if out:
                conn.execute("UPDATE batches SET review_hold=1,status='Safety Review Hold' WHERE batch_id=? AND recalled=0", (s["batch_id"],))
                self._create_alerts(conn, s["batch_id"], f"CẢNH BÁO NHIỆT ĐỘ: {temperature}°C nằm ngoài khoảng {min_allowed}–{max_allowed}°C; tạm khóa lô để xem xét.")
            self._audit(conn, actor, "shipment.temperature_recorded", "shipment", shipment_id, f"temperature={temperature};out_of_range={out}")
            return out

    def confirm_receipt(self, actor: str, order_id: str, quantity: float, note: str = "") -> None:
        self._authorize(actor, "receipt.write")
        quantity = _number(quantity, "Số lượng nhận")
        if quantity <= 0:
            raise ValidationError("Số lượng nhận phải lớn hơn 0.")
        with self._db() as conn:
            order = conn.execute("SELECT * FROM orders WHERE order_id=?", (order_id,)).fetchone()
            if not order:
                raise NotFoundError("Không tìm thấy đơn hàng.")
            if order["status"] != "Delivered":
                raise ConflictError("Chỉ xác nhận nhận hàng sau khi chuyến hàng đã giao.")
            ship = conn.execute("SELECT * FROM shipments WHERE order_id=?", (order_id,)).fetchone()
            if not ship or quantity > float(ship["quantity"]) + 1e-9:
                raise ValidationError("Số lượng nhận không được vượt số lượng đã giao.")
            if order["received_qty"] is not None:
                raise ConflictError("Đơn hàng đã được xác nhận nhận.")
            conn.execute("UPDATE orders SET received_qty=?,received_at=?,status='Received' WHERE order_id=?", (float(quantity), now_iso(), order_id))
            self._audit(conn, actor, "retail.receipt_confirmed", "order", order_id, note)

    def update_shipment_destination(self, actor: str, shipment_id: str, destination: str, reason: str) -> None:
        """Allow a correction only before the first in-transit event/checkpoint."""
        self._authorize(actor,'shipment.write')
        _required(Điểm_đến=destination,Lý_do_sửa=reason)
        with self._db() as conn:
            row=conn.execute('SELECT * FROM shipments WHERE shipment_id=?',(shipment_id,)).fetchone()
            if not row:raise NotFoundError('Không tìm thấy chuyến hàng.')
            if row['status']!='In Transit':raise ConflictError('Không thể sửa điểm đến của chuyến hàng đã kết thúc.')
            n=conn.execute('SELECT COUNT(*) FROM shipment_events WHERE shipment_id=?',(shipment_id,)).fetchone()[0]
            if n>1:raise ConflictError('Chuyến hàng đã có cập nhật hành trình; không được thay đổi điểm đến trực tiếp.')
            conn.execute('UPDATE shipments SET destination=? WHERE shipment_id=?',(destination.strip(),shipment_id))
            self._audit(conn,actor,'shipment.destination_updated','shipment',shipment_id,
                        f'old={row["destination"]};new={destination.strip()};reason={reason.strip()}')

# M07 Standalone Requirements Index

## functional_requirements

### FR-007 — Track shipment and transportation status

- description: The system shall allow an authorized Distributor / Logistics Manager to create a shipment and update transportation status.
- type: Functional
- priority: Must
- status: Approved
- source: SH-03
- rationale: Source: Lab 7 updated requirement baseline; Labs 1-4 core workflow. See UC-07.
- acceptance_criteria: Shipment status updates are timestamped and linked to Batch ID.
- verification_method: Test
- complexity: 1
- dependencies: None
- tags: UC-07;full-supply-chain
- module_id: M07
- implementation_status: Implemented
- linked_use_cases: UC-07
- designed_test_cases: TC-007
- _mod: M07

### FR-008 — Confirm retailer receipt

- description: The system shall allow an authorized Retailer Manager to confirm receipt of a delivered agricultural batch.
- type: Functional
- priority: Should
- status: Approved
- source: SH-04
- rationale: Source: Lab 7 updated requirement baseline; Labs 1-4 core workflow. See UC-08.
- acceptance_criteria: Receipt confirmation stores retailer, batch, quantity, and timestamp.
- verification_method: Test
- complexity: 1
- dependencies: None
- tags: UC-08;full-supply-chain
- module_id: M07
- implementation_status: Implemented
- linked_use_cases: UC-08
- designed_test_cases: TC-008
- _mod: M07

### FR-020 — Track distribution destination

- description: The system shall record the order, shipment, destination retailer, dispatched batch quantities, and delivery confirmation so that downstream distribution is traceable.
- type: Functional
- priority: Must
- status: Approved
- source: SH-03
- rationale: Source: Lab 7 updated requirement baseline; post-Lab-4 expansion. See UC-21.
- acceptance_criteria: Every dispatched quantity has a valid order, shipment, destination, and Batch ID.
- verification_method: Test
- complexity: 1
- dependencies: None
- tags: UC-21;full-supply-chain
- module_id: M07
- implementation_status: Implemented
- linked_use_cases: UC-21
- designed_test_cases: TC-020
- _mod: M07

## use_cases

### UC-07 — Manage Shipment

- primary_actor: Distributor / Logistics Manager
- goal: Create and monitor a shipment for eligible batches
- preconditions: Batch passes required inspection; shipment user authorized
- main_flow: 1 Select packed order. 2 Enter destination. 3 System checks allocations equal order quantity and batch is eligible. 4 System issues stock (on_hand and reserved decrease), creates shipment In Transit and event Dispatched. 5 Logistics adds location updates and temperature checkpoints. 6 Logistics marks Delivered.
- alternative_flows: 3a Order not Packed -> ConflictError. 3b Batch recalled/held -> ConflictError. 5a Temperature outside range -> batch Safety Review Hold, alerts. 6a Delivered while hold -> ConflictError. 6b Update after Delivered/Quarantined -> ConflictError.
- postconditions: Shipment status history is timestamped and linked to Batch ID.
- trigger: Order is ready to leave the warehouse.
- frequency: Not measured (coursework prototype)
- related_requirements: FR-007
- module_id: M07
- test_case_ids: TC-007
- web_implementation: create_shipment / update_shipment_status / record_temperature
- _mod: M07

### UC-08 — Confirm Retail Receipt

- primary_actor: Retailer Manager
- goal: Confirm delivery receipt at a retailer
- preconditions: A delivered shipment exists for retailer
- main_flow: 1 Select delivered order. 2 Enter received quantity and note. 3 System checks quantity > 0, not above shipped quantity and no earlier receipt. 4 System stores receipt and sets order Received. 5 Audit retail.receipt_confirmed.
- alternative_flows: 3a Not yet delivered -> ConflictError. 3b Quantity above shipped -> ValidationError. 3c Already confirmed -> ConflictError.
- postconditions: Receipt stored with retailer, batch, quantity and time.
- trigger: Goods arrive at the retailer.
- frequency: Not measured (coursework prototype)
- related_requirements: FR-008
- module_id: M07
- test_case_ids: TC-008
- web_implementation: confirm_receipt
- _mod: M07

### UC-21 — Track Order and Distribution

- primary_actor: Distributor / Logistics Manager
- goal: Maintain downstream order-to-retailer distribution links
- preconditions: Order has allocated eligible batches and an authorized distributor
- main_flow: Distributor selects order shipment; Confirms allocated Batch IDs and quantities; Adds retailer destination; Records dispatch and delivery events; System links order, shipment, batch and retailer; Publishes authorized distribution stage to trace history
- alternative_flows: Mismatched batch/order -> reject; Unallocated quantity -> block dispatch; Missing destination -> reject
- postconditions: Each dispatched quantity has resolvable order/batch/shipment/retailer linkage
- trigger: Distributor dispatches or tracks order
- frequency: Not measured (coursework prototype)
- related_requirements: FR-020
- module_id: M07
- test_case_ids: TC-020
- web_implementation: create_shipment / update_shipment_status
- _mod: M07

## test_cases

### TC-007 — Distributor records shipment transitions

- related_requirements: FR-007
- type: Functional
- priority: Must
- preconditions: Order of 200 kg is Packed; second order only Allocated.
- steps: 1 create_shipment on non-packed order. 2 create_shipment on Packed order to 'Retail Store, Ha Noi'. 3 update_shipment_status Delivered. 4 Update after delivery. 5 Update with status 'Flying'.
- expected_result: Shipment starts In Transit then Delivered; unpacked order -> ConflictError; change after delivery -> ConflictError; invalid status -> ValidationError.
- status: PASS
- actual_result: Shipment SHP-00001 dispatched (In Transit) then Delivered, final status Delivered; dispatch of unpacked order -> ConflictError; change after delivery -> ConflictError; invalid status -> ValidationError.
- executed_by: Automated script run_detailed_tests.py (sandbox, local SQLite)
- executed_date: 2026-10-22
- module_id: M07
- test_data: 200 kg; destination Retail Store, Ha Noi
- implementation_function: create_shipment / update_shipment_status / record_temperature
- evidence_scope: Local SQLite scenario result
- _mod: M07

### TC-008 — Retailer confirms delivered shipment

- related_requirements: FR-008
- type: Functional
- priority: Must
- preconditions: Shipment of 200 kg In Transit for order ORD-00001.
- steps: 1 confirm_receipt before delivery. 2 Mark shipment Delivered. 3 confirm_receipt 201. 4 confirm_receipt 200. 5 confirm_receipt again.
- expected_result: Before delivery -> ConflictError; 201 > 200 -> ValidationError; 200 accepted (order Received); duplicate -> ConflictError.
- status: PASS
- actual_result: Before delivery -> ConflictError; receipt 201 > 200 shipped -> ValidationError; receipt 200 accepted, order status Received; duplicate receipt -> ConflictError.
- executed_by: Automated script run_detailed_tests.py (sandbox, local SQLite)
- executed_date: 2026-10-22
- module_id: M07
- test_data: 201 kg then 200 kg
- implementation_function: confirm_receipt
- evidence_scope: Local SQLite scenario result
- _mod: M07

### TC-020 — Distribution destination links order shipment and batch

- related_requirements: FR-020
- type: Functional
- priority: Must
- preconditions: Packed order ORD-00001 (200 kg).
- steps: 1 create_shipment to 'Retail Store, Ha Noi'. 2 Read shipment row and inventory.
- expected_result: Shipment links order, batch, quantity, destination; on_hand 600->400, reserved 200->0.
- status: PASS
- actual_result: SHP-00001 links order ORD-00001, batch B-001, qty 200, destination 'Retail Store, Ha Noi'; stock issued at dispatch: on_hand 600->400, reserved 200->0; shipment in public trace.
- executed_by: Automated script run_detailed_tests.py (sandbox, local SQLite)
- executed_date: 2026-10-22
- module_id: M07
- test_data: 200 kg
- implementation_function: create_shipment / update_shipment_status
- evidence_scope: Local SQLite scenario result
- _mod: M07


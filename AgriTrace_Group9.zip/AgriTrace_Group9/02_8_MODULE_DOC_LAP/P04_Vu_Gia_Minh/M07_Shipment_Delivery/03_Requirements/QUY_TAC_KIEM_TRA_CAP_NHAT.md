# M07 — Quy tắc kiểm tra bổ sung

- **Hành vi:** Điều chỉnh điểm đến trước checkpoint; nhiệt độ ngoài ngưỡng kích hoạt giữ an toàn.
- **Luồng demo:** tạo chuyến → đổi điểm đến → ghi nhiệt độ → thử đổi điểm đến quá muộn
- **Mã nguồn:** `01_Python_Source/modules`, `01_Python_Source/app.py`
- **Kiểm thử đã thực thi:** `tests/test_review.py`, `verify_demo.py`; không tự đồng nhất số lượng unit test với số TC thiết kế.
- **Mốc:** 29/10/2026; nội dung mới phục vụ giao diện cập nhật, chưa thay thế các FR/UC/TC gốc trong `specification.json`.

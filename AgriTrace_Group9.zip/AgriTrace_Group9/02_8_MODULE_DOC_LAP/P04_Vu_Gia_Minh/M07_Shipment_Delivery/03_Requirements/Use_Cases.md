# M07 — Use Cases

## UC-07 — Manage Shipment
- primary_actor: Distributor / Logistics Manager
- goal: Create and monitor a shipment for eligible batches
- preconditions: Batch passes required inspection; shipment user authorized
- main_flow: 1 Select packed order. 2 Enter destination. 3 System checks allocations equal order quantity and batch is eligible. 4 System issues stock (on_hand and reserved decrease), creates shipment In Transit and event Dispatched. 5 Logistics adds location updates and temperature checkpoints. 6 Logistics marks Delivered.
- alternative_flows: 3a Order not Packed -> ConflictError. 3b Batch recalled/held -> ConflictError. 5a Temperature outside range -> batch Safety Review Hold, alerts. 6a Delivered while hold -> ConflictError. 6b Update after Delivered/Quarantined -> ConflictError.
- postconditions: Shipment status history is timestamped and linked to Batch ID.
- trigger: Order is ready to leave the warehouse.
- frequency: Not measured (coursework prototype)
- related_requirements: FR-007
- module_id: M07
- test_case_ids: TC-007
- web_implementation: create_shipment / update_shipment_status / record_temperature
- _mod: M07

## UC-08 — Confirm Retail Receipt
- primary_actor: Retailer Manager
- goal: Confirm delivery receipt at a retailer
- preconditions: A delivered shipment exists for retailer
- main_flow: 1 Select delivered order. 2 Enter received quantity and note. 3 System checks quantity > 0, not above shipped quantity and no earlier receipt. 4 System stores receipt and sets order Received. 5 Audit retail.receipt_confirmed.
- alternative_flows: 3a Not yet delivered -> ConflictError. 3b Quantity above shipped -> ValidationError. 3c Already confirmed -> ConflictError.
- postconditions: Receipt stored with retailer, batch, quantity and time.
- trigger: Goods arrive at the retailer.
- frequency: Not measured (coursework prototype)
- related_requirements: FR-008
- module_id: M07
- test_case_ids: TC-008
- web_implementation: confirm_receipt
- _mod: M07

## UC-21 — Track Order and Distribution
- primary_actor: Distributor / Logistics Manager
- goal: Maintain downstream order-to-retailer distribution links
- preconditions: Order has allocated eligible batches and an authorized distributor
- main_flow: Distributor selects order shipment; Confirms allocated Batch IDs and quantities; Adds retailer destination; Records dispatch and delivery events; System links order, shipment, batch and retailer; Publishes authorized distribution stage to trace history
- alternative_flows: Mismatched batch/order -> reject; Unallocated quantity -> block dispatch; Missing destination -> reject
- postconditions: Each dispatched quantity has resolvable order/batch/shipment/retailer linkage
- trigger: Distributor dispatches or tracks order
- frequency: Not measured (coursework prototype)
- related_requirements: FR-020
- module_id: M07
- test_case_ids: TC-020
- web_implementation: create_shipment / update_shipment_status
- _mod: M07

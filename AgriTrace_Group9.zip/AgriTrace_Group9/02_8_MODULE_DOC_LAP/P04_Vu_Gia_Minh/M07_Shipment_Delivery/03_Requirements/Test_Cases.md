# M07 — Test Cases

## TC-007 — Distributor records shipment transitions
- related_requirements: FR-007
- type: Functional
- priority: Must
- preconditions: Order of 200 kg is Packed; second order only Allocated.
- steps: 1 create_shipment on non-packed order. 2 create_shipment on Packed order to 'Retail Store, Ha Noi'. 3 update_shipment_status Delivered. 4 Update after delivery. 5 Update with status 'Flying'.
- expected_result: Shipment starts In Transit then Delivered; unpacked order -> ConflictError; change after delivery -> ConflictError; invalid status -> ValidationError.
- status: PASS
- actual_result: Shipment SHP-00001 dispatched (In Transit) then Delivered, final status Delivered; dispatch of unpacked order -> ConflictError; change after delivery -> ConflictError; invalid status -> ValidationError.
- executed_by: Automated script run_detailed_tests.py (sandbox, local SQLite)
- executed_date: 2026-10-22
- module_id: M07
- test_data: 200 kg; destination Retail Store, Ha Noi
- implementation_function: create_shipment / update_shipment_status / record_temperature
- evidence_scope: Local SQLite scenario result
- _mod: M07

## TC-008 — Retailer confirms delivered shipment
- related_requirements: FR-008
- type: Functional
- priority: Must
- preconditions: Shipment of 200 kg In Transit for order ORD-00001.
- steps: 1 confirm_receipt before delivery. 2 Mark shipment Delivered. 3 confirm_receipt 201. 4 confirm_receipt 200. 5 confirm_receipt again.
- expected_result: Before delivery -> ConflictError; 201 > 200 -> ValidationError; 200 accepted (order Received); duplicate -> ConflictError.
- status: PASS
- actual_result: Before delivery -> ConflictError; receipt 201 > 200 shipped -> ValidationError; receipt 200 accepted, order status Received; duplicate receipt -> ConflictError.
- executed_by: Automated script run_detailed_tests.py (sandbox, local SQLite)
- executed_date: 2026-10-22
- module_id: M07
- test_data: 201 kg then 200 kg
- implementation_function: confirm_receipt
- evidence_scope: Local SQLite scenario result
- _mod: M07

## TC-020 — Distribution destination links order shipment and batch
- related_requirements: FR-020
- type: Functional
- priority: Must
- preconditions: Packed order ORD-00001 (200 kg).
- steps: 1 create_shipment to 'Retail Store, Ha Noi'. 2 Read shipment row and inventory.
- expected_result: Shipment links order, batch, quantity, destination; on_hand 600->400, reserved 200->0.
- status: PASS
- actual_result: SHP-00001 links order ORD-00001, batch B-001, qty 200, destination 'Retail Store, Ha Noi'; stock issued at dispatch: on_hand 600->400, reserved 200->0; shipment in public trace.
- executed_by: Automated script run_detailed_tests.py (sandbox, local SQLite)
- executed_date: 2026-10-22
- module_id: M07
- test_data: 200 kg
- implementation_function: create_shipment / update_shipment_status
- evidence_scope: Local SQLite scenario result
- _mod: M07

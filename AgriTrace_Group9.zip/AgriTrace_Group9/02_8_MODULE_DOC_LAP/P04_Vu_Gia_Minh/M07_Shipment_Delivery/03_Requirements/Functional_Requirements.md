# M07 — Functional Requirements

## FR-007 — Track shipment and transportation status
- description: The system shall allow an authorized Distributor / Logistics Manager to create a shipment and update transportation status.
- type: Functional
- priority: Must
- status: Approved
- source: SH-03
- rationale: Source: Lab 7 updated requirement baseline; Labs 1-4 core workflow. See UC-07.
- acceptance_criteria: Shipment status updates are timestamped and linked to Batch ID.
- verification_method: Test
- complexity: 1
- dependencies: None
- tags: UC-07;full-supply-chain
- module_id: M07
- implementation_status: Implemented
- linked_use_cases: UC-07
- designed_test_cases: TC-007
- _mod: M07

## FR-008 — Confirm retailer receipt
- description: The system shall allow an authorized Retailer Manager to confirm receipt of a delivered agricultural batch.
- type: Functional
- priority: Should
- status: Approved
- source: SH-04
- rationale: Source: Lab 7 updated requirement baseline; Labs 1-4 core workflow. See UC-08.
- acceptance_criteria: Receipt confirmation stores retailer, batch, quantity, and timestamp.
- verification_method: Test
- complexity: 1
- dependencies: None
- tags: UC-08;full-supply-chain
- module_id: M07
- implementation_status: Implemented
- linked_use_cases: UC-08
- designed_test_cases: TC-008
- _mod: M07

## FR-020 — Track distribution destination
- description: The system shall record the order, shipment, destination retailer, dispatched batch quantities, and delivery confirmation so that downstream distribution is traceable.
- type: Functional
- priority: Must
- status: Approved
- source: SH-03
- rationale: Source: Lab 7 updated requirement baseline; post-Lab-4 expansion. See UC-21.
- acceptance_criteria: Every dispatched quantity has a valid order, shipment, destination, and Batch ID.
- verification_method: Test
- complexity: 1
- dependencies: None
- tags: UC-21;full-supply-chain
- module_id: M07
- implementation_status: Implemented
- linked_use_cases: UC-21
- designed_test_cases: TC-020
- _mod: M07

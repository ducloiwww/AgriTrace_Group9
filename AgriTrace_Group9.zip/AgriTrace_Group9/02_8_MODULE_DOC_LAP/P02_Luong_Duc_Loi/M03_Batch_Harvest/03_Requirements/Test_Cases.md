# M03 — Test Cases

## TC-003 — Create valid unique product batch
- related_requirements: FR-003
- type: Functional
- priority: Must
- preconditions: Cycles C-001 and C-002 exist.
- steps: 1 create_batch B-001 on C-001. 2 create_batch B-002 on C-002. 3 create_batch B-001 again. 4 create_batch on unknown cycle C-404.
- expected_result: Two unique batches retrievable; duplicate -> ConflictError; unknown cycle -> NotFoundError.
- status: PASS
- actual_result: B-001 and B-002 created and retrievable; duplicate -> ConflictError; unknown cycle -> NotFoundError.
- executed_by: Automated script run_detailed_tests.py (sandbox, local SQLite)
- executed_date: 2026-10-22
- module_id: M03
- test_data: B-001, B-002, C-404
- implementation_function: create_batch
- evidence_scope: Local SQLite scenario result
- _mod: M03

## TC-004 — Harvest record persists against correct batch
- related_requirements: FR-004
- type: Functional
- priority: Must
- preconditions: Batch B-001 on cycle planted 2026-01-01; batch B-2 on cycle planted 2026-05-01.
- steps: 1 record_harvest(B-001, 2026-04-02, 1000). 2 Repeat harvest on B-001. 3 Harvest B-2 on 2026-04-30 (before planting). 4 Harvest B-2 with quantity 0.
- expected_result: Harvest stored on B-001; repeat -> ConflictError; early date -> ValidationError; zero -> ValidationError.
- status: PASS
- actual_result: Harvest 1000 kg stored on B-001; second harvest -> ConflictError; date before planting -> ValidationError; zero quantity -> ValidationError.
- executed_by: Automated script run_detailed_tests.py (sandbox, local SQLite)
- executed_date: 2026-10-22
- module_id: M03
- test_data: 1000 kg; dates 2026-04-02 / 2026-04-30
- implementation_function: record_harvest
- evidence_scope: Local SQLite scenario result
- _mod: M03

## TC-015 — Grade harvest with conserved quantity
- related_requirements: FR-015
- type: Functional
- priority: Must
- preconditions: B-001 harvested 1000 kg, ungraded.
- steps: 1 grade 600/250/100/50. 2 Try 600/250/100/150. 3 Try negative grade. 4 After stock receipt try regrading.
- expected_result: Exact total accepted; 1100 -> ValidationError; negative -> ValidationError; regrade after receipt -> ConflictError.
- status: PASS
- actual_result: 600+250+100+50=1000 accepted; total 1100 -> ValidationError; negative grade -> ValidationError; regrading after stock receipt -> ConflictError.
- executed_by: Automated script run_detailed_tests.py (sandbox, local SQLite)
- executed_date: 2026-10-22
- module_id: M03
- test_data: A600 B250 C100 reject50; total 1100
- implementation_function: grade_harvest
- evidence_scope: Local SQLite scenario result
- _mod: M03

# M03 — Functional Requirements

## FR-003 — Create agricultural product batch
- description: When an authorized Farm Manager submits valid crop, origin, and cycle data, the system shall create a product batch with a unique Batch ID.
- type: Functional
- priority: Must
- status: Approved
- source: SH-01
- rationale: Source: Lab 7 updated requirement baseline; Labs 1-4 core workflow. See UC-03.
- acceptance_criteria: A unique Batch ID is issued and the batch is retrievable.
- verification_method: Test
- complexity: 1
- dependencies: None
- tags: UC-03;full-supply-chain
- module_id: M03
- implementation_status: Implemented
- linked_use_cases: UC-03
- designed_test_cases: TC-003
- _mod: M03

## FR-004 — Record harvest information
- description: The system shall allow an authorized Farm Manager to record harvest date, quantity, and crop information for a batch.
- type: Functional
- priority: Must
- status: Approved
- source: SH-01
- rationale: Source: Lab 7 updated requirement baseline; Labs 1-4 core workflow. See UC-04.
- acceptance_criteria: Harvest data is linked to the correct Batch ID.
- verification_method: Test
- complexity: 1
- dependencies: None
- tags: UC-04;full-supply-chain
- module_id: M03
- implementation_status: Implemented
- linked_use_cases: UC-04
- designed_test_cases: TC-004
- _mod: M03

## FR-015 — Sort and grade harvested products
- description: The system shall allow authorized processing staff to split a harvested quantity into grade categories and record grade, quantity, reason, and destination.
- type: Functional
- priority: Must
- status: Approved
- source: SH-02
- rationale: Source: Lab 7 updated requirement baseline; post-Lab-4 expansion. See UC-16.
- acceptance_criteria: Total graded quantity never exceeds available harvested quantity and grade records are traceable.
- verification_method: Test
- complexity: 1
- dependencies: None
- tags: UC-16;full-supply-chain
- module_id: M03
- implementation_status: Implemented
- linked_use_cases: UC-16
- designed_test_cases: TC-015
- _mod: M03

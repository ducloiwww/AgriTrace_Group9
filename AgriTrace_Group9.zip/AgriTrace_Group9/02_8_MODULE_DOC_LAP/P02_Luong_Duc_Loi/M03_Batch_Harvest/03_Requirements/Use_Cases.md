# M03 — Use Cases

## UC-03 — Create Product Batch
- primary_actor: Farm Manager
- goal: Create a uniquely identifiable agricultural product batch
- preconditions: Farm profile and applicable cultivation cycle exist
- main_flow: Farmer selects crop and source farm/plot; Enters batch creation details and intended harvest context; System validates references; System generates unique Batch ID; System stores batch and audit event
- alternative_flows: Duplicate or invalid crop/plot reference -> reject; Incomplete form -> request correction
- postconditions: Batch exists and is linked to its cultivation cycle.
- trigger: A crop is ready to be tracked as a batch.
- frequency: Not measured (coursework prototype)
- related_requirements: FR-003
- module_id: M03
- test_case_ids: TC-003
- web_implementation: create_batch
- _mod: M03

## UC-04 — Record Harvest Information
- primary_actor: Farm Manager
- goal: Record harvest quantities against the correct batch
- preconditions: An identifiable batch exists and is owned by the farm
- main_flow: 1 Select batch. 2 Enter harvest date and quantity in kg. 3 System validates quantity > 0 and date not before cycle planting date. 4 System stores harvest and sets status 'Harvested'. 5 Audit harvest.recorded.
- alternative_flows: 3a Quantity <= 0 -> ValidationError. 3b Date before planting -> ValidationError. 3c Batch already harvested -> ConflictError (sub-batches need CR-003). 3d Batch recalled -> ConflictError.
- postconditions: Harvest quantity and date stored on the batch.
- trigger: Farmer records harvest
- frequency: Not measured (coursework prototype)
- related_requirements: FR-004
- module_id: M03
- test_case_ids: TC-004
- web_implementation: record_harvest
- _mod: M03

## UC-16 — Sort and Grade Harvest
- primary_actor: Processing & Packing Manager
- goal: Classify harvested produce while conserving total quantity
- preconditions: A harvested batch with available ungraded quantity exists
- main_flow: Processor selects harvested batch; Enters grade A/B/C quantities and criteria; System checks each quantity >=0; System checks total graded does not exceed harvest quantity; Stores grade allocations with Batch ID
- alternative_flows: Grade sum exceeds harvest -> reject; Negative grade -> reject; Unknown batch -> reject
- postconditions: Graded quantities are tracked with conserved harvest total
- trigger: Processor submits sorting results
- frequency: Not measured (coursework prototype)
- related_requirements: FR-015
- module_id: M03
- test_case_ids: TC-015
- web_implementation: grade_harvest
- _mod: M03

from modules.core import AgriTraceBase
from modules.accounts import AccountServiceMixin
from modules.batches import BatchServiceMixin

class AgriTraceService(BatchServiceMixin, AccountServiceMixin, AgriTraceBase):
    """Local composition: only the business methods required by M03."""
    pass

def create_service(db_path,qr_dir):
    return AgriTraceService(db_path,qr_dir)

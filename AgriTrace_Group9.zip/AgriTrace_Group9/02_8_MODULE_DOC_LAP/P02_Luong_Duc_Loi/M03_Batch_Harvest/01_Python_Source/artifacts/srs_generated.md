# M03 Standalone Requirements Index

## functional_requirements

### FR-003 — Create agricultural product batch

- description: When an authorized Farm Manager submits valid crop, origin, and cycle data, the system shall create a product batch with a unique Batch ID.
- type: Functional
- priority: Must
- status: Approved
- source: SH-01
- rationale: Source: Lab 7 updated requirement baseline; Labs 1-4 core workflow. See UC-03.
- acceptance_criteria: A unique Batch ID is issued and the batch is retrievable.
- verification_method: Test
- complexity: 1
- dependencies: None
- tags: UC-03;full-supply-chain
- module_id: M03
- implementation_status: Implemented
- linked_use_cases: UC-03
- designed_test_cases: TC-003
- _mod: M03

### FR-004 — Record harvest information

- description: The system shall allow an authorized Farm Manager to record harvest date, quantity, and crop information for a batch.
- type: Functional
- priority: Must
- status: Approved
- source: SH-01
- rationale: Source: Lab 7 updated requirement baseline; Labs 1-4 core workflow. See UC-04.
- acceptance_criteria: Harvest data is linked to the correct Batch ID.
- verification_method: Test
- complexity: 1
- dependencies: None
- tags: UC-04;full-supply-chain
- module_id: M03
- implementation_status: Implemented
- linked_use_cases: UC-04
- designed_test_cases: TC-004
- _mod: M03

### FR-015 — Sort and grade harvested products

- description: The system shall allow authorized processing staff to split a harvested quantity into grade categories and record grade, quantity, reason, and destination.
- type: Functional
- priority: Must
- status: Approved
- source: SH-02
- rationale: Source: Lab 7 updated requirement baseline; post-Lab-4 expansion. See UC-16.
- acceptance_criteria: Total graded quantity never exceeds available harvested quantity and grade records are traceable.
- verification_method: Test
- complexity: 1
- dependencies: None
- tags: UC-16;full-supply-chain
- module_id: M03
- implementation_status: Implemented
- linked_use_cases: UC-16
- designed_test_cases: TC-015
- _mod: M03

## use_cases

### UC-03 — Create Product Batch

- primary_actor: Farm Manager
- goal: Create a uniquely identifiable agricultural product batch
- preconditions: Farm profile and applicable cultivation cycle exist
- main_flow: Farmer selects crop and source farm/plot; Enters batch creation details and intended harvest context; System validates references; System generates unique Batch ID; System stores batch and audit event
- alternative_flows: Duplicate or invalid crop/plot reference -> reject; Incomplete form -> request correction
- postconditions: Batch exists and is linked to its cultivation cycle.
- trigger: A crop is ready to be tracked as a batch.
- frequency: Not measured (coursework prototype)
- related_requirements: FR-003
- module_id: M03
- test_case_ids: TC-003
- web_implementation: create_batch
- _mod: M03

### UC-04 — Record Harvest Information

- primary_actor: Farm Manager
- goal: Record harvest quantities against the correct batch
- preconditions: An identifiable batch exists and is owned by the farm
- main_flow: 1 Select batch. 2 Enter harvest date and quantity in kg. 3 System validates quantity > 0 and date not before cycle planting date. 4 System stores harvest and sets status 'Harvested'. 5 Audit harvest.recorded.
- alternative_flows: 3a Quantity <= 0 -> ValidationError. 3b Date before planting -> ValidationError. 3c Batch already harvested -> ConflictError (sub-batches need CR-003). 3d Batch recalled -> ConflictError.
- postconditions: Harvest quantity and date stored on the batch.
- trigger: Farmer records harvest
- frequency: Not measured (coursework prototype)
- related_requirements: FR-004
- module_id: M03
- test_case_ids: TC-004
- web_implementation: record_harvest
- _mod: M03

### UC-16 — Sort and Grade Harvest

- primary_actor: Processing & Packing Manager
- goal: Classify harvested produce while conserving total quantity
- preconditions: A harvested batch with available ungraded quantity exists
- main_flow: Processor selects harvested batch; Enters grade A/B/C quantities and criteria; System checks each quantity >=0; System checks total graded does not exceed harvest quantity; Stores grade allocations with Batch ID
- alternative_flows: Grade sum exceeds harvest -> reject; Negative grade -> reject; Unknown batch -> reject
- postconditions: Graded quantities are tracked with conserved harvest total
- trigger: Processor submits sorting results
- frequency: Not measured (coursework prototype)
- related_requirements: FR-015
- module_id: M03
- test_case_ids: TC-015
- web_implementation: grade_harvest
- _mod: M03

## test_cases

### TC-003 — Create valid unique product batch

- related_requirements: FR-003
- type: Functional
- priority: Must
- preconditions: Cycles C-001 and C-002 exist.
- steps: 1 create_batch B-001 on C-001. 2 create_batch B-002 on C-002. 3 create_batch B-001 again. 4 create_batch on unknown cycle C-404.
- expected_result: Two unique batches retrievable; duplicate -> ConflictError; unknown cycle -> NotFoundError.
- status: PASS
- actual_result: B-001 and B-002 created and retrievable; duplicate -> ConflictError; unknown cycle -> NotFoundError.
- executed_by: Automated script run_detailed_tests.py (sandbox, local SQLite)
- executed_date: 2026-10-22
- module_id: M03
- test_data: B-001, B-002, C-404
- implementation_function: create_batch
- evidence_scope: Local SQLite scenario result
- _mod: M03

### TC-004 — Harvest record persists against correct batch

- related_requirements: FR-004
- type: Functional
- priority: Must
- preconditions: Batch B-001 on cycle planted 2026-01-01; batch B-2 on cycle planted 2026-05-01.
- steps: 1 record_harvest(B-001, 2026-04-02, 1000). 2 Repeat harvest on B-001. 3 Harvest B-2 on 2026-04-30 (before planting). 4 Harvest B-2 with quantity 0.
- expected_result: Harvest stored on B-001; repeat -> ConflictError; early date -> ValidationError; zero -> ValidationError.
- status: PASS
- actual_result: Harvest 1000 kg stored on B-001; second harvest -> ConflictError; date before planting -> ValidationError; zero quantity -> ValidationError.
- executed_by: Automated script run_detailed_tests.py (sandbox, local SQLite)
- executed_date: 2026-10-22
- module_id: M03
- test_data: 1000 kg; dates 2026-04-02 / 2026-04-30
- implementation_function: record_harvest
- evidence_scope: Local SQLite scenario result
- _mod: M03

### TC-015 — Grade harvest with conserved quantity

- related_requirements: FR-015
- type: Functional
- priority: Must
- preconditions: B-001 harvested 1000 kg, ungraded.
- steps: 1 grade 600/250/100/50. 2 Try 600/250/100/150. 3 Try negative grade. 4 After stock receipt try regrading.
- expected_result: Exact total accepted; 1100 -> ValidationError; negative -> ValidationError; regrade after receipt -> ConflictError.
- status: PASS
- actual_result: 600+250+100+50=1000 accepted; total 1100 -> ValidationError; negative grade -> ValidationError; regrading after stock receipt -> ConflictError.
- executed_by: Automated script run_detailed_tests.py (sandbox, local SQLite)
- executed_date: 2026-10-22
- module_id: M03
- test_data: A600 B250 C100 reject50; total 1100
- implementation_function: grade_harvest
- evidence_scope: Local SQLite scenario result
- _mod: M03


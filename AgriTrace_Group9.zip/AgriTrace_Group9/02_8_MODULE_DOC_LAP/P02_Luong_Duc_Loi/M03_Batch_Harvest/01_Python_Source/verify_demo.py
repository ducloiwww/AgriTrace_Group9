"""Executable standalone smoke scenarios. Uses a temporary SQLite database."""
import tempfile,json,traceback
from pathlib import Path
from service import create_service
from bootstrap import seed_demo

def verify():
    with tempfile.TemporaryDirectory() as td:
        service=create_service(Path(td)/'smoke.sqlite3',Path(td)/'qr')
        seed_demo(service,'M03')
        s=service
        s.create_batch('farm','B-SMOKE','C-DEMO')
        s.record_harvest('farm','B-SMOKE','2026-10-20',100)
        s.revise_harvest('farm','B-SMOKE','2026-10-20',110,'Scale correction')
        s.grade_harvest('farm','B-SMOKE',70,25,10,5)
        from modules.core import ConflictError
        try:s.revise_harvest('farm','B-SMOKE','2026-10-20',115,'Too late')
        except ConflictError:pass
        else:raise AssertionError('Edit after grading must be rejected')
    return {'module':'M03','status':'PASS','scenario':'Thu hoạch và phân hạng','positive_and_negative_checked':True}

if __name__=='__main__':
    try:
        result=verify()
    except Exception as e:
        result={'module':'M03','status':'FAIL','error':str(e)}
        traceback.print_exc()
    print(json.dumps(result,ensure_ascii=False,indent=2))
    if result['status']!='PASS':raise SystemExit(1)

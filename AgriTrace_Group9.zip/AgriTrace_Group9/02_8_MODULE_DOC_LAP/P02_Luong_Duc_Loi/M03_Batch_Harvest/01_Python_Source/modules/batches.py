"""AgriTrace modular SQLite business services.

Each mixin contains one cohesive responsibility; AgriTraceService composes them.
"""
from __future__ import annotations
from .core import (
    AgriTraceError, AuthorizationError, NotFoundError, ValidationError, ConflictError,
    ROLES, ROLE_ACTIONS, now_iso, _valid_date, _number, _valid_id, _required,
    hash_password, verify_password, sqlite3, secrets, json, datetime, date,
    timezone, math, re, hashlib, Path, Any
)

class BatchServiceMixin:
    def create_batch(self, actor: str, batch_id: str, cycle_id: str) -> None:
        self._authorize(actor, "batch.create")
        batch_id = _valid_id(batch_id, "Mã lô")
        cycle_id = _valid_id(cycle_id, "Mã chu kỳ")
        _required(Mã_lô=batch_id, Mã_chu_kỳ=cycle_id)
        with self._db() as conn:
            cycle = conn.execute("SELECT * FROM cycles WHERE cycle_id=?", (cycle_id,)).fetchone()
            if not cycle:
                raise NotFoundError("Không tìm thấy chu kỳ trồng trọt.")
            if cycle["status"] != "Active":
                raise ConflictError("Không thể tạo lô từ chu kỳ đã đóng.")
            if conn.execute("SELECT 1 FROM batches WHERE batch_id=?", (batch_id,)).fetchone():
                raise ConflictError("Mã lô đã tồn tại.")
            conn.execute("INSERT INTO batches(batch_id,cycle_id,created_by,created_at) VALUES(?,?,?,?)", (batch_id.strip(), cycle_id, actor, now_iso()))
            self._audit(conn, actor, "batch.created", "batch", batch_id, cycle_id)

    def record_harvest(self, actor: str, batch_id: str, harvest_date: str, quantity: float) -> None:
        self._authorize(actor, "harvest.write")
        _valid_date(harvest_date, "Ngày thu hoạch")
        quantity = _number(quantity, "Sản lượng thu hoạch")
        if quantity <= 0:
            raise ValidationError("Sản lượng thu hoạch phải lớn hơn 0.")
        with self._db() as conn:
            row = conn.execute("SELECT b.*, c.planting_date FROM batches b JOIN cycles c USING(cycle_id) WHERE batch_id=?", (batch_id,)).fetchone()
            if not row:
                raise NotFoundError("Không tìm thấy lô nông sản.")
            if row["recalled"]:
                raise ConflictError("Không thể ghi nhận thu hoạch cho lô đã thu hồi.")
            if row["harvest_qty"] is not None:
                raise ConflictError("Lô đã có bản ghi thu hoạch; hãy tạo lô con nếu cần tách đợt thu hoạch.")
            if date.fromisoformat(harvest_date) < date.fromisoformat(row["planting_date"]):
                raise ValidationError("Ngày thu hoạch không được trước ngày trồng.")
            conn.execute("UPDATE batches SET harvest_date=?,harvest_qty=?,status='Harvested' WHERE batch_id=?", (harvest_date, float(quantity), batch_id))
            self._audit(conn, actor, "harvest.recorded", "batch", batch_id, f"quantity={quantity}")

    def grade_harvest(self, actor: str, batch_id: str, grade_a: float, grade_b: float, grade_c: float, rejected_qty: float, location: str = "Farm sorting area") -> None:
        self._authorize(actor, "grading.write")
        _required(Địa_điểm_phân_loại=location)
        grade_a, grade_b, grade_c, rejected_qty = (_number(q, "Sản lượng phân hạng") for q in (grade_a, grade_b, grade_c, rejected_qty))
        quantities = (grade_a, grade_b, grade_c, rejected_qty)
        if any(q < 0 for q in quantities):
            raise ValidationError("Sản lượng từng hạng không được âm.")
        with self._db() as conn:
            row = conn.execute("SELECT * FROM batches WHERE batch_id=?", (batch_id,)).fetchone()
            if not row:
                raise NotFoundError("Không tìm thấy lô nông sản.")
            if row["harvest_qty"] is None:
                raise ConflictError("Phải ghi nhận thu hoạch trước khi phân loại.")
            if row["recalled"] or row["review_hold"]:
                raise ConflictError("Lô bị thu hồi/giữ để xem xét, không thể phân loại tiếp.")
            if any(float(x["received_total"]) > 0 for x in conn.execute("SELECT received_total FROM inventory WHERE batch_id=?", (batch_id,))):
                raise ConflictError("Không thể sửa phân hạng sau khi đã nhập kho.")
            total = sum(quantities)
            if round(total, 6) != round(float(row["harvest_qty"]), 6):
                raise ValidationError("Hạng A + B + C + hàng loại bỏ phải bằng tổng sản lượng thu hoạch.")
            conn.execute("UPDATE batches SET grade_a=?,grade_b=?,grade_c=?,rejected_qty=?,graded_at=?,grading_location=?,status='Sorted' WHERE batch_id=?",
                         (float(grade_a), float(grade_b), float(grade_c), float(rejected_qty), now_iso(), location.strip(), batch_id))
            self._audit(conn, actor, "harvest.graded", "batch", batch_id, json.dumps({"A": grade_a, "B": grade_b, "C": grade_c, "rejected": rejected_qty, "location": location.strip()}))

    def revise_harvest(self, actor: str, batch_id: str, harvest_date: str, quantity: float, reason: str) -> None:
        """Correct a harvest entry before grading; never rewrite downstream history."""
        self._authorize(actor, 'harvest.write')
        _required(Lý_do_sửa=reason)
        d=_valid_date(harvest_date,'Ngày thu hoạch')
        q=_number(quantity,'Sản lượng');
        if q<=0:raise ValidationError('Sản lượng phải lớn hơn 0.')
        with self._db() as conn:
            row=conn.execute('SELECT b.*,c.planting_date FROM batches b JOIN cycles c USING(cycle_id) WHERE batch_id=?',(batch_id,)).fetchone()
            if not row:raise NotFoundError('Không tìm thấy lô.')
            if row['harvest_qty'] is None:raise ConflictError('Phải ghi nhận thu hoạch trước khi sửa.')
            if row['graded_at'] or row['status']!='Harvested' or row['review_hold'] or row['recalled']:
                raise ConflictError('Chỉ sửa được sản lượng trước phân loại, kiểm định hoặc thu hồi.')
            if d < date.fromisoformat(row['planting_date']):raise ValidationError('Ngày thu hoạch trước ngày trồng.')
            conn.execute('UPDATE batches SET harvest_date=?,harvest_qty=? WHERE batch_id=?',(harvest_date,float(q),batch_id))
            self._audit(conn,actor,'harvest.revised','batch',batch_id,f'reason={reason.strip()};old={row["harvest_qty"]};new={q}')

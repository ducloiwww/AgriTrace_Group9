import sys, unittest, tempfile
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from service import create_service
from bootstrap import seed_demo
from modules.core import AgriTraceError,AuthorizationError

class ModuleTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory()
        self.s=create_service(Path(self.temp.name)/'test.sqlite3',Path(self.temp.name)/'qr')
        seed_demo(self.s,'M03')
    def tearDown(self):self.temp.cleanup()
    def test_create_batch(self):
        self.s.create_batch('farm','B-NEW','C-DEMO');self.assertEqual(self.s._one('batches','batch_id','B-NEW')['status'],'Created')
    def test_harvest_then_grade(self):
        self.s.create_batch('farm','B-NEW','C-DEMO');self.s.record_harvest('farm','B-NEW','2026-10-20',100)
        self.s.grade_harvest('farm','B-NEW',60,25,10,5)
        self.assertEqual(self.s._one('batches','batch_id','B-NEW')['grade_a'],60)
    def test_over_grading_rejected(self):
        self.s.create_batch('farm','B-NEW','C-DEMO');self.s.record_harvest('farm','B-NEW','2026-10-20',100)
        with self.assertRaises(AgriTraceError):self.s.grade_harvest('farm','B-NEW',80,25,10,5)
    def test_grade_without_harvest(self):
        self.s.create_batch('farm','B-NEW','C-DEMO')
        with self.assertRaises(AgriTraceError):self.s.grade_harvest('farm','B-NEW',60,25,10,5)
    def test_duplicate_batch(self):
        self.s.create_batch('farm','B-NEW','C-DEMO')
        with self.assertRaises(AgriTraceError):self.s.create_batch('farm','B-NEW','C-DEMO')

if __name__=='__main__':unittest.main()

import unittest,tempfile
from pathlib import Path
from service import create_service
from bootstrap import seed_demo
from modules.core import ValidationError,ConflictError,NotFoundError,AuthorizationError

class ReviewTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory()
        self.s=create_service(Path(self.temp.name)/'testing.sqlite3',Path(self.temp.name)/'qr')
        seed_demo(self.s,'M03')
    def tearDown(self):self.temp.cleanup()
    def new(self):return self.s.create_order('retailer','Retail-01','B-DEMO','A',20,'2026-11-01')
    def test_revise_harvest_before_grading(self):
        self.s.create_batch('farm','B-EDIT','C-DEMO')
        self.s.record_harvest('farm','B-EDIT','2026-10-20',100)
        self.s.revise_harvest('farm','B-EDIT','2026-10-20',110,'Verified scale')
        self.assertEqual(self.s._one('batches','batch_id','B-EDIT')['harvest_qty'],110)
        self.s.grade_harvest('farm','B-EDIT',70,25,10,5)
        with self.assertRaises(ConflictError): self.s.revise_harvest('farm','B-EDIT','2026-10-20',120,'Late')
    def test_revise_negative_harvest_preserves_data(self):
        self.s.create_batch('farm','B-EDIT','C-DEMO');self.s.record_harvest('farm','B-EDIT','2026-10-20',100)
        with self.assertRaises(ValidationError):self.s.revise_harvest('farm','B-EDIT','2026-10-20',-5,'Error')
        self.assertEqual(self.s._one('batches','batch_id','B-EDIT')['harvest_qty'],100)


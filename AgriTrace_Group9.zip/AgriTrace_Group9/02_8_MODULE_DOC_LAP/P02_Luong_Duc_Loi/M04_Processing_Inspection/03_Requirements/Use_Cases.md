# M04 — Use Cases

## UC-05 — Record Processing and Packaging
- primary_actor: Processing & Packing Manager
- goal: Capture processing and packaging history per batch
- preconditions: A received harvested batch exists; processing user authorized
- main_flow: 1 Select batch. 2 Enter facility, processing date, packaging date and package details. 3 System checks harvest and grading exist and packaging date is not before processing date. 4 System stores processing data and sets status 'Processed'. 5 Audit processing.recorded.
- alternative_flows: 3a Not graded -> ConflictError. 3b Packaging before processing -> ValidationError. 3c Batch recalled/held -> ConflictError. 3d Already processed or inspected -> ConflictError.
- postconditions: Processing and packaging events are stored against the batch
- trigger: Batch arrives at the processing facility.
- frequency: Not measured (coursework prototype)
- related_requirements: FR-005
- module_id: M04
- test_case_ids: TC-005
- web_implementation: record_processing
- _mod: M04

## UC-06 — Record Quality Inspection Result
- primary_actor: Food Safety / Regulatory Inspector
- goal: Register quality inspection results and responsible reviewer
- preconditions: Batch is available for inspection; inspector or delegated processor authenticated
- main_flow: 1 Select batch. 2 Choose result Passed, Failed or Pending and enter notes and location. 3 System checks pre-conditions for Passed. 4 System stores result, actor and time. 5 Failed -> status 'Quality Hold' and alerts sent to operational roles.
- alternative_flows: 3a Passed before harvest/grading/processing -> ConflictError. 3b Passed on recalled batch -> ConflictError. 3c Passed while safety hold active -> ConflictError. 3d Invalid result -> ValidationError.
- postconditions: Inspection result and shipment eligibility are traceable
- trigger: Inspector submits inspection
- frequency: Not measured (coursework prototype)
- related_requirements: FR-006
- module_id: M04
- test_case_ids: TC-006
- web_implementation: inspect_quality
- _mod: M04

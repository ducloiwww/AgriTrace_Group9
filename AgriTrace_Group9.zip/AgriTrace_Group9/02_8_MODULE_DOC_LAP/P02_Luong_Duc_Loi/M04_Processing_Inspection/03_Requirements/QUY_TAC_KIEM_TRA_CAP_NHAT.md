# M04 — Quy tắc kiểm tra bổ sung

- **Hành vi:** Sửa thông tin đóng gói chỉ trước kiểm định; đóng gói không trước chế biến.
- **Luồng demo:** chế biến → sửa quy cách → đăng nhập inspector để kiểm định → thử sửa sau kiểm định
- **Mã nguồn:** `01_Python_Source/modules`, `01_Python_Source/app.py`
- **Kiểm thử đã thực thi:** `tests/test_review.py`, `verify_demo.py`; không tự đồng nhất số lượng unit test với số TC thiết kế.
- **Mốc:** 29/10/2026; nội dung mới phục vụ giao diện cập nhật, chưa thay thế các FR/UC/TC gốc trong `specification.json`.

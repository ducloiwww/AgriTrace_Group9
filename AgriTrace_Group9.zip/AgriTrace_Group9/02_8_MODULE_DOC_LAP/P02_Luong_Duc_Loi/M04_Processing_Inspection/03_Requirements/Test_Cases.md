# M04 — Test Cases

## TC-005 — Processing record links to correct batch
- related_requirements: FR-005
- type: Functional
- priority: Must
- preconditions: B-001 harvested 1000 and graded 600/250/100/50; B-2 harvested but not graded.
- steps: 1 Processing on ungraded B-2. 2 Processing on B-001 with packaging date 2026-04-03 before processing 2026-04-04. 3 Valid processing (Pack House 1, 2026-04-03, 2026-04-04, 'Crate 5 kg'). 4 Repeat processing.
- expected_result: Valid record linked to B-001; ungraded -> ConflictError; date order -> ValidationError; repeat -> ConflictError.
- status: PASS
- actual_result: Processing linked to B-001 (facility=Pack House 1); before grading -> ConflictError; packaging before processing -> ValidationError; second record -> ConflictError.
- executed_by: Automated script run_detailed_tests.py (sandbox, local SQLite)
- executed_date: 2026-10-22
- module_id: M04
- test_data: Pack House 1; Crate 5 kg
- implementation_function: record_processing
- evidence_scope: Local SQLite scenario result
- _mod: M04

## TC-006 — Quality inspection outcome and actor are recorded
- related_requirements: FR-006
- type: Functional
- priority: Must
- preconditions: B-001 processed; inspector account exists.
- steps: 1 Inspect Passed before processing (separate batch). 2 Inspect Passed after processing. 3 On another batch record Failed 'mold'. 4 Try inventory receipt of the failed batch.
- expected_result: Passed stores result and actor=inspector; early Passed -> ConflictError; Failed -> Quality Hold, alerts created, receipt blocked.
- status: PASS
- actual_result: Passed recorded with actor=inspector; Passed before processing -> ConflictError; Failed -> status 'Quality Hold', inventory receipt blocked (ConflictError), alerts created: 1.
- executed_by: Automated script run_detailed_tests.py (sandbox, local SQLite)
- executed_date: 2026-10-22
- module_id: M04
- test_data: result Passed/Failed; notes
- implementation_function: inspect_quality
- evidence_scope: Local SQLite scenario result
- _mod: M04

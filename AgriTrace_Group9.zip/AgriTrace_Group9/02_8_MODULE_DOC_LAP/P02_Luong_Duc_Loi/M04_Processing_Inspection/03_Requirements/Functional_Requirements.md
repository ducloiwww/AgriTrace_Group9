# M04 — Functional Requirements

## FR-005 — Record processing and packaging
- description: The system shall allow an authorized Processing & Packing Manager to record processing and packaging information for a received batch.
- type: Functional
- priority: Must
- status: Approved
- source: SH-02
- rationale: Source: Lab 7 updated requirement baseline; Labs 1-4 core workflow. See UC-05.
- acceptance_criteria: Processing and packaging information is linked to the correct batch.
- verification_method: Test
- complexity: 1
- dependencies: None
- tags: UC-05;full-supply-chain
- module_id: M04
- implementation_status: Implemented
- linked_use_cases: UC-05
- designed_test_cases: TC-005
- _mod: M04

## FR-006 — Record quality inspection result
- description: The system shall allow an authorized inspector or processing manager to record quality inspection result and notes for a batch.
- type: Functional
- priority: Must
- status: Approved
- source: SH-06
- rationale: Source: Lab 7 updated requirement baseline; Labs 1-4 core workflow. See UC-06.
- acceptance_criteria: Inspection status and responsible actor are stored.
- verification_method: Test
- complexity: 1
- dependencies: None
- tags: UC-06;full-supply-chain
- module_id: M04
- implementation_status: Implemented
- linked_use_cases: UC-06
- designed_test_cases: TC-006
- _mod: M04

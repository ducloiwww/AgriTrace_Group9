# M04: Processing & Inspection

**Owner:** Lương Đức Lợi

01_Python_Source: independent app and tests.
02_Test_Logs: actual execution results.
03_Requirements: SRS extracts relevant to M04.
04_Diagrams: four diagrams (PNG and editable DOT).

Run on Windows: open `01_Python_Source` and double-click `run_windows.bat`.

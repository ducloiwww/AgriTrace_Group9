"""AgriTrace modular SQLite processing & quality services.

Each mixin contains one cohesive responsibility; AgriTraceService composes them.
"""
from __future__ import annotations
from .core import (
    AgriTraceError, AuthorizationError, NotFoundError, ValidationError, ConflictError,
    ROLES, ROLE_ACTIONS, now_iso, _valid_date, _number, _valid_id, _required,
    hash_password, verify_password, sqlite3, secrets, json, datetime, date,
    timezone, math, re, hashlib, Path, Any
)

class ProcessingServiceMixin:
    def record_processing(self, actor: str, batch_id: str, facility: str, processing_date: str, packaging_date: str, package_details: str) -> None:
        self._authorize(actor, "processing.write")
        _required(Cơ_sở=facility, Ngày_chế_biến=processing_date, Ngày_đóng_gói=packaging_date, Quy_cách=package_details)
        pdate = _valid_date(processing_date, "Ngày chế biến")
        gdate = _valid_date(packaging_date, "Ngày đóng gói")
        if gdate < pdate:
            raise ValidationError("Ngày đóng gói không được trước ngày chế biến.")
        with self._db() as conn:
            row = conn.execute("SELECT * FROM batches WHERE batch_id=?", (batch_id,)).fetchone()
            if not row:
                raise NotFoundError("Không tìm thấy lô nông sản.")
            if row["harvest_qty"] is None or row["grade_a"] + row["grade_b"] + row["grade_c"] <= 0:
                raise ConflictError("Cần thu hoạch và phân loại trước khi chế biến/đóng gói.")
            if row["recalled"] or row["review_hold"]:
                raise ConflictError("Lô bị thu hồi/giữ để xem xét, không thể chế biến tiếp.")
            if row["inspection_status"] != "Pending" or row["process_facility"] or conn.execute("SELECT 1 FROM inventory WHERE batch_id=? AND received_total>0", (batch_id,)).fetchone():
                raise ConflictError("Mỗi lô chỉ ghi một quy trình chế biến/đóng gói; không thể sửa sau khi đã ghi hoặc đã kiểm định/nhập kho.")
            conn.execute("UPDATE batches SET process_facility=?,processing_date=?,packaging_date=?,package_details=?,status='Processed' WHERE batch_id=?",
                         (facility.strip(), processing_date, packaging_date, package_details.strip(), batch_id))
            self._audit(conn, actor, "processing.recorded", "batch", batch_id, facility)

    def inspect_quality(self, actor: str, batch_id: str, result: str, notes: str = "", location: str = "Quality inspection station") -> None:
        self._authorize(actor, "quality.write")
        if result != "Pending":
            _required(Địa_điểm_kiểm_định=location)
        if result not in {"Passed", "Failed", "Pending"}:
            raise ValidationError("Kết quả kiểm định phải là Passed, Failed hoặc Pending.")
        with self._db() as conn:
            row = conn.execute("SELECT * FROM batches WHERE batch_id=?", (batch_id,)).fetchone()
            if not row:
                raise NotFoundError("Không tìm thấy lô nông sản.")
            if result == "Passed" and row["recalled"]:
                raise ConflictError("Không thể phê duyệt lô đã bị thu hồi.")
            if result == "Passed" and (row["harvest_qty"] is None or row["grade_a"] + row["grade_b"] + row["grade_c"] <= 0 or not row["process_facility"]):
                raise ConflictError("Chỉ kiểm định đạt sau khi đã thu hoạch, phân loại, chế biến và đóng gói.")
            if result == "Passed" and row["review_hold"]:
                raise ConflictError("Lô đang bị giữ để xem xét an toàn; cần giải phóng giữ bởi thanh tra trước khi kiểm định lại.")
            if result == "Failed":
                status = "Recalled" if row["recalled"] else "Quality Hold"
                hold_value = 1
            else:
                status = "Recalled" if row["recalled"] else ("Approved" if result == "Passed" else row["status"])
                hold_value = int(row["review_hold"])
            conn.execute("UPDATE batches SET inspection_status=?,inspection_notes=?,inspection_location=?,inspection_actor=?,inspection_at=?,status=?,review_hold=? WHERE batch_id=?",
                         (result, notes.strip(), location.strip(), actor, now_iso(), status, hold_value, batch_id))
            self._audit(conn, actor, f"quality.{result.lower()}", "batch", batch_id, f"location={location.strip()}; notes={notes.strip()}")
            if result == "Failed":
                self._create_alerts(conn, batch_id, "Kết quả kiểm định KHÔNG ĐẠT. Lô bị khóa khỏi nhập kho/giao hàng.")

    def revise_processing(self, actor: str, batch_id: str, facility: str, processing_date: str, packaging_date: str, package_details: str, reason: str) -> None:
        """Correct packaging data only before any quality decision."""
        self._authorize(actor,'processing.write')
        _required(Cơ_sở=facility,Ngày_chế_biến=processing_date,Ngày_đóng_gói=packaging_date,Quy_cách=package_details,Lý_do_sửa=reason)
        d1=_valid_date(processing_date,'Ngày chế biến');d2=_valid_date(packaging_date,'Ngày đóng gói')
        if d2<d1:raise ValidationError('Ngày đóng gói không được trước ngày chế biến.')
        with self._db() as conn:
            b=conn.execute('SELECT * FROM batches WHERE batch_id=?',(batch_id,)).fetchone()
            if not b:raise NotFoundError('Không tìm thấy lô.')
            if not b['process_facility'] or b['inspection_at'] or b['review_hold'] or b['recalled']:
                raise ConflictError('Chỉ được sửa hồ sơ chế biến trước khi kiểm định.')
            conn.execute('UPDATE batches SET process_facility=?,processing_date=?,packaging_date=?,package_details=? WHERE batch_id=?',
                         (facility.strip(),processing_date,packaging_date,package_details.strip(),batch_id))
            self._audit(conn,actor,'processing.revised','batch',batch_id,f'reason={reason.strip()}')

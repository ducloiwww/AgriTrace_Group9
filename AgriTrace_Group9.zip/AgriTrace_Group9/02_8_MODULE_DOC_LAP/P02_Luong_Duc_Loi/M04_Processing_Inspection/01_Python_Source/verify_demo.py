"""Executable standalone smoke scenarios. Uses a temporary SQLite database."""
import tempfile,json,traceback
from pathlib import Path
from service import create_service
from bootstrap import seed_demo

def verify():
    with tempfile.TemporaryDirectory() as td:
        service=create_service(Path(td)/'smoke.sqlite3',Path(td)/'qr')
        seed_demo(service,'M04')
        s=service
        s.record_processing('processor','B-DEMO','Demo facility','2026-10-21','2026-10-22','5 kg')
        s.revise_processing('processor','B-DEMO','Demo facility','2026-10-21','2026-10-22','10 kg','Correction')
        s.inspect_quality('inspector','B-DEMO','Passed','OK','Lab')
        from modules.core import ConflictError
        try:s.revise_processing('processor','B-DEMO','X','2026-10-21','2026-10-22','Box','Too late')
        except ConflictError:pass
        else:raise AssertionError('Edit after inspection must be rejected')
    return {'module':'M04','status':'PASS','scenario':'Chế biến và kiểm định','positive_and_negative_checked':True}

if __name__=='__main__':
    try:
        result=verify()
    except Exception as e:
        result={'module':'M04','status':'FAIL','error':str(e)}
        traceback.print_exc()
    print(json.dumps(result,ensure_ascii=False,indent=2))
    if result['status']!='PASS':raise SystemExit(1)

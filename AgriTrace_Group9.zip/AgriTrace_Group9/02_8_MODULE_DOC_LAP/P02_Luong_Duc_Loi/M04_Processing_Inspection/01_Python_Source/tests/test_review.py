import unittest,tempfile
from pathlib import Path
from service import create_service
from bootstrap import seed_demo
from modules.core import ValidationError,ConflictError,NotFoundError,AuthorizationError

class ReviewTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory()
        self.s=create_service(Path(self.temp.name)/'testing.sqlite3',Path(self.temp.name)/'qr')
        seed_demo(self.s,'M04')
    def tearDown(self):self.temp.cleanup()
    def new(self):return self.s.create_order('retailer','Retail-01','B-DEMO','A',20,'2026-11-01')
    def test_revise_processing_before_inspection(self):
        self.s.record_processing('processor','B-DEMO','Facility','2026-10-21','2026-10-22','5kg')
        self.s.revise_processing('processor','B-DEMO','Facility 2','2026-10-21','2026-10-22','10kg','Correction')
        self.assertEqual(self.s._one('batches','batch_id','B-DEMO')['package_details'],'10kg')
        self.s.inspect_quality('inspector','B-DEMO','Passed','OK','Lab')
        with self.assertRaises(ConflictError):self.s.revise_processing('processor','B-DEMO','X','2026-10-21','2026-10-22','X','Late')
    def test_invalid_revision_keeps_old_package(self):
        self.s.record_processing('processor','B-DEMO','Facility','2026-10-21','2026-10-22','5kg')
        with self.assertRaises(ValidationError):self.s.revise_processing('processor','B-DEMO','Facility','2026-10-22','2026-10-21','Bad','Wrong date')
        self.assertEqual(self.s._one('batches','batch_id','B-DEMO')['package_details'],'5kg')


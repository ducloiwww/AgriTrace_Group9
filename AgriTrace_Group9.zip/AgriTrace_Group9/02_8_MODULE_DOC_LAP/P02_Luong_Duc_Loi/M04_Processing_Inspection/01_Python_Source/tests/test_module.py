import sys, unittest, tempfile
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from service import create_service
from bootstrap import seed_demo
from modules.core import AgriTraceError,AuthorizationError

class ModuleTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory()
        self.s=create_service(Path(self.temp.name)/'test.sqlite3',Path(self.temp.name)/'qr')
        seed_demo(self.s,'M04')
    def tearDown(self):self.temp.cleanup()
    def process(self):self.s.record_processing('processor','B-DEMO','Packing Center','2026-10-21','2026-10-22','Thùng 5 kg')
    def test_process(self):
        self.process();self.assertEqual(self.s._one('batches','batch_id','B-DEMO')['status'],'Processed')
    def test_inspection_pass(self):
        self.process();self.s.inspect_quality('inspector','B-DEMO','Passed','Good');self.assertEqual(self.s._one('batches','batch_id','B-DEMO')['inspection_status'],'Passed')
    def test_invalid_packaging_date(self):
        with self.assertRaises(AgriTraceError):self.s.record_processing('processor','B-DEMO','Packing Center','2026-10-22','2026-10-21','Thùng 5 kg')
    def test_inspector_role(self):
        self.process()
        with self.assertRaises(AuthorizationError):self.s.inspect_quality('farm','B-DEMO','Passed','Good')
    def test_failure_holds_batch(self):
        self.process();self.s.inspect_quality('inspector','B-DEMO','Failed','Bad')
        b=self.s._one('batches','batch_id','B-DEMO');self.assertTrue(b['review_hold'])

if __name__=='__main__':unittest.main()

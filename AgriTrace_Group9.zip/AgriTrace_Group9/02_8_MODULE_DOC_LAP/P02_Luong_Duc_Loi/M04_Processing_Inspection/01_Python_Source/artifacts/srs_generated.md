# M04 Standalone Requirements Index

## functional_requirements

### FR-005 — Record processing and packaging

- description: The system shall allow an authorized Processing & Packing Manager to record processing and packaging information for a received batch.
- type: Functional
- priority: Must
- status: Approved
- source: SH-02
- rationale: Source: Lab 7 updated requirement baseline; Labs 1-4 core workflow. See UC-05.
- acceptance_criteria: Processing and packaging information is linked to the correct batch.
- verification_method: Test
- complexity: 1
- dependencies: None
- tags: UC-05;full-supply-chain
- module_id: M04
- implementation_status: Implemented
- linked_use_cases: UC-05
- designed_test_cases: TC-005
- _mod: M04

### FR-006 — Record quality inspection result

- description: The system shall allow an authorized inspector or processing manager to record quality inspection result and notes for a batch.
- type: Functional
- priority: Must
- status: Approved
- source: SH-06
- rationale: Source: Lab 7 updated requirement baseline; Labs 1-4 core workflow. See UC-06.
- acceptance_criteria: Inspection status and responsible actor are stored.
- verification_method: Test
- complexity: 1
- dependencies: None
- tags: UC-06;full-supply-chain
- module_id: M04
- implementation_status: Implemented
- linked_use_cases: UC-06
- designed_test_cases: TC-006
- _mod: M04

## use_cases

### UC-05 — Record Processing and Packaging

- primary_actor: Processing & Packing Manager
- goal: Capture processing and packaging history per batch
- preconditions: A received harvested batch exists; processing user authorized
- main_flow: 1 Select batch. 2 Enter facility, processing date, packaging date and package details. 3 System checks harvest and grading exist and packaging date is not before processing date. 4 System stores processing data and sets status 'Processed'. 5 Audit processing.recorded.
- alternative_flows: 3a Not graded -> ConflictError. 3b Packaging before processing -> ValidationError. 3c Batch recalled/held -> ConflictError. 3d Already processed or inspected -> ConflictError.
- postconditions: Processing and packaging events are stored against the batch
- trigger: Batch arrives at the processing facility.
- frequency: Not measured (coursework prototype)
- related_requirements: FR-005
- module_id: M04
- test_case_ids: TC-005
- web_implementation: record_processing
- _mod: M04

### UC-06 — Record Quality Inspection Result

- primary_actor: Food Safety / Regulatory Inspector
- goal: Register quality inspection results and responsible reviewer
- preconditions: Batch is available for inspection; inspector or delegated processor authenticated
- main_flow: 1 Select batch. 2 Choose result Passed, Failed or Pending and enter notes and location. 3 System checks pre-conditions for Passed. 4 System stores result, actor and time. 5 Failed -> status 'Quality Hold' and alerts sent to operational roles.
- alternative_flows: 3a Passed before harvest/grading/processing -> ConflictError. 3b Passed on recalled batch -> ConflictError. 3c Passed while safety hold active -> ConflictError. 3d Invalid result -> ValidationError.
- postconditions: Inspection result and shipment eligibility are traceable
- trigger: Inspector submits inspection
- frequency: Not measured (coursework prototype)
- related_requirements: FR-006
- module_id: M04
- test_case_ids: TC-006
- web_implementation: inspect_quality
- _mod: M04

## test_cases

### TC-005 — Processing record links to correct batch

- related_requirements: FR-005
- type: Functional
- priority: Must
- preconditions: B-001 harvested 1000 and graded 600/250/100/50; B-2 harvested but not graded.
- steps: 1 Processing on ungraded B-2. 2 Processing on B-001 with packaging date 2026-04-03 before processing 2026-04-04. 3 Valid processing (Pack House 1, 2026-04-03, 2026-04-04, 'Crate 5 kg'). 4 Repeat processing.
- expected_result: Valid record linked to B-001; ungraded -> ConflictError; date order -> ValidationError; repeat -> ConflictError.
- status: PASS
- actual_result: Processing linked to B-001 (facility=Pack House 1); before grading -> ConflictError; packaging before processing -> ValidationError; second record -> ConflictError.
- executed_by: Automated script run_detailed_tests.py (sandbox, local SQLite)
- executed_date: 2026-10-22
- module_id: M04
- test_data: Pack House 1; Crate 5 kg
- implementation_function: record_processing
- evidence_scope: Local SQLite scenario result
- _mod: M04

### TC-006 — Quality inspection outcome and actor are recorded

- related_requirements: FR-006
- type: Functional
- priority: Must
- preconditions: B-001 processed; inspector account exists.
- steps: 1 Inspect Passed before processing (separate batch). 2 Inspect Passed after processing. 3 On another batch record Failed 'mold'. 4 Try inventory receipt of the failed batch.
- expected_result: Passed stores result and actor=inspector; early Passed -> ConflictError; Failed -> Quality Hold, alerts created, receipt blocked.
- status: PASS
- actual_result: Passed recorded with actor=inspector; Passed before processing -> ConflictError; Failed -> status 'Quality Hold', inventory receipt blocked (ConflictError), alerts created: 1.
- executed_by: Automated script run_detailed_tests.py (sandbox, local SQLite)
- executed_date: 2026-10-22
- module_id: M04
- test_data: result Passed/Failed; notes
- implementation_function: inspect_quality
- evidence_scope: Local SQLite scenario result
- _mod: M04


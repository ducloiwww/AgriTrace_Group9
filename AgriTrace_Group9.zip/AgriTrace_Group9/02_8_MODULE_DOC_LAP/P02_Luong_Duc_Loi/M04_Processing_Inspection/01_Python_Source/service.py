from modules.core import AgriTraceBase
from modules.accounts import AccountServiceMixin
from modules.processing import ProcessingServiceMixin

class AgriTraceService(ProcessingServiceMixin, AccountServiceMixin, AgriTraceBase):
    """Local composition: only the business methods required by M04."""

    def _create_alerts(self,conn,batch_id,message):
        from modules.core import ROLE_ACTIONS,now_iso
        for role in sorted(ROLE_ACTIONS.keys()):
            conn.execute("INSERT INTO alerts(batch_id,target_role,message,created_at) VALUES(?,?,?,?)",(batch_id,role,message,now_iso()))


def create_service(db_path,qr_dir):
    return AgriTraceService(db_path,qr_dir)

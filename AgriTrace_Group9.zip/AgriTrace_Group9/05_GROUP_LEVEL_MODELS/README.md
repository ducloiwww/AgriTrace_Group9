# Group-Level System Models — AgriTrace

This folder contains six group-level models prepared from the supplied AgriTrace Group 9 source package, its module requirements, source files, local data definitions and test artefacts.

| No. | Model | Editable source |
|---|---|---|
| 01 | Actor-to-module use-case participation map | Graphviz `.dot` |
| 02 | Logical farm-to-table activity workflow | Python / Matplotlib `.py` |
| 03 | Current runtime and data-flow architecture | Graphviz `.dot` |
| 04 | Conceptual data model and module data ownership | Graphviz `.dot` |
| 05 | Batch lifecycle state machine | Graphviz `.dot` |
| 06 | Order and shipment lifecycle state machine | Graphviz `.dot` |

Each model is also supplied as a PNG image for insertion into reports and presentations. To regenerate the activity workflow from its Python source, install Matplotlib (`python -m pip install matplotlib`) and run `python 02_Logical_Activity_Workflow_Source.py` from this folder. The module-specific Use Case, Activity, DFD and State Machine diagrams remain in each module's own `04_Diagrams` folder.

## Interpretation notes

- The package contains eight standalone local applications, each with its own SQLite database. It does not implement one shared runtime database or automatic cross-application synchronization.
- Dashed connectors in the group-level workflow and architecture represent conceptual business references, manual hand-offs or demonstration-fixture inputs. They are not live integrations or physical cross-database foreign keys.
- The actor map distinguishes configured runtime roles from external stakeholders. The Agricultural Certification Body is listed as a stakeholder but is not a configured login role in the current package; the Consumer accesses public trace without an operational login.
- The conceptual data model summarizes data ownership and intended lineage; it does not assert that all depicted entities are stored in one physical schema.

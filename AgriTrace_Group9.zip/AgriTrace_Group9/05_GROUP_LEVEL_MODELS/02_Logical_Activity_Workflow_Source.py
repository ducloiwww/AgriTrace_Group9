import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, Polygon, FancyArrowPatch
from pathlib import Path

out = Path(__file__).resolve().parent / '02_Logical_Activity_Workflow.png'
fig, ax = plt.subplots(figsize=(14.5, 7.6), dpi=300)
fig.patch.set_facecolor('white'); ax.set_facecolor('white')
ax.set_xlim(0,14.5); ax.set_ylim(0,7.6); ax.axis('off')
navy='#24415E'; textc='#17324D'; pale='#EAF2F8'; green='#E2F0D9'; yellow='#FFF2CC'; red='#FCE4D6'; line='#55738F'; lane='#F8FAFC'; lane_edge='#A8B8C8'

# Three clearly separated swimlanes, arranged as a serpentine workflow.
for y0, h, label in [
    (5.65,1.55,'A. FARM, CULTIVATION, HARVEST AND PROCESSING'),
    (3.25,1.55,'B. INSPECTION, INVENTORY AND ORDER FULFILMENT'),
    (0.85,1.55,'C. SHIPMENT, DELIVERY AND PUBLIC TRACEABILITY')]:
    ax.add_patch(FancyBboxPatch((0.22,y0),14.06,h,boxstyle='round,pad=0.02,rounding_size=0.12',facecolor=lane,edgecolor=lane_edge,linewidth=1.0,linestyle='--',zorder=0))
    ax.text(0.43,y0+h-0.18,label,fontsize=10,fontweight='bold',color=navy,va='top')

def rounded(cx,cy,label,fc=pale,w=2.14,h=.72,fs=10.7):
    ax.add_patch(FancyBboxPatch((cx-w/2,cy-h/2),w,h,boxstyle='round,pad=.07,rounding_size=.10',facecolor=fc,edgecolor=navy,linewidth=1.25,zorder=3))
    ax.text(cx,cy,label,ha='center',va='center',fontsize=fs,color=textc,linespacing=1.05,zorder=4)

def diamond(cx,cy,label,w=2.05,h=.78,fs=10.2):
    ax.add_patch(Polygon([(cx,cy+h/2),(cx+w/2,cy),(cx,cy-h/2),(cx-w/2,cy)],closed=True,facecolor=yellow,edgecolor=navy,linewidth=1.25,zorder=3))
    ax.text(cx,cy,label,ha='center',va='center',fontsize=fs,color=textc,linespacing=1.0,zorder=4)

def arrow(p1,p2,label=None,style='solid',color=line,fs=8.8,dy=.13):
    ax.add_patch(FancyArrowPatch(p1,p2,arrowstyle='-|>',mutation_scale=13,linewidth=1.3,color=color,linestyle=style,zorder=2))
    if label:
        ax.text((p1[0]+p2[0])/2,(p1[1]+p2[1])/2+dy,label,fontsize=fs,color=color,ha='center',va='center',bbox=dict(facecolor='white',edgecolor='none',alpha=.95,pad=1),zorder=5)

xs=[1.35,4.1,6.85,9.6,12.35]
# Lane A: left to right
ya=6.05
rounded(xs[0],ya,'M02\nFarm setup +\ncultivation',fs=9.7)
rounded(xs[1],ya,'M03\nCreate batch +\nharvest',fs=9.7)
rounded(xs[2],ya,'M03\nGrade A / B / C +\nrejected quantity',fs=9.4)
diamond(xs[3],ya,'Grade total =\nharvest quantity?',fs=9.2)
rounded(xs[4],ya,'M04\nProcessing +\npackaging',fs=9.7)
for i in range(4): arrow((xs[i]+1.08,ya),(xs[i+1]-1.08,ya),label=('Yes' if i==3 else None),dy=.12)
# quantity exception note
rounded(xs[3],5.20,'No: correct and re-grade',fc=red,w=2.25,h=.34,fs=8.0)

# Lane B: right to left
yb=3.95
rounded(xs[4],yb,'M04\nQuality inspection',fs=9.7)
diamond(xs[3],yb,'Inspection\nresult?',w=2.0,h=.82,fs=9.5)
rounded(xs[2],yb,'M05\nReceive eligible\nstock',fc=green,fs=9.5)
rounded(xs[1],yb,'M06\nCreate + confirm\norder',fs=9.5)
rounded(xs[0],yb,'M06\nAllocate + pack',fs=9.5)
for i in range(4,0,-1): arrow((xs[i]-1.08,yb),(xs[i-1]+1.08,yb))
# Outcome qualification note
ax.text(xs[3],2.88,'Passed → eligible for M05 stock | Failed → Quality Hold\nPending → remain Processed and await re-inspection',ha='center',va='center',fontsize=7.8,color='#8B4A27',bbox=dict(boxstyle='round,pad=.22',facecolor='#FFF8F1',edgecolor='#D9B49B'))

# Lane C: left to right
yc=1.55
rounded(xs[0],yc,'M07\nDispatch + track\nshipment',fs=9.5)
diamond(xs[1],yc,'Outside configured\ntemperature range?',w=2.12,h=.82,fs=9.2)
rounded(xs[2],yc,'M07\nDelivery + retailer\nreceipt',fs=9.5)
rounded(xs[3],yc,'M08\nQR + public\ntrace',fc=green,fs=9.5)
rounded(xs[4],yc,'M08\nRecall + audit +\nalerts',fc=green,w=2.14,h=.72,fs=9.3)
for i in range(4): arrow((xs[i]+1.08,yc),(xs[i+1]-1.08,yc),label=('No' if i==1 else None),dy=.12)
# Temperature exception note
rounded(xs[1],0.55,'Yes: Safety Review Hold\nRelease after authorised review',fc=red,w=2.35,h=.42,fs=7.8)
# Module-to-module hand-off annotations: deliberately dashed and no claim of sync.
arrow((xs[4],5.66),(xs[4],4.36),'Manual / demo hand-off',style='dashed',color='#A87916',fs=8.2,dy=0)
arrow((xs[0],3.56),(xs[0],1.96),'Manual / demo hand-off',style='dashed',color='#A87916',fs=8.2,dy=0)
# Footer
ax.text(7.25,.12,'Logical business workflow only. The eight supplied applications use separate SQLite databases and do not synchronize automatically.',fontsize=8.7,color='#4B5967',ha='center',va='center')
plt.savefig(out,bbox_inches='tight',pad_inches=.10,facecolor='white')
print(out)

"""Run 61 data-driven scenarios against isolated SQLite in all eight standalone apps."""
from pathlib import Path
import json, subprocess, sys, datetime, csv
ROOT=Path(__file__).resolve().parent
apps=sorted((ROOT/'02_8_MODULE_DOC_LAP').glob('P*/M*/01_Python_Source'))
summary=[]
for app in apps:
    mid=app.parent.name[:3]
    cmd=[sys.executable,str(app/'run_data_tests.py')]
    print(f'===== {mid} =====',flush=True)
    result=subprocess.run(cmd,cwd=app)
    json_path=app.parent/'02_Test_Logs'/'data_driven_results.json'
    if json_path.exists():
        j=json.loads(json_path.read_text(encoding='utf-8'))
        if result.returncode: j['fail']=max(int(j['fail']),1)
        summary.append({'module':mid,'total':j['total'],'passed':j['pass'],'failed':j['fail'],'exit_code':result.returncode})
    else:
        summary.append({'module':mid,'total':0,'passed':0,'failed':1,'exit_code':result.returncode})
log_dir=ROOT/'03_KET_QUA_KIEM_THU';log_dir.mkdir(exist_ok=True)
with (log_dir/'data_test_summary.csv').open('w',newline='',encoding='utf-8-sig') as f:
    writer=csv.DictWriter(f,fieldnames=['module','total','passed','failed','exit_code']);writer.writeheader();writer.writerows(summary)
(log_dir/'data_test_summary.json').write_text(json.dumps({'generated_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'results':summary},ensure_ascii=False,indent=2),encoding='utf-8')
print('\n====== DATA TEST SUMMARY ======')
for x in summary:print(f'{x["module"]}: {x["passed"]}/{x["total"]} PASS, {x["failed"]} FAIL')
print('TOTAL:',sum(x['passed'] for x in summary),'/',sum(x['total'] for x in summary),'PASS')
sys.exit(0 if len(summary)==8 and all(x['failed']==0 and x['exit_code']==0 for x in summary) else 1)

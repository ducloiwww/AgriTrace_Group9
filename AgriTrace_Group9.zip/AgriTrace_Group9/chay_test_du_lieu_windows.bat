@echo off
cd /d "%~dp0"
python chay_test_du_lieu_8_module.py
pause

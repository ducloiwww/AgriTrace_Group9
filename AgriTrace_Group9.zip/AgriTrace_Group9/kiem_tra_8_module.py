"""Batch verification of eight self-contained module test suites; not required to run the websites."""
from pathlib import Path
import subprocess,sys
ROOT=Path(__file__).resolve().parent
errors=0
for folder in sorted(ROOT.glob('02_8_MODULE_DOC_LAP/*/M*/01_Python_Source')):
 result=subprocess.run([sys.executable,'run_tests.py'],cwd=folder)
 print(folder.parent.name, 'PASS' if result.returncode==0 else 'FAIL')
 errors+=result.returncode!=0
raise SystemExit(1 if errors else 0)

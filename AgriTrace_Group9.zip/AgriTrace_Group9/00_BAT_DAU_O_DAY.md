# AgriTrace Group 9 — 8 standalone modules / 4 participants

Each M01–M08 is an INDEPENDENT Python application, with its own app.py, data/module.sqlite3, tests, SRS snippets and diagrams.

**How to start:** select `02_8_MODULE_DOC_LAP/P0x_.../Mxx_.../01_Python_Source`; double-click run_windows.bat (Windows) or run `python app.py`. Then open `http://127.0.0.1:810x`, x = module number.

**Important:** M03–M08 use **local demonstration fixtures** to replace required data from upstream modules. They do not automatically share operational data. This is an independent teaching demo, not an integrated end-to-end workflow.

**To test:** in each module's `01_Python_Source`, run `python run_tests.py`; inspect `02_Test_Logs` for execution evidence.

Four 21-page Word reports are stored in `01_BAO_CAO_4_THANH_VIEN`; these were prepared for the integrated 8-module project and should be interpreted alongside the module-specific README and specifications.

Demo credentials: admin/Admin@123, farm/Farm@123, processor/Process@123, inspector/Inspect@123, warehouse/Warehouse@123, retailer/Retail@123, logistics/Logistics@123. Change the passwords before non-local use; bind to 127.0.0.1 by default.

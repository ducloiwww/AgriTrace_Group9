# AgriTrace Group 9 — kết quả sau sửa ngày 29/10/2026

| Module | Unit tests | Smoke nghiệp vụ | Website HTTP |
|---|---:|---|---|
| M01 — Identity & Access | 7/7 đạt | PASS | GET/POST smoke PASS |
| M02 — Farm & Cultivation | 9/9 đạt | PASS | GET/POST smoke PASS |
| M03 — Batch & Harvest | 7/7 đạt | PASS | GET/POST smoke PASS |
| M04 — Processing & Inspection | 7/7 đạt | PASS | GET/POST smoke PASS |
| M05 — Warehouse & Inventory | 8/8 đạt | PASS | GET/POST smoke PASS |
| M06 — Retail Orders & Allocation | 8/8 đạt | PASS | GET/POST smoke PASS |
| M07 — Shipment & Delivery | 8/8 đạt | PASS | GET/POST smoke PASS |
| M08 — Public Traceability, Recall & Audit | 9/9 đạt | PASS | GET/POST smoke PASS |

**Tổng cộng: 63/63 unittest đạt; 8/8 kịch bản smoke PASS; 8/8 ứng dụng khởi động, đăng nhập và trả HTML HTTP.**

Kiểm thử HTTP thực hiện trên các bản sao dữ liệu tạm và bao gồm kiểm tra M06 nhập số âm, giữ thông tin nhập sau lỗi và M08 che bảng audit khi không đủ quyền. Các kết quả này không phải bằng chứng kiểm thử tất cả thao tác thủ công hay triển khai production.
Các file `unit_tests_result.txt` trong gói có thể là bản log trước sửa; dùng `unit_tests_cap_nhat.txt` và `smoke_tests_cap_nhat.txt` mới để đối chiếu.
Bộ test tự động **không** được coi là thực thi đầy đủ mọi TC trong bộ FR/UC/TC thiết kế; chưa kiểm thử hiệu năng, bảo mật triển khai hoặc đồng bộ dữ liệu giữa các module.

## Chạy lại
Mở thư mục `01_Python_Source` trong từng module: `python run_tests.py`, `python verify_demo.py`, `python app.py`.
Trong thư mục gốc: `python kiem_tra_8_module.py`.
Module độc lập sử dụng dữ liệu demo và SQLite cục bộ; không cần chạy ứng dụng tích hợp.
Các thao tác chỉnh sửa nguy hiểm được giới hạn theo vai trò/trạng thái; Audit log là append-only.

# Đối chiếu Excel và dữ liệu chạy thử

**Excel Master Dataset:** sheet `test_cases` có 40 Test Case: TC-001 đến TC-020 theo 8 module, TC-021 đến TC-040 thuộc NFR/cross-cutting.

**Ứng dụng độc lập:** mỗi module có dữ liệu seed DEMO riêng (`B-DEMO` ...). Dữ liệu này KHÁC nhiều ID và lượng trong Excel gốc (`B-001`, 1000 kg ...). Để thực hiện thử tất cả tình huống trên app độc lập, đã tạo **61 kịch bản bổ sung DT-Mxx-yy** với các bước kiểm tra và precondition trên SQLite tạm. Đây là kịch bản thực thi theo logic nghiệp vụ hiện tại, không phải 40 TC gốc được tự động hóa nguyên dạng.

- Mở app → đăng nhập → bấm **Dữ liệu Excel / Test Case** để xem nguyên văn ca Excel và kịch bản executable.
- `python run_data_tests.py --list`: danh sách.
- `python run_data_tests.py --case DT-M05-07`: chạy riêng một ca.
- `python run_data_tests.py`: chạy toàn bộ ca của module.
- Nhật ký mới trong `02_Test_Logs/data_driven_execution.log` và JSON có **Actual** cùng **Expected**, không PASS giả.
- Không tự động gọi hoặc thay đổi DB website `data/module.sqlite3`.

**Lưu ý:** TC-021 đến TC-040 là các NFR/CR dùng chung chưa tự động hóa đầy đủ bởi bộ 61 ca. Cần tiếp tục kiểm thử tích hợp, hiệu năng, bảo mật theo chỉ tiêu của từng NFR.

# DỮ LIỆU MASTER DATASET EXCEL VÀ APP TEST

## Hai nguồn dữ liệu cần phân biệt
- **Master Dataset Excel gốc**: `04_DU_LIEU_EXCEL_VA_SRS_TONG_HOP/AgriTrace_Master_Dataset_Group9_8Modules.xlsx`, gồm 20 sheet, 40 TC thiết kế. TC-001 tới TC-020 theo module; TC-021 tới TC-040 dùng chung NFR/CR.
- **Excel mới có dữ liệu chạy thử**: `04_DU_LIEU_EXCEL_VA_SRS_TONG_HOP/AgriTrace_Master_Dataset_Them_DuLieu_Test_App.xlsx`: giữ 20 sheet cũ và thêm `App_Test_Data_61`, `Excel_App_Mapping`, `HuongDan_App_Test`.

**Quan trọng**: Input ở bản Excel gốc có thể là B-001 và sản lượng 1000 kg, trong khi ứng dụng hiện tại độc lập sử dụng B-DEMO, 100 kg. 61 kịch bản DT-* **không phải** là 40 Test Case gốc đã được thực thi y nguyên. Chúng là những ca bổ sung theo cùng FR/UC, dùng fixture demo phù hợp với source code hiện tại.

## Xem dữ liệu TC trong app
1. Mở một module bất kỳ, chạy `python app.py`.
2. Đăng nhập bằng tài khoản demo.
3. Bấm liên kết **Dữ liệu Excel / Test Case** ở đầu giao diện.
4. Xem các mục gốc từ Excel (Precondition, Input, Steps, Expected) và các kịch bản DT-* thực thi được.

## Chạy test từ dữ liệu (an toàn với website)
Trong `01_Python_Source` của mỗi module:

```powershell
python run_data_tests.py --list
python run_data_tests.py
python run_data_tests.py --case DT-M05-07
```

Ở thư mục gốc `AgriTrace_Group9` chạy:

```powershell
python chay_test_du_lieu_8_module.py
```

Log tạo mới: `02_Test_Logs/data_driven_execution.log` (Expected / Actual) và `data_driven_results.json`. Các ca chạy trong SQLite tạm riêng: **không làm mất dữ liệu đang nhập trên web**.

## Phạm vi chưa được bao phủ
Các NFR/CR Test Case TC-021...TC-040 vẫn cần đánh giá và chạy riêng theo chỉ tiêu thích hợp (đặc biệt hiệu năng, bảo mật, tính nhất quán). Không nên sao chép số PASS lịch sử của Excel thành số liệu phiên chạy mới.

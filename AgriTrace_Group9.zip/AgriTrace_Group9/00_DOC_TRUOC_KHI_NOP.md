# AgriTrace Group 9 — bản cập nhật đầy đủ

## Tổ chức
- `01_BAO_CAO_4_THANH_VIEN`: 4 báo cáo Word ~22 trang, giữ nguyên phong cách bìa mẫu.
- `02_8_MODULE_DOC_LAP`: 8 ứng dụng Python chạy độc lập, phân cho 4 thành viên.
- `03_KET_QUA_KIEM_THU`: tóm tắt kết quả hiện hành.

## Hướng dẫn 3 lệnh
1. Mở `01_Python_Source` của module bất kỳ trong VS Code.
2. Chạy `python run_tests.py` và `python verify_demo.py` để xem PASS/FAIL.
3. Chạy `python app.py` rồi truy cập `http://127.0.0.1:8101` (M01) đến `:8108` (M08).

Mỗi module có SQLite của riêng mình. Khi thầy yêu cầu nhập sai, chọn biểu mẫu (đúng vai trò), nhập số âm/mã không hợp lệ hoặc sửa bản ghi sai trạng thái để thấy thông báo và kiểm tra dữ liệu không đổi.

LƯU Ý: Dữ liệu demo không đồng bộ giữa các module. Đây là ứng dụng học tập cục bộ, không phải sản phẩm triển khai thực tế.

## Group-level system models (English)
- `05_GROUP_LEVEL_MODELS`: six group-level diagrams in PNG format and editable Graphviz DOT / Python source files.
- The consolidated Word report includes the same diagrams in Appendix H and the GitHub repository URL in Section 1.4.
- Repository: https://github.com/ducloiwww/AgriTrace_Group9.git
- The models distinguish the intended farm-to-table business workflow from the current eight standalone applications. Dashed hand-offs do not represent automatic synchronization.
